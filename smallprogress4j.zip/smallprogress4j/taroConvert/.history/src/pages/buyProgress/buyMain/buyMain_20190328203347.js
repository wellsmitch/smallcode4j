import {
  Block,
  View,
  Image,
  Text,
  Input,
  Picker,
  Textarea
} from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
import { Network, Api, validate } from '../../../utils/index.js'
// eslint-disable-next-line import/no-commonjs
const citysJSON = require('../../../utils/city.js');
//index.js
//获取应用实例
import './buyMain.scss'
const app = Taro.getApp()

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    mobile: Taro.getApp().globalData.mobile,
    region: ['河南省', '郑州市', '二七区'],
    // regionText: '河南省-郑州市-二七区',
    customItem: '全部',
    detailNum: 0,
    buyNumber: 1,
    isSelect: true,
    isBuySelect: true,
    receiver: '',
    receiverPhone: '',
    receiverAdress: '',
    receiverRegion: '河南省-郑州市-二七区',
    remark: '',
    singlePrice: '8.0', // 单价
    totalPrice: '8.0', // 总价
    totalGoodsPrice: '0.0', // 商品总价
    servicePrice: '0.0', // 信息服务费
    initServicePrice: '0.0', // 信息服务费
    freight: '0.0', // 运费
    login_code: '',
    agreeCheck: true, // 协议勾选
    userArr: ''
  }

  componentWillMount(option) {
    let userArr = ''
    if (option.userid) {
      userArr = option.userid.split('_')
    }
    this.moveCarGet()
    this.setData({
      login_code: app.globalData.login_code || '',
      userArr: userArr
    })
  }

  moveCarGet = () => {
    Network.post(
      Api.DYNAMIC_PRICE,
      {
        params: {
          buyNumber: 1
        },
        loading: false
      },
      data => {
        if (data.code === 200) {
          this.setData({
            freight: parseFloat(data.data.freight).toFixed(2),
            singlePrice: parseFloat(data.data.unitPrice).toFixed(2),
            initServicePrice: parseFloat(data.data.servicePrice).toFixed(2),
            totalGoodsPrice: parseFloat(data.data.unitPrice).toFixed(2),
            servicePrice: parseFloat(data.data.servicePrice).toFixed(2),
            totalPrice: parseFloat(
              Number(data.data.unitPrice) +
                Number(data.data.freight) +
                Number(data.data.servicePrice)
            ).toFixed(2)
          })
        }
      }
    )
  }
  tapAgree = () => {
    let _t = !this.data.agreeCheck
    this.setData({
      agreeCheck: _t
    })
  }
  buyImm = () => {
    if(!Taro.getApp().globalData.token){
      Taro.getApp().globalData.goToUrl = '/pages/login/login';
      my.navigateTo({
        url: '/pages/login/login'
      })
      return;
    }
    if (!this.data.receiver.trim()) {
      Taro.showToast({
        title: '请填写收货人姓名',
        icon: 'none'
      })
      return false
    }
    let phoneNumber = this.data.receiverPhone.trim()
    if (!validate.phoneNumber(phoneNumber)) {
      Taro.showToast({
        title: '请输入11位有效的手机号码',
        icon: 'none'
      })
      return false
    }
    if (!this.data.receiverAdress.trim()) {
      Taro.showToast({
        title: '请填写详细收货地址',
        icon: 'none'
      })
      return false
    }
    if (!this.data.agreeCheck) {
      Taro.showToast({
        title: '请勾选服务协议',
        icon: 'none'
      })
      return false
    }
    console.log(1)
    let _param = {
      buyNumber: this.data.buyNumber, //数量
      receiver: this.data.receiver, //姓名
      receiverPhone: this.data.receiverPhone, //手机号
      receiverAdress: this.data.receiverAdress, //地址
      receiverRegion: this.data.receiverRegion,
      totalPrice: this.data.totalPrice //总价
    }

    if (typeof this.data.userArr == 'object' && this.data.userArr.length > 0) {
      _param.inviteUserId = this.data.userArr[0]
      _param.inviteSource = this.data.userArr[1]
    }
    if(this.state.isBuySelect){
      this.state.isBuySelect = false;
      // this.setState({
      //   isSelect: false
      // })
      Network.post(
        Api.C_ORDER,
        {
          params: {
            params: JSON.stringify(_param)
          }
        },
        data => {
          this.state.isBuySelect = true;
          if (data.code === 200) {
            this.cxxPay(data.data.orderNumber)
          } else {
            Taro.showToast({
              title: data.message,
              icon: 'none'
            })
          }
        }
      )
    }
    console.log(0)
    
  }
  cxxPay = orderId => {
    // 先检查session是否过期
    // let _fn = (orderId) => {
      Network.post(
        Api.XCX_PAY,
        {
          params: {
            tradeType: 'HLB-XCX-SM',
            orderNumber: orderId
          }
        },
        res => {
          console.log('-=-=-=-=-')
          console.log(res)
          if (res.code == 200) {
            my.tradePay({
              tradeNO: res.data.trade_no, // 调用统一收单交易创建接口（alipay.trade.create），获得返回字段支付宝交易号trade_no
              success: (res) => {
                console.log('pppppppppppp')
                console.log(res)
                if(res.resultCode == '9000'){
                  Taro.navigateTo({
                    url: '/pages/buyProgress/buySuc/buySuc'
                  })
                }
              },
              fail: (res) => {
                my.alert({
                content: '支付失败~',
              });
              }
            });
            // this.wxPluginPay(res.data)
          }else {
            my.alert({
              content: res.message,
            });
          }
        }
      )
    // }

    // Taro.login({
    //   success: res => {
    //     app.globalData.login_code = res.code
    //     this.setData({
    //       login_code: res.code
    //     })
    //     _fn(orderId, res.code)
    //   }
    // })
    // wx.checkSession({
    //     success: () => { // 没有过期
    //         _fn(orderId, this.data.login_code)
    //     },
    //     fail: () => {
    //         wx.login({
    //             success: (res) => {
    //                 app.globalData.login_code = res.code;
    //                 this.setData({
    //                     login_code: res.code
    //                 });
    //                 _fn(orderId, res.code);
    //             }
    //         })
    //     }
    // })
  }
  wxPluginPay = data => {
    let _param = {
      timeStamp: data.timeStamp,
      nonceStr: data.nonceStr,
      package: `${data.package}`,
      signType: 'MD5',
      paySign: data.paySign,
      success: () => {
        Taro.redirectTo({
          url: '/pages/buyProgress/buySuc/buySuc'
        })
      },
      fail: res => {
        console.warn(res)
      }
    }
    console.log(_param)
    Taro.requestPayment(_param)
  }
  // bindRegionChange = e => {
  //   // console.log(e.detail.value);
  //   this.setData({
  //     receiverRegion: e.detail.value.join('-')
  //   })
  // }
  nameBlur = e => {
    // console.log(e);
    // if (!e.detail.value.trim()) {
    //   wx.showToast({title: '请填写收货人姓名', icon: 'none'})
    //   return false;
    // }
    this.setData({
      receiver: e.detail.value
    })
    // return true;
  }
  detailInput = e => {
    this.setData({
      receiverAdress: e.detail.value
    })
    this.setData({
      detailNum: e.detail.value.trim().length
    })
  }
  detailBlur = e => {
    // if (!e.detail.value.trim()) {
    //   wx.showToast({title: '请填写详细收货地址', icon: 'none'});
    //   return false;
    // }
    // console.log();
    this.setData({
      receiverAdress: e.detail.value
    })
    // return true;
  }
  phoneBlur = e => {
    // if (!e.detail.value.trim() || e.detail.value.trim().length < 11) {
    //   wx.showToast({title: '请输入11位有效的手机号码', icon: 'none'});
    //   return false;
    // }
    this.setData({
      receiverPhone: e.detail.value
    })
    // return true;
  }
  getAddress() {
    let isSelect = this.state.isSelect;
    if(isSelect){
      this.setState({
        isSelect: false
      })
      my.multiLevelSelect({
        title: '选择省市区',//级联选择标题
        list: citysJSON.citys,//引入的js
        success: (res) => {
          this.state.isSelect = true;
            // this.setState({
            //   isSelect: true
            // })
            let address = res.result.length === 3 ? res.result[0].name + '-' + res.result[1].name + '-' + res.result[2].name : res.result[0].name + '-' + res.result[1].name;
            this.setData({
                receiverRegion: address
            })
        }
      });
    }
  }
  accAdd = (arg1, arg2) => {
    var r1, r2, m
    try {
      r1 = arg1.toString().split('.')[1].length
    } catch (e) {
      r1 = 0
    }
    try {
      r2 = arg2.toString().split('.')[1].length
    } catch (e) {
      r2 = 0
    }
    m = Math.pow(10, Math.max(r1, r2))
    return (arg1 * m + arg2 * m) / m
  }
  numDesc = () => {
    if (this.data.buyNumber >= 2) {
      let _d = this.data.buyNumber - 1,
        toFixedTotalGoodsPrice = parseFloat(this.data.singlePrice * _d).toFixed(
          2
        ),
        toFixedServicePrice = parseFloat(
          this.data.initServicePrice * _d
        ).toFixed(2),
        toFixedTotalPrice = parseFloat(
          this.accAdd(
            this.accAdd(this.data.singlePrice * _d, this.data.freight),
            toFixedServicePrice
          )
        ).toFixed(2)
      this.setData({
        buyNumber: _d,
        totalGoodsPrice: toFixedTotalGoodsPrice,
        servicePrice: toFixedServicePrice,
        totalPrice: toFixedTotalPrice
      })
    }
  }
  numAdd = () => {
    let _d = this.data.buyNumber + 1,
      toFixedTotalGoodsPrice = parseFloat(this.data.singlePrice * _d).toFixed(
        2
      ),
      toFixedServicePrice = parseFloat(this.data.initServicePrice * _d).toFixed(
        2
      ),
      toFixedTotalPrice = parseFloat(
        this.accAdd(
          this.accAdd(this.data.singlePrice * _d, this.data.freight),
          toFixedServicePrice
        )
      ).toFixed(2)
    this.setData({
      buyNumber: _d,
      totalGoodsPrice: toFixedTotalGoodsPrice,
      servicePrice: toFixedServicePrice,
      totalPrice: toFixedTotalPrice
    })
  }
  goServAgree = () => {
    Taro.navigateTo({
      url: '/pages/doc/servAgree/servAgree'
    })
  }
  telCall = () => {
    Taro.makePhoneCall({
      phoneNumber: this.data.mobile
    })
  }
  config = {
    navigationBarTitleText: '购买车贴'
  }

  render() {
    const {
      buyNumber: buyNumber,
      totalGoodsPrice: totalGoodsPrice,
      servicePrice: servicePrice,
      freight: freight,
      region: region,
      customItem: customItem,
      receiverRegion: receiverRegion,
      detailNum: detailNum,
      mobile: mobile,
      agreeCheck: agreeCheck,
      totalPrice: totalPrice
    } = this.state
    return (
      <Block>
        {/* index.wxml */}
        <View className="container">
          <View className="top-view">
            <Image
              className="image-bg"
              src="https://apph5.mmcqing.com/xcx/images/buy-suc-bg.png"
            />
            <View className="content-view">
              <Image
                className="image"
                src="https://apph5.mmcqing.com/xcx/images/buy-qr.png"
              />
              <View className="right-view">
                <View className="t-text">
                  <Text>挪车贴</Text>
                  <Text className="t-num">x1</Text>
                </View>
                <View>
                  <Text>材质：可移不干胶</Text>
                </View>
                <View>
                  <Text>尺寸：81mm*91mm</Text>
                </View>
              </View>
            </View>
            <View className="remain-view">
              <Text>
                注：收到快递后请<Text className="or">绑定</Text>
                挪车码后使用，如有疑问可查看“我的-使用帮助”
              </Text>
            </View>
          </View>
          <View className="main-container">
            <View className="form-view">
              <View className="input-view border-none price">
                <View className="left">购买数量</View>
                <View className="right">
                  <View className="content-view right-top">
                    <Text
                      className="desc"
                      hoverClass="hoveractive"
                      onClick={this.numDesc}
                    />
                    <Text className="input input-none">{buyNumber}</Text>
                    {/* <Input className="input input-none" value={buyNumber} /> */}
                    <Text
                      className="add"
                      onClick={this.numAdd}
                      hoverClass="hoveractive"
                    />
                  </View>
                </View>
              </View>
              {/* <View className="input-view price">
                <View className="left">商品总价</View>
                <View className="right">
                  <Text className="layer-text">{'￥' + totalGoodsPrice}</Text>
                </View>
              </View>
              <View className="input-view price">
                <View className="left">信息服务费</View>
                <View className="right">
                  <Text className="layer-text">{'￥' + servicePrice}</Text>
                </View>
              </View>
              <View className="input-view noboder price">
                <View className="left">运费</View>
                <View className="right">
                  <Text className="layer-text">{'￥' + freight}</Text>
                </View>
              </View> */}
            </View>
            <View className="form-view">
              <View className="input-view">
                <Text className="label">收货人</Text>
                <View className="wid60">
                  <Input
                    type="text"
                    onInput={this.nameBlur}
                    className="input"
                    placeholder="请输入收货人姓名"
                    placeholderClass="placehoderClass"
                  />
                </View>
              </View>
              <View className="input-view">
                <Text className="label">联系电话</Text>
                <View className="wid60">
                  <Input
                    type="number"
                    onInput={this.phoneBlur}
                    maxlength="11"
                    className="input"
                    placeholder="请输入手机号码"
                    placeholderClass="placehoderClass"
                  />
                </View>
              </View>
              <View className="input-view">
                <Text className="label">所在区域</Text>
                <View className="wid60" onClick={this.getAddress}>
                  <Input
                    disabled
                    type="number"
                    value={this.state.receiverRegion}
                    maxlength="11"
                    className="input"
                    placeholder="请选择地区"
                    placeholderClass="placehoderClass"
                  />
                </View>
              </View>
              {/* <Picker
                mode="region"
                range="['中国', '美国', '巴西', '日本']"
                onChange={this.bindRegionChange}
                value={region}
                customItem={customItem}
              >
                <View className="input-view more-right">
                  <Text>所在区域</Text>
                  <View className="right-text">{receiverRegion}</View>
                </View>
              </Picker> */}
              <Textarea
                className="form-textarea"
                onInput={this.detailInput}
                maxlength="60"
                placeholder="请填写详细收货地址"
                placeholderClass="placehoderClass"
              />
              {/* <View className="textarea-label">
                <Text>{detailNum}</Text>/60
              </View> */}
            </View>
            <View className="copy-view">
              <Text className="c">本服务由和路宝提供</Text>
              <View className="c">
                客服电话：
                <View onClick={this.telCall} className="tel">
                  <Text>{mobile}</Text>
                </View>
              </View>
            </View>
          </View>
          <View className="agree-view">
            {!agreeCheck && <View className="before" onClick={this.tapAgree} />}
            {agreeCheck && (
              <Image
                src="https://apph5.mmcqing.com/xcx/images/check.png"
                className="icon"
                onClick={this.tapAgree}
              />
            )}
            我同意
            <Text className="orange-text" onClick={this.goServAgree}>
              《服务协议》
            </Text>
            中的说明
          </View>
          <View className="bottom-fixed">
            <View className="m-view">{'共计' + totalPrice + '元'}</View>
            <View
              className="buy-submit"
              hoverClass="hoveactive"
              onClick={this.buyImm}
            >
              立即购买
            </View>
          </View>
        </View>
      </Block>
    )
  }
}

export default _C
