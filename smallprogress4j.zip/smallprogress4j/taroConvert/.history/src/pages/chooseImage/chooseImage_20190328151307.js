import {
  Block,
  View,
  CoverImage,
  Camera,
  Image,
  Text,
  Button
} from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'

import { Api, Network, validate } from '../../utils/index.js'
import './chooseImage.scss'
const app = Taro.getApp()

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    showBox: true,
    clicktime: true
  }

  componentWillMount(options) {
    // setTimeout(() => {
    //   this.ctx = Taro.createCameraContext()
    // }, 200)
    my.getSetting({
      success: (res) => {
        console.log('-=-=-=-=-=-=-==-')
        console.log(res)
        /*
         * res.authSetting = {
         *   "scope.location": true,
         *   "scope.audioRecord": true,
         *   ...
         * }
         */
      }
    })
  }

  componentDidMount() {}

  componentDidShow() {
    let that = this
    if (this.data.showBox) {
      return
    }
    my.getSetting({
      success: (res) => {
        if (res.authSetting.camera) {
          that.setData({
            showBox: true
          })
        } else {
          that.setData({
            showBox: false
          })
        }
      }
    })
    // Taro.getSetting({
    //   success(res) {
    //     console.log(res.authSetting['scope.camera'])
    //     if (res.authSetting['scope.camera']) {
    //       that.setData({
    //         showBox: true
    //       })
    //     } else {
    //       that.setData({
    //         showBox: false
    //       })
    //     }
    //   }
    // })
  }

  componentDidHide() {}

  takePhoto = () => {
    // if (!this.data.clicktime) {
    //   return
    // }
    this.setData({
      clicktime: false
    })
    var that = this
    my.chooseImage({
      count: 1,
      chooseImage: 1,
      sourceType: 'camera',
      success: res => {
        that.setData({
          src: res.apFilePaths[0]
        })
        // Taro.showLoading({
        //   title: '识别中'
        // })
        const uploadTask = Taro.uploadFile({
          url: Api.lpr, // 仅为示例，非真实的接口地址
          filePath: res.apFilePaths[0],
          name: 'imgBase',
          header: {
            'content-type': 'multipart/form-data'
          },
          formData: {},
          success(res) {
            Taro.hideLoading()
            if (res.statusCode == 200) {
              let cardata = JSON.parse(res.data)
              console.log(JSON.parse(res.data))
              if (cardata.code == 200) {
                that.setimg(cardata.data[0].carNum)
              } else {
                Taro.showToast({
                  title: cardata.message,
                  icon: 'none',
                  duration: 2000
                })
                that.setData({
                  src: ''
                })
              }
            } else {
              Taro.hideLoading()
              Taro.showToast({
                title: '车牌解析失败，请重试！',
                icon: 'none',
                duration: 2000
              })
              that.setData({
                src: ''
              })
            }

            // do something
          },
          fail: function(res) {
            Taro.hideLoading()
            console.log(res)
            typeof fail == 'function' && fail(res.data)
            Taro.showToast({
              title: '网络异常，请重试！',
              icon: 'none',
              duration: 2000
            })
            that.setData({
              src: ''
            })
          },
          complete: function() {
            Taro.hideLoading()
            that.setData({
              clicktime: true
            })
          }
        })
      }
    });
    // this.ctx.takePhoto({
    //   quality: 'high',
      // success: res => {
      //   console.log(res)
      //   that.setData({
      //     src: res.tempImagePath
      //   })
      //   Taro.showLoading({
      //     title: '识别中'
      //   })
      //   const uploadTask = Taro.uploadFile({
      //     url: Api.lpr, // 仅为示例，非真实的接口地址
      //     filePath: res.tempImagePath,
      //     name: 'imgBase',
      //     header: {
      //       'content-type': 'multipart/form-data'
      //     },
      //     formData: {},
      //     success(res) {
      //       if (res.statusCode == 200) {
      //         let cardata = JSON.parse(res.data)
      //         console.log(JSON.parse(res.data))
      //         if (cardata.code == 200) {
      //           that.setimg(cardata.data[0].carNum)
      //         } else {
      //           Taro.showToast({
      //             title: cardata.message,
      //             icon: 'none',
      //             duration: 2000
      //           })
      //           that.setData({
      //             src: ''
      //           })
      //         }
      //       } else {
      //         Taro.showToast({
      //           title: '车牌解析失败，请重试！',
      //           icon: 'none',
      //           duration: 2000
      //         })
      //         that.setData({
      //           src: ''
      //         })
      //       }

      //       // do something
      //     },
      //     fail: function(res) {
      //       console.log(res)
      //       typeof fail == 'function' && fail(res.data)
      //       Taro.showToast({
      //         title: '网络异常，请重试！',
      //         icon: 'none',
      //         duration: 2000
      //       })
      //       that.setData({
      //         src: ''
      //       })
      //     },
      //     complete: function() {
      //       that.setData({
      //         clicktime: true
      //       })
      //     }
      //   })
      // }
    // })
  }
  setimg = data => {
    var pages = Taro.getCurrentPages()
    var currPage = pages[pages.length - 1] //当前页面
    var prevPage = pages[pages.length - 2] //上一个页面
    Taro.getApp().globalData.cardata = data;
    Taro.getApp().globalData.isDetail = true;
    // prevPage.setState({
    //   cardata: data
    // })
    // Taro.navigateBack()
    // redirectTo
    my.redirectTo({
      url: Taro.getApp().globalData.cameUrl
    })
  }
  callback = () => {
    var that = this
  }
  error = () => {
    this.setData({
      showBox: false
    })
  }
  config = {
    disableScroll: true
  }

  render() {
    const { showBox: showBox, src: src } = this.state
    return (
      <Block>
        {showBox && (
          <View className="camearImg">
            {src && (
              <CoverImage className="carimg" mode="aspectFit" src={src} />
            )}
            <Camera
              devicePosition="back"
              flash="off"
              onError={this.error}
              className="camearImgs"
            />
          </View>
        )}
        <View className="bottom">
          <View className="bottom_title flex_hm flex_hc">
            点击拍照，自动识别车牌号
          </View>
          <View className="bottom_body">
            <Image
              className="btimg"
              onClick={this.takePhoto}
              src="https://apph5.mmcqing.com/xcx/images/btnimg.png"
            />
            <View className="btimgtext">拍照</View>
          </View>
        </View>
        {!showBox && (
          <View className="flex_hm flex_hc btn flex_v">
            <Text className="tstxt">您未允许打开相机，请点击设置允许</Text>
            <Text className="tstxt">打开相机后重新回到本页面</Text>
            <Button
              className="gosetting"
              openType="openSetting"
              onOpenSetting={this.callback}
            >
              去设置
            </Button>
          </View>
        )}
        {/*  <view class="page-body">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           <view class="page-body-wrapper">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             <view class="btn-area">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               <button type="primary" bindtap="takePhoto">拍照</button>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             </view>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           </view>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         </view>  */}
      </Block>
    )
  }
}

export default _C
