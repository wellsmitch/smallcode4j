import Taro from '@tarojs/taro-h5';
import { Block, View, Image } from '@tarojs/components';
import Nerv from "nervjs";
import withWeapp from '@tarojs/with-weapp';
import './invite.scss';
var app = Taro.getApp();

@withWeapp('Component')
class _C extends Taro.Component {
  _observeProps = [];
  state = {};
  Jump = () => {
    // this.triggerEvent('Jump', {}, {});
    Taro.navigateTo({
      url: '/pages/activities/inviteEarnMoney/inviteEarnMoney'
    });
  };
  config = {
    component: true
  };

  render() {
    return <Block>
        {/*  组件模板  */}
        <View className="wrapper">
          <View onClick={this.Jump}>
            <Image className="jump" mode="widthFix" src="https://apph5.mmcqing.com/xcx/images/invite.png" />
          </View>
        </View>
      </Block>;
  }
}

export default _C;