import Taro from '@tarojs/taro-h5';
import { Block, View, CoverView, CoverImage } from '@tarojs/components';
import Nerv from "nervjs";
import withWeapp from '@tarojs/with-weapp';
import './authorized.scss';
// components/component-tag-name.js
// import { util, Network, Api } from "utils/index";
// var md5 = require('utils/md5.js');
var app = Taro.getApp();

@withWeapp('Component')
class _C extends Taro.Component {
  _observeProps = [];
  state = {
    phoneAuth: '',
    msgCanClick: true,
    phoneNumber: '',
    openid: '',
    showMsgPanel: false,
    msgBtnText: '',
    msgCode: '',
    focus: false,
    charAt0: '',
    charAt1: '',
    charAt2: '',
    charAt3: '',
    charAt4: '',
    charAt5: '',
    animationData: {}
  };
  inputfocus = () => {
    this.setData({
      focus: true
    });
  };
  onshows = () => {};
  onTap = () => {
    var myEventDetail = {
      data: this.data // detail对象，提供给事件监听函数
    };
    var myEventOption = {}; // 触发事件的选项
    this.triggerEvent('myevent', myEventDetail, myEventOption);
    this.setData({
      vie: 'miokh',
      showMsgPanel: false
    });
  };
  msgCodeBlur = e => {
    // 手机号失去焦点获取值

    let msgCode = e.detail.value.trim();
    this.setData({
      msgCode: msgCode,
      charAt0: msgCode.charAt(0),
      charAt1: msgCode.charAt(1),
      charAt2: msgCode.charAt(2),
      charAt3: msgCode.charAt(3),
      charAt4: msgCode.charAt(4),
      charAt5: msgCode.charAt(5)
    });
  };
  toBuy = e => {
    // 购买授权判断
    if (Taro.getStorageSync('click')) {
      return false;
    }
    Taro.getStorageSync('click', '1');
    this.setData({
      msgCode: '',
      charAt0: '',
      charAt1: '',
      charAt2: '',
      charAt3: '',
      charAt4: '',
      charAt5: ''
    });
    let that = this;
    // this.setData({
    //     showMsgPanel:true
    // })
    // this.anim()
    Taro.showLoading({
      title: '加载中...',
      mask: true
    });
    app.accredit(e, res => {
      //授权获取手机号
      // console.log(res)
      console.log(res);
      that.setData({
        phoneNumber: res.data.phone,
        openid: res.data.openid,
        showMsgPanel: false
        // msgBtnText: '60s后可重发'
      });
      let myEventDetail = {
        data: that.data //
      };
      let myEventOption = {};
      this.triggerEvent('myevent', myEventDetail, myEventOption);
      // that.dowmSms();
    });
  };
  dowmSms = () => {
    //倒计时操作
    if (this.data.msgCanClick) {
      this.setData({ msgCanClick: false }); //不可点击
      //app.msgGet(this.data.phoneNumber)////发送验证码
      let _count = 60;
      this.setData({
        timer: setInterval(() => {
          _count--;
          this.setData({ msgBtnText: `${_count}s可重发` });
          if (_count === 0) {
            this.setData({ msgBtnText: `重新获取` });
            clearInterval(this.data.timer);
            this.setData({
              timer: null,
              msgCanClick: true
            });
          }
        }, 1000)
      });
    }
  };
  modalCancel = () => {
    // 关闭弹框
    this.setData({ showMsgPanel: false });
  };
  modalConfirm = () => {
    // 弹框确认
    var myEventDetail = {
      data: this.data // detail对象，提供给事件监听函数
    };
    var myEventOption = {}; // 触发事件的选项
    // console.log(myEventDetail)

    this.triggerEvent('myevent', myEventDetail, myEventOption);
  };
  onMyEvent = e => {
    // console.log(e)
  };
  anim = () => {
    var animation = Taro.createAnimation({
      duration: 150,
      timingFunction: 'linear',
      delay: 0,
      transformOrigin: '50% 50% 0',
      success: function (res) {
        console.log('res');
      }
    });

    this.animation = animation;
    this.setData({
      animationData: animation.export()
    });
    // animation.scale(2, 2).rotate(45).step()

    var n = 0;
    //连续动画需要添加定时器,所传参数每次+1就行
    var time = setInterval(function () {
      // animation.translateY(-60).step()
      n = n + 1;
      if (!this.data.showMsgPanel) {
        clearInterval(time);
        time = null;
      }
      console.log(180 * n);
      this.animation.rotateZ(180 * n).step();
      this.setData({
        animationData: this.animation.export()
      });
    }.bind(this), 150);
  };
  config = {
    component: true
  };

  render() {
    const {
      showMsgPanel: showMsgPanel,
      animationData: animationData
    } = this.state;
    return <Block>
        {/*  组件模板  */}
        <View className="wrapper">
          {/*  <view class="modal" wx:if="{{showMsgPanel}}">
                                                                   <view class="modal-main">
                                                                       <view class="modal-title">请填写手机短信验证码</view>
                                                                       <view class="modal-content">
                                                                           <view class="c-title">
                                                                               <text>已发送到手机号：{{phoneNumber}}</text>
                                                                           </view>
                                                                           <view class="c-content">   
                                                                               
                                                                               <text class='numCode' bindtap='inputfocus'>{{charAt0}}</text> 
                                                                               <text class='numCode' bindtap='inputfocus'>{{charAt1}}</text> 
                                                                               <text class='numCode' bindtap='inputfocus'>{{charAt2}}</text>                
                                                                               <text class='numCode' bindtap='inputfocus'>{{charAt3}}</text> 
                                                                               <text class='numCode' bindtap='inputfocus'>{{charAt4}}</text> 
                                                                               <text class='numCode' bindtap='inputfocus'>{{charAt5}}</text> 
                                                                               <input type="number"  focus="{{focus}}" value="{{msgCode}}" class="input" maxlength="6" bindinput="msgCodeBlur" placeholder="www" cursor-spacing="20" />
                                                                           </view>
                                                                           <view class="c-msg" bindtap="dowmSms" wx:if="{{msgCanClick}}">{{msgBtnText}}</view>
                                                                           <view class="c-msg c-msg-gray" bindtap="dowmSms" wx:else>{{msgBtnText}}</view>
                                                                           <view class="modal-btn">
                                                                               <text class="btn cancel" bindtap="modalCancel">取消</text>
                                                                               <text class="btn confirm" bindtap="modalConfirm">确认</text>
                                                                           </view>
                                                                       </view>
                                                                   </view>
                                                               </view>  */}
          {/*  <view class='loading' wx:if="{{showMsgPanel}}">
                                                                                    <view class='loading_imgbox'>  
                                                                                        <view class='loading_box' animation="{{animationData}}" >
                                                                                            <image  mode="scaleToFill" class="loadImg" src="https://apph5.mmcqing.com/xcx/images/loading.png"   />
                                                                                        </view>
                                                                                    </view>
                                                                                </view>  */}
          {showMsgPanel && <CoverView className="loading">
              <CoverView className="loading_box">
                <CoverImage animation={animationData} mode="scaleToFill" className="loadImg" src="https://apph5.mmcqing.com/xcx/images/loading.png" />
              </CoverView>
            </CoverView>}
        </View>
      </Block>;
  }
}

export default _C;