import Taro from '@tarojs/taro-h5';
import { Block, View, Image, Text } from '@tarojs/components';
import Nerv from "nervjs";
import withWeapp from '@tarojs/with-weapp';
import './introduce.scss';
var app = Taro.getApp();

@withWeapp('Component')
class _C extends Taro.Component {
  _observeProps = [];
  state = {};
  config = {
    component: true
  };

  render() {
    return <Block>
        {/*  组件模板  */}
        <View className="introduceBox flex flex_hm">
          <View className="flex1">
            <Image className="introduce-img" mode="aspectFit" src="https://apph5.mmcqing.com/xcx/images/jieshao-icon1.png" />
            <Text className="introduce-t">隐私保护</Text>
            <Text className="introduce-c">匿名打电话</Text>
            <Text className="introduce-c">信息无泄漏</Text>
          </View>
          <View className="flex1">
            <Image className="introduce-img" mode="aspectFit" src="https://apph5.mmcqing.com/xcx/images/jieshao-icon2.png" />
            <Text className="introduce-t">快速便捷</Text>
            <Text className="introduce-c">微信扫码</Text>
            <Text className="introduce-c">一键通知挪车</Text>
          </View>
          <View className="flex1">
            <Image className="introduce-img" mode="aspectFit" src="https://apph5.mmcqing.com/xcx/images/jieshao-icon3.png" />
            <Text className="introduce-t">多管齐下</Text>
            <Text className="introduce-c">电话短信推送</Text>
            <Text className="introduce-c">多通道速达</Text>
          </View>
        </View>
      </Block>;
  }
}

export default _C;