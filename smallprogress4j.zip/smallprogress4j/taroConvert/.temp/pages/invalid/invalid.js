import Taro from '@tarojs/taro-h5';
import { Block, Text } from '@tarojs/components';
import Nerv from "nervjs";
import withWeapp from '@tarojs/with-weapp';
import './invalid.scss';

@withWeapp('Page')
class _C extends Taro.Component {
  state = {};

  componentWillMount(options) {}

  componentDidMount() {}

  componentDidShow() {}

  componentDidHide() {}

  componentWillUnmount() {}

  onPullDownRefresh = () => {};
  onReachBottom = () => {};
  onShareAppMessage = () => {};
  config = {};

  render() {
    return <Block>
        {/* pages/invalid/invalid.wxml */}
        <Text>pages/invalid/invalid.wxml</Text>
      </Block>;
  }
} // pages/invalid/invalid.js

export default _C;