import Taro from '@tarojs/taro-h5';
import { Block, View, ScrollView, Image, Text } from '@tarojs/components';
import Nerv from "nervjs";
import withWeapp from '@tarojs/with-weapp';
import './userHelp.scss';
//index.js
//获取应用实例
const app = Taro.getApp();

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    mobile: Taro.getApp().globalData.mobile,
    motto: 'Hello World',
    help_imgurl: 'https://apph5.mmcqing.com/xcx/images/help-zfb.png?time=' + Math.random() * 10,
    userInfo: {},
    hasUserInfo: false,
    canIUse: Taro.canIUse('button.open-type.getUserInfo')
  };
  bindViewTap = () => {
    Taro.navigateTo({
      url: '../logs/logs'
    });
  };

  componentWillMount() {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      });
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        });
      };
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      Taro.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo;
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          });
        }
      });
    }
  }

  getUserInfo = e => {
    console.log(e);
    app.globalData.userInfo = e.detail.userInfo;
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    });
  };
  goOnlineExp = () => {
    Taro.navigateTo({
      url: '/pages/onlineExp/onlineExpMain/onlineExpMain'
    });
  };
  telCall = () => {
    Taro.makePhoneCall({
      phoneNumber: this.data.mobile
    });
  };
  config = {
    navigationBarTitleText: '使用帮助'
  };

  render() {
    const { help_imgurl: help_imgurl, mobile: mobile } = this.state;
    return <Block>
        {/* index.wxml */}
        <View className="container">
          <ScrollView scrollY>
            <View className="top-view">
              <Image className="image" src={help_imgurl} />
            </View>
            <View className="bind-view">
              <Image src="https://apph5.mmcqing.com/xcx/images/help-bg-2.png" className="image" />
              <Text>
                请您在收到挪车贴后，第一时间绑定车辆，绑定后即可开始使用。
              </Text>
            </View>
            <View className="step-view">
              <Image src="https://apph5.mmcqing.com/xcx/images/help-bg-7.png" />
            </View>
            <View className="main-container">
              <View className="list-view">
                <View className="flex-row">
                  <View className="li">
                    <Image className="li-image" src="https://apph5.mmcqing.com/xcx/images/jieshao-icon1.png" />
                    <Text className="t">隐私保护</Text>
                    <Text className="c">匿名打电话</Text>
                    <Text className="c">信息无泄漏</Text>
                  </View>
                  <View className="li">
                    <Image className="li-image" src="https://apph5.mmcqing.com/xcx/images/jieshao-icon2.png" />
                    <Text className="t">快速便捷</Text>
                    <Text className="c">微信扫码</Text>
                    <Text className="c">一键通知挪车</Text>
                  </View>
                  <View className="li">
                    <Image className="li-image" src="https://apph5.mmcqing.com/xcx/images/jieshao-icon3.png" />
                    <Text className="t">多管齐下</Text>
                    <Text className="c">电话短信推送</Text>
                    <Text className="c">多通道速达</Text>
                  </View>
                </View>
              </View>
              <View className="copy-view">
                <Text className="c">本服务由和路宝提供</Text>
                <View className="c">
                  客服电话：
                  <View onClick={this.telCall} className="tel">
                    <Text>{mobile}</Text>
                  </View>
                </View>
              </View>
            </View>
          </ScrollView>
        </View>
      </Block>;
  }

  componentDidMount() {}

  componentDidShow() {}

}

export default _C;