import Taro from '@tarojs/taro-h5';
import { Block, View, ScrollView, Image, Text } from '@tarojs/components';
import Nerv from "nervjs";
import withWeapp from '@tarojs/with-weapp';
import './comQAQ.scss';
//index.js
//获取应用实例
const app = Taro.getApp();

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    mobile: Taro.getApp().globalData.mobile
  };

  componentWillMount() {}

  telCall = () => {
    Taro.makePhoneCall({
      phoneNumber: this.data.mobile
    });
  };
  config = {
    navigationBarTitleText: '常见问题'
  };

  render() {
    const { mobile: mobile } = this.state;
    return <Block>
        {/* index.wxml */}
        <View className="container">
          <ScrollView scrollY>
            <View className="top-view">
              <Image className="image" src="https://apph5.mmcqing.com/xcx/images/qaq-top-bg.png" />
              <View className="t">
                <Text>常见问题</Text>
              </View>
            </View>
            <View className="list-panel">
              <View className="list-view">
                <View className="t-view">
                  <Image className="image" src="https://apph5.mmcqing.com/xcx/images/qaq-list-t.png" />
                  <View className="t">
                    <Text>Q1: 在线体验的生成的码和寄出的码是不是同一个？</Text>
                  </View>
                </View>
                <View className="c-view">
                  <Text>
                    不是，在线体验生成的码仅限于线上体验和打印使用，寄
                    出的码是全新的空码，到手之后需要使用微信重新扫码绑 定。
                  </Text>
                </View>
              </View>
              <View className="list-view">
                <View className="t-view">
                  <Image className="image" src="https://apph5.mmcqing.com/xcx/images/qaq-list-t.png" />
                  <View className="t">
                    <Text>Q2: 申请之后多久发货？</Text>
                  </View>
                </View>
                <View className="c-view">
                  <Text>
                    工作日申请后第二天发货，周末及节假日申请后在下一个工作日发出。
                  </Text>
                </View>
              </View>
              <View className="list-view">
                <View className="t-view">
                  <Image className="image" src="https://apph5.mmcqing.com/xcx/images/qaq-list-t.png" />
                  <View className="t">
                    <Text>Q3: 发货之后怎么查看我的物流信息？</Text>
                  </View>
                </View>
                <View className="c-view">
                  <Text>
                    发货之后我们会发送一条包含快递单号的短信，也可以在微信“和路宝”小程序，在“我的订单”里查看快递单号，您可以使用搜索引擎搜索查看物流信息。
                  </Text>
                </View>
              </View>
              <View className="list-view">
                <View className="t-view">
                  <Image className="image" src="https://apph5.mmcqing.com/xcx/images/qaq-list-t.png" />
                  <View className="t">
                    <Text>Q4: 快递一直没有收到怎么办？</Text>
                  </View>
                </View>
                <View className="c-view">
                  <Text>
                    物流信息由和路宝委托第三方物流公司寄出，如出现物流问题可致电物流客服询问，如没有回应则可以致电和路宝客服咨询。
                  </Text>
                </View>
              </View>
              <View className="list-view">
                <View className="t-view">
                  <Image className="image" src="https://apph5.mmcqing.com/xcx/images/qaq-list-t.png" />
                  <View className="t">
                    <Text>Q5: 挪车码收到后怎么用？</Text>
                  </View>
                </View>
                <View className="c-view">
                  <Text>
                    您将收到精美挪车贴一张，收货后需要使用车主本人微信扫码绑定联络手机号和车牌号，绑定后挪车贴可贴在挡风玻璃四角或后方玻璃内侧使用。
                  </Text>
                </View>
              </View>
              <View className="list-view">
                <View className="t-view">
                  <Image className="image" src="https://apph5.mmcqing.com/xcx/images/qaq-list-t.png" />
                  <View className="t">
                    <Text>
                      Q6: 挪车贴粘贴后可以移动吗？会不会留下胶水痕迹？
                    </Text>
                  </View>
                </View>
                <View className="c-view">
                  <Text>
                    车贴在粘贴后可揭下重复粘贴使用，不会残留胶水印记。
                  </Text>
                </View>
              </View>
              <View className="list-view">
                <View className="t-view">
                  <Image className="image" src="https://apph5.mmcqing.com/xcx/images/qaq-list-t.png" />
                  <View className="t">
                    <Text>
                      Q7: 绑定信息可以修改吗？如果不想用了可不可以解绑？
                    </Text>
                  </View>
                </View>
                <View className="c-view">
                  <Text>
                    绑定信息可由开启该车帖的微信账号扫码修改且不限次数，若挪车码物料发生破损或其它情况导致无法使用，车主可破坏挪车二维码保证其无法扫码后再丢弃，也可致电客服要求我方工作人员解绑。
                  </Text>
                </View>
              </View>
              <View className="list-view">
                <View className="t-view">
                  <Image className="image" src="https://apph5.mmcqing.com/xcx/images/qaq-list-t.png" />
                  <View className="t">
                    <Text>Q8: 使用中会不会产生额外费用？</Text>
                  </View>
                </View>
                <View className="c-view">
                  <Text>
                    挪车码在使用过程中没有额外费用，仅会在拨叫过程中产生拨叫本人通话资费标准的市话费。
                  </Text>
                </View>
              </View>
            </View>
            <View className="copy-view">
              <Text className="c">本服务由和路宝提供</Text>
              <View className="c">
                客服电话：
                <View onClick={this.telCall} className="tel">
                  <Text>{mobile}</Text>
                </View>
              </View>
            </View>
          </ScrollView>
        </View>
      </Block>;
  }

  componentDidMount() {}

  componentDidShow() {}

}

export default _C;