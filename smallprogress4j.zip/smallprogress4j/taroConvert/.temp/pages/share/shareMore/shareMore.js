import Taro from '@tarojs/taro-h5';
import { Block, View, Text, Image, Button } from '@tarojs/components';
import Nerv from "nervjs";
import withWeapp from '@tarojs/with-weapp';
//index.js
//获取应用实例
const app = Taro.getApp();
import { Network, Api } from "../../../utils/index";
import './shareMore.scss';

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    showShare: false,
    inviteNum: 0,
    userId: '',
    inviteBoList: [],
    canConvert: 0,
    yetConvert: 0,
    // isScroll: true,
    showLoading: false,
    offset: 0,
    limit: 5
  };
  onShareAppMessage = obj => {
    if (obj.from === 'button') {
      return {
        title: '邀请好友，免费领取挪车贴！',
        path: `/pages/index/index?recommenduserid=${this.data.userId}`,
        imageUrl: '/static/images/share-icon.png',
        success(res) {
          // 转发成功之后的回调

          if (res.errMsg == 'shareAppMessage:ok') {
            //   wx.showToast({
            //       title: '分享成功',
            //       icon: "none"
            //   })
          }
        },
        fail(res) {
          // 转发失败之后的回调
          if (res.errMsg == 'shareAppMessage:cancel') {
            // 用户取消转发
            Taro.showToast({
              title: '转发取消',
              icon: 'none'
            });
          } else if (res.errMsg == 'shareAppMessage:fail') {
            // 转发失败，其中 detail message 为详细失败信息
            console.log(res.detail);
            Taro.showToast({
              title: '转发失败',
              icon: 'none'
            });
          }
        },
        complete(res) {
          // 转发结束之后的回调（转发成不成功都会执行）
        }
      };
    }
  };
  stopProp = e => {};
  getUserId = () => {
    Network.get(Api.USER_ID, {}, data => {
      // console.log(data);
      if (data.code === 200) {
        this.setData({ userId: data.data.userid || '' });
      }
    });
  };
  loadMore = () => {};

  componentWillMount() {
    this.getShareMore();
    this.getUserId();
  }

  getShareMore = () => {
    Network.post(Api.VIEW_MORE, {
      params: {
        offset: this.data.offset,
        limit: this.data.limit
      },
      loading: false
    }, data => {
      console.log(data);
      if (data.code === 200) {
        let retData = data.data.inviteBoList || [];
        this.setData({
          inviteBoList: [...this.data.inviteBoList, ...(data.data.inviteBoList || [])],
          canConvert: data.data.canConvert || 0,
          yetConvert: data.data.yetConvert || 0,
          inviteNum: data.data.inviteNum || 0
        });
        if (retData.length < this.data.limit) {
          // 不足一页了
          this.setData({ showLoading: false });
        } else if (retData.length == this.data.limit && data.data.inviteNum == (this.data.inviteBoList || []).length) {
          this.setData({ showLoading: false });
        } else {
          this.setData({
            showLoading: true,
            offset: this.data.offset + this.data.limit
          });
        }
      }
    });
  };
  shareCancel = () => {
    this.setData({
      showShare: false
      // isScroll: true
    });
  };
  openShare = () => {
    this.setData({ showShare: true });
  };
  config = {};

  render() {
    const {
      canConvert: canConvert,
      yetConvert: yetConvert,
      inviteNum: inviteNum,
      inviteBoList: inviteBoList,
      showLoading: showLoading,
      showShare: showShare
    } = this.state;
    return <Block>
        {/*  <scroll-view scroll-y="{{isScroll}}">  */}
        <View className="container">
          <View className="main-container">
            <View className="charge-view box-shadow">
              <View className="li-view">
                <View className="num">
                  {canConvert}
                  <Text className="i">张</Text>
                </View>
                <View className="desc">可兑换挪车贴</View>
              </View>
              <View className="li-view">
                <View className="num">
                  {yetConvert}
                  <Text className="i">张</Text>
                </View>
                <View className="desc">已兑换挪车贴</View>
              </View>
            </View>
            <View className="share-view">
              <View className="share-title">
                {'我的邀请（' + inviteNum + '）人'}
              </View>
              <Image className="img-header" src="https://apph5.mmcqing.com/xcx/images/share-bg-h.png" />
              <View className="share-content">
                <View className="list-content">
                  {inviteBoList.map((item, index) => {
                  return <View className="li" key="unique">
                        <Text className="tel">{item.phoneNum}</Text>
                        <Text className="date">{item.inviteTime}</Text>
                      </View>;
                })}
                </View>
                {showLoading ? <View className="loadMore" onClick={this.getShareMore}>
                    加载更多
                  </View> : <View className="loadMore" />}
                <View className="btn-apply" onClick={this.openShare}>
                  立即邀请
                </View>
              </View>
              <Image className="img-footer" src="https://apph5.mmcqing.com/xcx/images/share-bg-b.png" />
            </View>
          </View>
        </View>
        {/*  </scroll-view>  */}
        {showShare && <View className="share-popup" onTouchMove={this.stopProp}>
            <View className="share-content">
              <View className="img-view">
                <Image className="shake" src="https://apph5.mmcqing.com/xcx/images/share-shake.png" />
                <Image className="image" src="https://apph5.mmcqing.com/xcx/images/share-popup.png" mode="widthFix" />
              </View>
              <View className="share-btn">
                <View className="cancel" onClick={this.shareCancel}>
                  取消
                </View>
                <Button className="share" openType="share">
                  立即分享
                </Button>
              </View>
            </View>
          </View>}
      </Block>;
  }

  componentDidMount() {}

  componentDidShow() {}

}

export default _C;