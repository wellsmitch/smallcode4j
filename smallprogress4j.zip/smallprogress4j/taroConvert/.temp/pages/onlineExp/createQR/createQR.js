import Taro from '@tarojs/taro-h5';
import { View, Image, Text, Canvas } from '@tarojs/components';
import Nerv from "nervjs";
import withWeapp from '@tarojs/with-weapp';
import './createQR.scss';
//index.js
//获取应用实例
// import Utils from '../../../utils/index'
const app = Taro.getApp();

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    mobile: Taro.getApp().globalData.mobile,
    qrUrl: 'https://apph5.mmcqing.com/xcx/images/buy-qr.png',
    openSet: false
  };

  componentWillMount(options) {
    this.setData({ qrUrl: '' });
    console.log(options.imgUrl);
    if (options.imgUrl) {
      console.log(options.imgUrl);
      this.setData({ qrUrl: options.imgUrl });
    }
    // canvas 画图
    var query = Taro.createSelectorQuery();
    //选择id
    var that = this;
    const ctx = Taro.createCanvasContext('share');
    let width, height;
    // wx.getImageInfo({
    //     src: that.data.qrUrl,    //请求的网络图片路径
    //     success: function (res) {
    //         console.log(res)
    //         //请求成功后将会生成一个本地路径即res.path,然后将该路径缓存到storageKeyUrl关键字中
    //         that.setData({
    //             qrUrl: res.path
    //         })
    //         imgcanvas()
    //     },
    //     fail() {
    //         wx.showToast({
    //             title: '二维码加载失败',
    //             icon: "none"
    //         })
    //         imgcanvas()
    //     }

    // })
    function imgcanvas() {
      query.select('.bg').boundingClientRect(function (rect) {
        width = rect.width;
        height = rect.height;
        ctx.drawImage('https://apph5.mmcqing.com/xcx/images/buy-qr.png', 0, 0, rect.width, rect.height);
      }).exec();
      let w = 0,
          h = 0;
      query.select('.picBox').boundingClientRect(function (rect) {
        console.log(that.data.qrUrl);
        w = rect.width;
        h = rect.height;
        // ctx.drawImage(that.data.qrUrl, width / 2 - rect.width / 2, height / 2 - rect.height / 2, rect.width, rect.height)
        // ctx.draw()
        // ctx.restore();
      }).exec();
      query.select('.pic').boundingClientRect(function (rects) {
        console.log(that.data.qrUrl);
        ctx.drawImage(that.data.qrUrl, width / 2 - w / 2, height / 2 - h / 2, rects.width, rects.height);
        ctx.draw();
      }).exec();
    }
  }

  storePic = () => {
    let that = this;
    Taro.getSetting({
      success: response => {
        if (!response.authSetting['scope.writePhotosAlbum']) {
          Taro.authorize({
            scope: 'scope.writePhotosAlbum',
            success: res => {
              console.log(res);
              that.imgDownload();
            },
            fail() {
              that.setData({
                openSet: true
              });
            }
          });
        } else {
          that.setData({
            openSet: false
          });
          this.imgDownload();
        }
      }
    });
  };
  imgDownload = () => {
    Taro.showLoading({
      title: '加载中...'
    });
    Taro.canvasToTempFilePath({
      canvasId: 'share',
      success: function (res) {
        console.log(res);
        Taro.hideLoading();
        Taro.getImageInfo({
          src: res.tempFilePath,
          success: function (ret) {
            //console.log(ret)
            var path = ret.path;
            // console.log(path)
            Taro.saveImageToPhotosAlbum({
              filePath: path,
              success(result) {
                //console.log(result)
                Taro.showToast({
                  title: '保存成功',
                  icon: 'none'
                });
              }
            });
          }
        });
      }
    });
  };
  telCall = () => {
    Taro.makePhoneCall({
      phoneNumber: this.data.mobile
    });
  };
  goToPage(val) {
    my.redirectTo({
      url: val
    });
  }
  config = {};

  render() {
    const { qrUrl: qrUrl, mobile: mobile } = this.state;
    return <View className="container">
        <View className="top-view">
          <Image className="image" src="https://apph5.mmcqing.com/xcx/images/buy-suc-bg.png" />
          <View className="text-view">
            <View className="t-view">
              <Text>挪车体验码</Text>
            </View>
            <View className="s-view">
              <Text>注：此挪车码仅做为挪车体验使用</Text>
            </View>
            <View className="suc-image">
              <Canvas canvasId="share" className="canvas_img" style="width:100%; height:100%" />
              <Image className="bg" src="https://apph5.mmcqing.com/xcx/images/suc-nct.png" />
              <View className="picBox">
                <Image className="pic" mode src={qrUrl} />
              </View>
            </View>
          </View>
        </View>
        <View className="main-container">
          {/* <Navigator url="/pages/buyProgress/buyMain/buyMain"> */}
            <View onClick={() => this.goToPage('/pages/buyProgress/buyMain/buyMain')} className="btn-apply" hoverClass="btn-applyhover">
              <Text>立即申购</Text>
            </View>
          {/* </Navigator> */}
          {/*  <view class="store-pic">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          <button open-type='openSetting' bindtap="storePic" wx:if="{{openSet}}" >保存相册</button>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          <button bindtap="storePic" wx:if="{{!openSet}}">保存相册</button>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      </view>  */}
        </View>
        <View className="copy-view">
          <Text className="c">本服务由和路宝提供</Text>
          <View className="c">
            客服电话：
            <View onClick={this.telCall} className="tel">
              <Text>{mobile}</Text>
            </View>
          </View>
        </View>
      </View>;
  }

  componentDidMount() {}

  componentDidShow() {}

}

export default _C;