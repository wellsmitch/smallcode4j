import Taro from '@tarojs/taro-h5';
import { Block, View, Image, Text, Navigator } from '@tarojs/components';
import Nerv, { Config } from "nervjs";
import withWeapp from '@tarojs/with-weapp';
//index.js
//获取应用实例
import { Api, Network } from "../../utils/index";
import './userCenter.scss';
const app = Taro.getApp();

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    mobile: Taro.getApp().globalData.mobile,
    orderNum: '0',
    ewmNum: '0',
    userInfo: '',
    canIUse: Taro.canIUse('button.open-type.getUserInfo')
  };

  componentWillMount() {
    my.setNavigationBar({
      title: '扫码挪车'
    });
    this.cewmInfoGet();
    // console.log(app.globalData);
    if (app.globalData.userInfo) {
      // console.log('test');
      this.setData({
        userInfo: app.globalData.userInfo
      });
    }
  }

  goMoveCarRecord = () => {
    Taro.navigateTo({
      url: '/pages/buyProgress/moveQRList/moveQRList'
    });
  };
  cewmInfoGet = () => {
    Network.post(Api.CEWM_INFO, {
      params: {}
    }, res => {
      console.log(res);
      if (res.code === 200) {
        this.setData({
          orderNum: res.data.total_order_num,
          ewmNum: res.data.total_ewm_num
        });
      }
    });
  };
  goOrderRecord = () => {
    Taro.navigateTo({
      url: '/pages/buyProgress/buyRecord/buyRecord'
    });
  };
  goToPage(val) {
    if (Taro.getApp().globalData.token) {
      my.navigateTo({
        url: val
      });
    } else {
      Taro.getApp().globalData.goToUrl = val;
      Taro.redirectTo({
        url: '/pages/login/login'
      });
    }
  }
  telCall = () => {
    Taro.makePhoneCall({
      phoneNumber: this.data.mobile
    });
  };
  toIndex = () => {
    my.reLaunch({
      url: '/pages/index/index'
    });
    // Taro.redirectTo({
    //   url: '/pages/index/index'
    // })
    // wx.navigateTo({
    //   url: '/pages/index/index'
    // })
  };
  config = {};

  render() {
    let avatarImg = this.state.userInfo.avatar;
    const { orderNum: orderNum, ewmNum: ewmNum, mobile: mobile } = this.state;
    return <Block>
        {/* index.wxml */}
        <View className="container">
          <View>
            <View className="pic-view">
              <Image className="image" src="https://apph5.mmcqing.com/xcx/images/center-bg-pic.png" />
              <View className="info-view">
                <View className="icon-image">
                  {/* <OpenData className="pic" type="userAvatarUrl" /> */}
                   <Image className="pic" src={avatarImg} />
                </View>
                <View className="info-main-view">
                  {/* <View className="t-name">
                    <Text>您好！</Text>
                    <OpenData
                      className="usname"
                      type="userNickName"
                      lang="zh_CN"
                    />
                   </View> */}
                   <View className="t-name"><Text>您好！ {this.state.userInfo.nickName}</Text></View> 
                  <View className="t-desc">
                    <Text>感谢使用立码挪车，以下为您的相关信息</Text>
                  </View>
                  <View className="order-view">
                    <View className="order-flex r-line" onClick={() => this.goToPage('/pages/buyProgress/buyRecord/buyRecord')}>
                      <View className="blue-num">
                        <Text>{orderNum}</Text>
                      </View>
                      <View>
                        <Text>订单/笔</Text>
                      </View>
                    </View>
                    <View className="order-flex" onClick={() => this.goToPage('/pages/buyProgress/moveQRList/moveQRList')}>
                      <View className="blue-num">
                        <Text>{ewmNum}</Text>
                      </View>
                      <View>
                        <Text>挪车码/张</Text>
                      </View>
                    </View>
                  </View>
                </View>
              </View>
            </View>
            <View className="share-view mt50">
              {/*  <view class="share-bg-view">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       <navigator url="/pages/share/mainIndex/mainIndex"  class="jump" hover-class="navigator-hover">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       </navigator>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       <image class="img" src="https://apph5.mmcqing.com/xcx/images/share-bg.png" mode="widthFix"></image>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     </view>  */}
              <View className="Q-help-view">
                {/*  <image class="Q-help-image" src="https://apph5.mmcqing.com/xcx/images/center-bg-2.png"></image>  */}
                <View className="rel">
                  <Navigator url="/pages/doc/comQAQ/comQAQ">
                    <View className="QAQ flex_hm">
                      <Text className="flex1">常 见 问 题</Text>
                      <Image className="Q-IMAGE" src="https://apph5.mmcqing.com/xcx/images/center-r-more.png" />
                    </View>
                  </Navigator>
                  <Navigator url="/pages/doc/userHelp/userHelp">
                    <View className="flex_hm">
                      <Text className="flex1">使 用 帮 助</Text>
                      <Image className="Q-IMAGE" src="https://apph5.mmcqing.com/xcx/images/center-r-more.png" />
                    </View>
                  </Navigator>
                </View>
              </View>
            </View>
          </View>
          <View className="main-container">
            <View className="copy-view">
              <Text className="c">本服务由和路宝提供</Text>
              <View className="c">
                客服电话：
                <View onClick={this.telCall} className="tel">
                  <Text>{mobile}</Text>
                </View>
              </View>
            </View>
          </View>
        </View>
        <View className="menu-footer">
          <View className="index flex_hm flex_hc  flex_v" onClick={this.toIndex}>
            <Image className="image" src="https://apph5.mmcqing.com/xcx/images/tab-1-02.png" />
            <View>
              <Text>挪 车 码</Text>
            </View>
          </View>
          <View className="center cur flex_hm flex_hc flex_v">
            <Image className="image" src="https://apph5.mmcqing.com/xcx/images/tab-1-03.png" />
            <View>
              <Text>我 的</Text>
            </View>
          </View>
        </View>
      </Block>;
  }

  componentDidMount() {}

  componentDidShow() {}

}

export default _C;