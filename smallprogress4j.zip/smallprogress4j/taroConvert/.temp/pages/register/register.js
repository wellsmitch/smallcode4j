import Taro from '@tarojs/taro-h5';

import Nerv from "nervjs";
import withWeapp from '@tarojs/with-weapp';


//index.js
//获取应用实例
// var WXBizDataCrypt = require('../../utils/WXBizDataCrypt')

import './register.scss';
const app = Taro.getApp();

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    token: '',
    msg_code: '',
    phone: ''
  };

  componentWillMount(options) {
    // let _page = getCurrentPages();
    // let _prevPage = _page[_page.length - 2];
    // _prevPage.setData({})
    this.setData({ phone: options.phoneNum });
  }

  register = () => {};
  config = {};

  render() {
    return null;
  }

  componentDidMount() {}

  componentDidShow() {}

}

export default _C;