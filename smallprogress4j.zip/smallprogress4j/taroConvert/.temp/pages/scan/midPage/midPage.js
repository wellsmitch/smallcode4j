import Taro from '@tarojs/taro-h5';
import { View } from '@tarojs/components';
import Nerv from "nervjs";
import withWeapp from '@tarojs/with-weapp';
//index.js
//获取应用实例
import { Api, Network } from "../../../utils/index";
import './midPage.scss';

const app = Taro.getApp();

@withWeapp('Page')
class _C extends Taro.Component {
  state = {};
  request = options => {
    let _sendInfo = 'p=' + Taro.getApp().globalData.optionsUrl;

    // _sendInfo ='p=olgO6EaK_1';
    // _sendInfo = 'p=CTR5dkfr_1'
    // _sendInfo = 'p=VMu6uh8k_1';
    // _sendInfo = "p=olgO6EaK_1";
    // _sendInfo = "p=KEpssmVs_1";
    Network.get(`${Api.PARE_WM}?${_sendInfo}`, { loading: false }, res => {
      Taro.hideLoading();
      if (res.data && res.data.code === 200) {
        let _ret = res.data.data;
        switch (_ret.resPage) {
          case '0':
            // 详情页
            let param = res.data.data || {};
            Taro.redirectTo({
              url: '/pages/scan/usedQR/usedQR?param=' + JSON.stringify(param)
            });
            break; // 修改
          case '1':
            //
            let cparam = {
              carNum: _ret.carNum,
              phone: _ret.phone,
              id: _ret.id,
              type: 1
            };
            Taro.redirectTo({
              url: '/pages/scan/modifyQR/modifyQR?param=' + JSON.stringify(cparam)
            });
            break;
          case '2':
            // 绑定
            Taro.redirectTo({
              url: '/pages/scan/bindQR/bindQR?id=' + _ret.id
            });
            break;
          case '3':
            // 绑定
            Taro.redirectTo({
              url: '/pages/onlineExp/createQR/createQR?imgUrl=' + _ret.car_pic_url
            });
            break;
          case '4':
            // 绑定
            let params = res.data.data || {};
            Taro.redirectTo({
              url: '/pages/scan/usedQR/usedQR?param=' + JSON.stringify(params)
            });
            break;
          case '5':
            // 绑定
            Taro.redirectTo({
              url: '/pages/onlineExp/createQR/createQR?imgUrl=' + _ret.car_pic_url
            });
            break;
        }
      }
    });
  };

  componentWillMount(options) {

    Taro.showLoading({
      title: '加载中...',
      mask: true
    });
    let count = 0;
    let timer = setInterval(() => {
      if (app.globalData.token) {
        this.request(options);
        clearInterval(timer);
      }
      if (app.globalData.notoken) {
        this.request(options);
        clearInterval(timer);
      }
      count++;
      if (count === 20) {
        this.request(options);
        clearInterval(timer);
      }
    }, 150);
  }

  config = {};

  render() {
    return <View className="container" />;
  }

  componentDidMount() {}

  componentDidShow() {}

}

export default _C;