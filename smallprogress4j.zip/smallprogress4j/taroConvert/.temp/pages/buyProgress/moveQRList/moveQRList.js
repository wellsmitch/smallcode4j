import Taro from '@tarojs/taro-h5';
import { View, ScrollView, Image, Text } from '@tarojs/components';
import Nerv from "nervjs";
import withWeapp from '@tarojs/with-weapp';
//index.js
//获取应用实例
import { Api, Network } from "../../../utils/index";
import './moveQRList.scss';
const app = Taro.getApp();

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    mobile: Taro.getApp().globalData.mobile,
    moveList: [],
    nodata: false,
    statusWitch: {
      '0': '体验码',
      '1': '挪车码'
    }
  };

  componentWillMount() {
    this.orderListGet();
  }

  orderListGet = () => {
    Network.post(Api.EWM_DETAIL, {
      params: {
        type: 1
      }
    }, res => {
      if (res.code === 200) {
        console.log(res);
        let nodata = res.data.movecarList.length < 1 ? true : false;
        this.setData({
          moveList: res.data.movecarList.map(item => {
            return item;
          }),
          nodata: nodata
        });
      }
    });
  };
  goDetail = e => {
    let _index = e.currentTarget.dataset.inde;
    let _data = this.data.moveList[e.currentTarget.dataset.index];

    if (_data.type === '0') {

      Taro.getApp().globalData.cameUrl = `/pages/onlineExp/createQR/createQR?imgUrl=${_data.ewm_pic_url}`;
      Taro.navigateTo({
        url: `/pages/onlineExp/createQR/createQR?imgUrl=${_data.ewm_pic_url}`
      });
    }
    if (_data.type === '1') {
      Taro.getApp().globalData.cameUrl = `/pages/scan/modifyQR/modifyQR?param=${JSON.stringify(_data)}`;
      Taro.navigateTo({
        url: `/pages/scan/modifyQR/modifyQR?param=${JSON.stringify(_data)}`
      });
    }
  };
  telCall = () => {
    Taro.makePhoneCall({
      phoneNumber: this.data.mobile
    });
  };
  config = {};

  render() {
    const { moveList: moveList, nodata: nodata, mobile: mobile } = this.state;
    return <View className="container">
        <ScrollView className="scrollView" scrollY>
          <View className="main-container">
            {moveList.length > 0 && <View className="list-view">
                {moveList.map((move, index) => {
              return <View className="li-view" key="unique" onClick={this.goDetail} data-index={index}>
                      <Image src={move.ewm_pic_url} className="left-qr" />
                      <View className="right-text">
                        <View>
                          {move.type === '0' ? <Text className="type">体验码</Text> : <Text className="type type-ncx">挪车码</Text>}
                          {move.carNum}
                        </View>
                        <View>{'绑定手机号： ' + move.phone}</View>
                      </View>
                    </View>;
            })}
              </View>}
            {moveList.length < 1 && <View className="flex_hm flex_hc flex_v nodataBox">
                <Image className="nodata" mode="widthFix" src="https://apph5.mmcqing.com/xcx/images/nodata.png" />
                <Text className="nodata_text">暂无记录</Text>
              </View>}
            <View className="copy-view">
              <Text className="c">本服务由和路宝提供</Text>
              <View className="c">
                客服电话：
                <View onClick={this.telCall} className="tel">
                  <Text>{mobile}</Text>
                </View>
              </View>
            </View>
          </View>
        </ScrollView>
      </View>;
  }

  componentDidMount() {}

  componentDidShow() {}

}

export default _C;