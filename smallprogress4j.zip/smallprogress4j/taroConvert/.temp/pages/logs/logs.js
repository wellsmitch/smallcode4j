import Taro from '@tarojs/taro-h5';
import { Block, View, Text } from '@tarojs/components';
import Nerv from "nervjs";
import withWeapp from '@tarojs/with-weapp';
import './logs.scss';
//logs.js
// import Utils from '../../utils/index'
const app = Taro.getApp();

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    logs: []
  };

  componentWillMount() {
    // console.log(Utils);
    // this.setData({
    //   logs: (wx.getStorageSync('logs') || []).map(log => {
    //     return util.formatTime(new Date(log))
    //   })
    // })
  }

  config = {
    navigationBarTitleText: '查看启动日志'
  };

  render() {
    const { logs: logs } = this.state;
    return <Block>
        {/* logs.wxml */}
        <View className="container log-list">
          {logs.map((log, index) => {
          return <Block>
                <Text className="log-item">{index + 1 + '. ' + log}</Text>
              </Block>;
        })}
        </View>
      </Block>;
  }

  componentDidMount() {}

  componentDidShow() {}

}

export default _C;