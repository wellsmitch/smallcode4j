import Taro from '@tarojs/taro-h5';
import Nerv from "nervjs";
// let _token;
// try {
//   _token = wx.getStorageSync('TOKEN')
// } catch (e) {
//   // Do something when catch error
// }
const Network = {
  post: (url, opts, sucCb, errorCb) => {
    if (opts.loading) {
      Taro.showLoading({
        title: '加载中...',
        mask: true
      });
    }
    var optaions = {};
    if (!!opts.params.params) {
      optaions = opts.params;
      optaions.params = JSON.parse(optaions.params);
      if (!!!optaions.params.source) {
        optaions.params.source = '4';
      }
      optaions.params = JSON.stringify(optaions.params);
    } else {
      if (!!!opts.params.source) {
        opts.params.source = '4';
      }
      optaions = opts.params;
      if (url.indexOf('pay/all/create/order') > -1) {
        delete opts.params.source;
      }
    }
    console.log('optaions');
    console.log(optaions);
    let _param = {
      url: url,
      data: optaions,
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        token: Taro.getApp().globalData.token
      },
      success: res => {
        sucCb && sucCb(res.data);
      },
      fail: res => {
        if (errorCb) {
          errorCb && errorCb(res.data);
        } else {
          Taro.showToast({
            title: '服务器繁忙！请稍后重试',
            icon: 'none'
          });
        }
      },
      complete: () => {
        if (opts.loading) {
          Taro.hideLoading();
        }
      }
    };
    if (opts.tokenNone) {
      // 不需要token
      delete _param.header.token;
    } else {
      let _token = Taro.getStorageSync('TOKEN');
      if (_token) {
        _param.header['token'] = _token;
      }
    }
    Taro.request(_param);
  },
  get: (url, opts, sucCb, errorCb) => {
    if (opts.loading) {
      Taro.showLoading();
    }
    let _param = {
      url: url,
      // data: params,
      method: 'GET',
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        token: Taro.getApp().globalData.token
      },
      success: res => {
        sucCb && sucCb(res);
      },
      fail: res => {
        if (errorCb) {
          errorCb && errorCb(res);
        } else {
          Taro.showToast({
            title: '网络异常',
            icon: 'none'
          });
        }
      },
      complete: () => {
        if (opts.loading) {
          Taro.hideLoading();
        }
      }
    };
    if (opts.tokenNone) {
      // 不需要token
      delete _param.header.token;
    } else {
      let _token = Taro.getStorageSync('TOKEN');
      if (_token) {
        _param.header['token'] = _token;
      }
    }
    Taro.request(_param);
  }
};
export default Network;