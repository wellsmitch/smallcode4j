let _prefix = 'https://www.mmcqing.com:18089/';
// let _prefix = 'https://www.mmcqing.com:8083';
const Api = {
  HTTPS: _prefix,
  FULL_USER_INFO: "https://www.mmcqing.com:18089/api/thirdparty/xcx/user", // 用户信息补全
  INTERFACE_TEST: "https://www.mmcqing.com:18089/test",
  openId: "https://www.mmcqing.com:18089/api/thirdparty/wx/xcx/openid", //获取openid;
  DYNAMIC_PRICE: "https://www.mmcqing.com:18089/api/movecar/unitPrice", // 动态获取车贴价格
  MOVE_CAR_CEWM: "https://www.mmcqing.com:18089/api/movecar/cewm", // 体验码申请
  RULE_CARD_INFO: "https://www.mmcqing.com:18089/api/v3/rule/carInfo", // 城市简称集合
  EWM_DETAIL: "https://www.mmcqing.com:18089/api/movecar/ewmdetail", // 订单或挪车码列表
  C_ORDER: "https://www.mmcqing.com:18089/api/movecar/cOrder", // 购买下单
  BIND_EWM: "https://www.mmcqing.com:18089/api/movecar/bindewm", // 绑挪车码
  CEWM_INFO: "https://www.mmcqing.com:18089/api/movecar/cewminfo", // 我的订单，挪车码的数量统计
  XCX_PAY: "https://www.mmcqing.com:18089/api/pay/all/create/order", // 小程序统一支付
  UPDATE_BIND_EWM: "https://www.mmcqing.com:18089/api/movecar/updateEwm", // 更改绑定车贴
  AUTH_LOGIN: "https://www.mmcqing.com:18089/api/thirdparty/login", // 授权登录
  AUTH_BIND: "https://www.mmcqing.com:18089/api/thirdparty/bind", // 授权绑定接口
  PARE_WM: "https://www.mmcqing.com:18089/api/xcx/parewm", // 判断扫码跳转
  PHONE_NUMBER_GET: "https://www.mmcqing.com:18089/api/thirdparty/phone", // 手机号解析
  SMS_GET: "https://www.mmcqing.com:18089/api/oauth/sms/bind", // 发送短信接口
  HOME_RESOURCES: "https://www.mmcqing.com:18089/api/v3/xcx/h5/resources", //首页功能接口
  SMS_MESSAGE: "https://www.mmcqing.com:18089/api/push/message", //发送短信通知车主挪车
  CLOUD_MIRROR: "https://www.mmcqing.com:18089/api/v1/cloud-mirror/", //绑定设备接口
  IMG_EXAMPLE: "https://www.mmcqing.com:18089/api/v1/video/queryTransgressCodeList", //图片示例接口
  INVITE_COUNT: "https://www.mmcqing.com:18089/api/movecar/inviteCount", // 统计用户邀请好友数 和展示详情
  USER_ID: "https://www.mmcqing.com:18089/api/v3/user/token/user", // 查看用戶的userid
  CAN_CONVERT: "https://www.mmcqing.com:18089/api/movecar/canConvert", // 可兑换车贴数量
  VIEW_MORE: "https://www.mmcqing.com:18089/api/movecar/viewMore", // 查看更多分享好友
  TELL_BIND: "https://www.mmcqing.com:18089/api/new/third/tell/bind", // 电话拨打/new/third/tell/bind
  APPOINTMENT_CONVERT: "https://www.mmcqing.com:18089/api/movecar/convert", // 免费兑换接口
  MESSAGE_INFO: "https://www.mmcqing.com:18089/api/movecar/push/message",
  GET_MOBILE_SMS: "https://www.mmcqing.com:18089/api/mobile/dsms", // 获取短信验证码（新的）
  lpr: "https://www.mmcqing.com:18089/api/ocr/xlpr", //解析车牌接口
  inviteInfo: "https://www.mmcqing.com:18089/api/movecar/inviteInfo", //统计用户邀请成功数，购买数量，佣金
  withdraw: "https://www.mmcqing.com:18089/api/movecar/withdraw", //提现申请
  movecarInviteCount: "https://www.mmcqing.com:18089/api/movecar/movecarInviteCount", //统计邀请好友购买挪车贴信息
  withdrawRecord: "https://www.mmcqing.com:18089/api/movecar/withdrawRecord", //佣金提现记录
  faceInvite: "https://www.mmcqing.com:18089/api/movecar/faceInvite" //面对面邀请生成二维码
};
export default Api;