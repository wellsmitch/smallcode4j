import { Block, View, Image, Button, Text, Input } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
//index.js
//获取应用实例
import { Api, Network, validate } from '../../../utils/index.js'
import MyInvite from '../../../components/invite/invite'
import MyComponent from '../../../components/authorized/authorized'
import './bindQR.scss'

const util = require('../../../utils/_md5.js');

const app = Taro.getApp()

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    mobile: Taro.getApp().globalData.mobile,
    multiIndex: [0, 0],
    multiArray: [],
    platePrefix: '',
    codeList: {},
    plateNumber: '',
    phoneNumber: '',
    moveCarId: '',
    authShow: false,
    authInfo: {
      phoneNumber: '',
      openid: ''
    },
    userInfo: {
      avatar: `https://apph5.mmcqing.com/xcx/images/wx-ic-bg.jpg`
    },
    msgBtnText: '发送短信验证码',
    msgCanClick: true,
    showMsgPanel: false,
    timer: null,
    msgCode: '',
    test: {
      a: 1
    },
    // msgBtnText: '发送短信验证码',
    showConfirmPanel: false,
    codeshow: false,
    codeshowNum: '获取验证码',
    codeNo: '',
    submitBtn: false,
    showModel: false,
    cityCodeArr: [],
    cityArr: [],
    showlabgb: false,
    showCityt: true,
    showCodecity: false,
    plateCode: [],
    cardata: '',
    clickTimeout: true,
    phoneAuth: ''
  }
  getCode = () => {
    if (this.state.codeshowNum == '获取验证码') {
      if (this.state.phoneNumber.length != 11) {
        Taro.showToast({
          title: '请输入11位手机号码',
          icon: 'none'
        })
        return false
      }
      app.msgGets(this.state.phoneNumber, res => {
        this.setState({
          codeshowNum: 60,
          submitBtn: true
        })
        let setTime = setInterval(() => {
          let num = this.state.codeshowNum
          num--
          this.setState({
            codeshowNum: num
          })
          if (num < 1) {
            clearInterval(setTime)
            setTime = null
            this.setState({
              codeshowNum: '获取验证码'
            })
          }
        }, 1000)
      })
    }
  }
  getUserInfo = e => {
    // 首次授权执行
    let detail = e.detail
    if (detail.errMsg === 'getUserInfo:ok') {
      // 授权成功
      app.globalData.userInfo = detail.userInfo
      this.setState({
        userInfo: detail.userInfo
      })
    } else {
      Taro.showToast({
        content: '授权失败',
        icon: 'none'
      })
    }
  }
  getStoreUserInfo = () => {
    // 已经授权执行缓存取
    if (app.globalData.userInfo) {
      this.setState({
        userInfo: app.globalData.userInfo
      })
    }
    // else {
    //   Taro.getSetting({
    //     success: res => {
    //       if (res.authSetting['scope.userInfo']) {
    //         // 已授权
    //         Taro.getUserInfo({
    //           success: res => {
    //             app.globalData.userInfo = res.userInfo
    //             this.setState({
    //               userInfo: res.userInfo
    //             })
    //             if (this.userInfoReadyCallback) {
    //               this.userInfoReadyCallback(res)
    //             }
    //           }
    //         })
    //       }
    //     }
    //   })
    // }
  }

  componentWillMount(options) {
    this.fillCame();
    this.getStoreUserInfo()
    let phoneAuth = false
    if (app.globalData.token) {
      phoneAuth = false
    } else {
      phoneAuth = true
    }
    this.setState({
      moveCarId: options.id,
      phoneAuth: phoneAuth
    })
    this.carInfoGet()
  }

  componentWillUnmount () {
    Taro.getApp().globalData.cardata = '';
  }
  fillCame() {
    let cardata = app.globalData.cardata;
    if (cardata.length > 5) {
      let arr = []
      for (let i = 0; i < cardata.length; i++) {
        arr.push(cardata[i])
      }

      let platePrefix = arr[0]
      let arrcode = arr.slice(1)
      this.setState({
        platePrefix: platePrefix,
        plateCode: arrcode
      })
      let plateNumber = ''
      for (let i = 0; i < arrcode.length; i++) {
        plateNumber += arrcode[i]
      }
      this.setState({
        plateNumber: plateNumber
      })
    }
  }

  carInfoGet = () => {
    // 获取车牌信息
    // let prefixList = wx.getStorageSync('CAR_PRFIX_LIST');
    // if (prefixList) { // 默认从缓存取
    //     this.setState({
    //         codeList: prefixList
    //     });
    //     this.stateCityInit();
    // } else {
    // Network.post(Api.RULE_CARD_INFO, {
    //     params: {
    //         time: 0
    //     }
    // }, (data) => {
    //     if (data.code === 200) {
    //         let _store = {};
    //         (data.data || []).map(item => {
    //             _store[item.title] = (item.capitals || []).map(item2 => {
    //                 return item2.title;
    //             })
    //         })
    //         wx.setStorageSync('CAR_PRFIX_LIST', _store);
    //         this.setState({
    //             codeList: _store
    //         });
    //         this.stateCityInit();
    //     }
    // });
    // };
    this.dataCityInit()
  }
  dataCityInit = () => {
    // 处理
    // 请求后台
    // let _l = Object.keys(this.state.codeList);
    // let _t = [
    //     [..._l],
    //     [...this.state.codeList[_l[0]]]
    // ];
    // let _p = `${_t[0][0]}${_t[1][0]}`;
    let _t = []
    _t[0] = [
      '豫',
      '冀',
      '皖',
      '琼',
      '京',
      '沪',
      '黑',
      '陕',
      '甘',
      '津',
      '贵',
      '川',
      '藏',
      '宁',
      '粤',
      '赣',
      '桂',
      '鲁',
      '辽',
      '湘',
      '新',
      '渝',
      '苏',
      '云',
      '青',
      '晋',
      '鄂',
      '蒙',
      '吉',
      '闽',
      '浙',
      '使'
    ]
    _t[1] = [
      [
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        0,
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'J',
        'K',
        'L',
        'M',
        'N',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V'
      ],
      ['W', 'X', 'Y', 'Z', '学', '领', '警', '挂']
    ]
    this.setState({
      multiArray: _t,
      cityArr: [
        _t[0].slice(0, 10),
        _t[0].slice(10, 19),
        _t[0].slice(19, 27),
        _t[0].slice(27)
      ],
      cityCodeArr: _t[1]
    })
  }
  phoneBlur = e => {
    this.setState({
      phoneNumber: e.detail.value
    })
    if (e.detail.value.length == 11) {
      this.setState({
        codeshow: true
      })
    } else {
      this.setState({
        codeshow: false
      })
    }
  }
  codeNum = e => {
    //验证码输入
    this.setState({
      codeNo: e.detail.value
    })
  }
  plateBlur = e => {
    // 车牌号输入
    this.setState({
      plateNumber: e.detail.value
    })
    if (
      this.state.phoneNumber.length == 11 &&
      this.state.plateNumber.length > 5 &&
      this.state.plateNumber.length < 8
    ) {
      this.setState({
        codeshow: true
      })
    } else {
      this.setState({
        codeshow: false
      })
    }
  }
  bindMultiPickerChange = e => {
    this.setState({
      multiIndex: e.detail.value
    })
  }
  bindMultiPickerColumnChange = e => {
    let data = {
      multiArray: this.state.multiArray,
      multiIndex: this.state.multiIndex
    }
    data.multiIndex[e.detail.column] = e.detail.value
    if (e.detail.column === 0) {
      let _c = this.state.multiArray[0][e.detail.value]
      data.multiArray[1] = this.state.codeList[_c]
    }
    this.setState(data)
    let _p = `${data.multiArray[0][data.multiIndex[0]]}${
      data.multiArray[1][data.multiIndex[1]]
    }`
    this.setState({
      platePrefix: _p
    })
  }
  moveCarCreate = e => {
    let plateNumber = this.state.plateNumber.trim()
    if (!this.state.platePrefix || !plateNumber || plateNumber.length < 6) {
      Taro.showToast({
        title: '请输入有效车牌号',
        icon: 'none'
      })
      return
    }
    let phoneNumber = this.state.phoneNumber
    if (!phoneNumber || !validate.phoneNumber(phoneNumber)) {
      Taro.showToast({
        title: '请输入11位有效的手机号码',
        icon: 'none'
      })
      return
    }
    if (!this.state.submitBtn) {
      Taro.showToast({
        title: '请先发送验证码',
        icon: 'none'
      })
      return
    }
    let codeNoNumber = this.state.codeNo
    if (!codeNoNumber || !validate.codeNumber(codeNoNumber)) {
      Taro.showToast({
        title: '请输入6位数字验证码',
        icon: 'none'
      })
      return
    }

    this.setState({
      showConfirmPanel: true
    })
  }
  modalConfirm = e => {
    // 弹框确认操作
    // if (this.state.showMsgPanel) { // 授权短信验证码弹框
    //     app.confirm(e, () => {
    //         this.setState({ authShow: true, showMsgPanel: false });
    //         this.selectComponent("#componentId").modalCancel();
    //         this.moveCarCreate()
    //     })
    // };
    this.setState({
      showConfirmPanel: false
    })
    if(Taro.getApp().globalData.token){
      this.binNCM();
    }else {
      this.bindUser();
    }
    // if (Taro.getStorageSync('TOKEN')) {
    //   Taro.showLoading({
    //     title: '加载中...'
    //   })
    //   this.binNCM()
    // } else {
    //   Taro.showLoading({
    //     title: '加载中...'
    //   })
    //   app.getOpenid(res => {
    //     app.getOpenids(
    //       { phone: this.state.phoneNumber, codeNum: this.state.codeNo },
    //       res => {
    //         if (res.code == 200) {
    //           Taro.setStorageSync('TOKEN', res.data.token)
    //           app.globalData.token = res.data.token
    //           this.setState({
    //             token: true
    //           })
    //           this.binNCM()
    //         } else {
    //           Taro.hideLoading()
    //           Taro.showToast({
    //             title: res.message,
    //             icon: 'none'
    //           })
    //         }
    //       }
    //     )
    //   })
    // }
  }
  focuss = () => {
    this.setState({
      showModel: false,
      showlabgb: false,
      showCityt: true,
      showCodecity: false
    })
  }
  
  bindUser () {
    let phone = this.state.phoneNumber,
        code = this.state.codeNo;
    
    my.httpRequest({
      method: 'post',
      url: Taro.getApp().globalData.apiUrl + 'api/thirdparty/bind', // 该url是自己的服务地址，实现的功能是服务端拿到authcode去开放平台进行token验证
      data: {
        type: 'hlbsm-zfbxcx',
        openid: Taro.getApp().globalData.openId,
        phone: phone,
        password: code,
      },
      success: (res) => {
        if(res.data.code==200){
            Taro.getApp().globalData.token = res.data.data.token;
            Taro.getApp().globalData.phone = res.data.data.phone;
            Taro.getApp().globalData.isBind = true;
            this.binNCM();
        }else{
          my.alert({
            title:'提示',
            content:res.data.message
          })
        }
      }
    })
  }
  binNCM = () => {
    Network.post(
      Api.BIND_EWM,
      {
        params: {
          plateNum: `${this.state.platePrefix}${this.state.plateNumber}`,
          phoneNum: this.state.phoneNumber,
          id: this.state.moveCarId,
          code: this.state.codeNo
        },
        loading: false
      },
      function(res) {
        Taro.hideLoading()
        if (res.code && res.code == 200) {
          
          Taro.getApp().globalData.cardata = '';
          Taro.redirectTo({
            url: '/pages/scan/success/success?type=bind'
          })
        } else {
          Taro.showToast({
            title: res.message || '绑定失败',
            icon: 'none',
            duration: 5000
          })
        }
      }
    )
  }
  modalCancel = () => {
    this.setState({
      showConfirmPanel: false
    })
  }
  telCall = () => {
    Taro.makePhoneCall({
      phoneNumber: this.state.mobile
    })
  }
  showCity = e => {
    this.setState({
      showModel: true,
      showlabgb: true,
      showCityt: true,
      showCodecity: false
    })
  }
  showCityc = () => {
    let last = false
    if (!this.state.showModel && this.state.plateCode.length == 7) {
      last = true
    } else {
      last = false
    }
    this.setState({
      showModel: true,
      showlabgb: false,
      showCityt: false,
      showCodecity: true,
      last: last
    })
  }
  plateCity = e => {
    if (this.state.plateCode.length < 6) {
      this.setState({
        platePrefix: e.target.dataset.item,
        showlabgb: false,
        showCityt: false,
        showCodecity: true
      })
    } else {
      this.setState({
        platePrefix: e.target.dataset.item,
        showModel: false,
        showlabgb: false,
        showCityt: false,
        showCodecity: true
      })
    }
  }
  closeMode = () => {
    this.setState({
      showModel: false,
      last: false
    })
  }
  platecodeCity = e => {
    if (e.target.dataset.item < 10 && this.state.plateCode.length == 0) {
      return
    }
    if (e.target.dataset.item > 'Z' && this.state.plateCode.length < 5) {
      return
    }
    if (this.state.plateCode.length < 6) {
      let code = this.state.plateCode
      code.push(e.target.dataset.item)
      this.setState({
        plateCode: code
      })
    } else {
      if (this.state.plateCode.length == 6) {
        let code = this.state.plateCode
        code.push(e.target.dataset.item)
        if (this.state.platePrefix.length < 1) {
          this.setState({
            plateCode: code,
            showModel: true,
            showlabgb: false,
            showCityt: true,
            showCodecity: false
          })
        } else {
          this.setState({
            plateCode: code,
            showModel: false,
            showlabgb: false,
            showCityt: false,
            showCodecity: true,
            last: false
          })
        }
      } else {
        this.setState({
          showModel: false,
          showlabgb: false,
          showCityt: false,
          showCodecity: true
        })
      }
    }
    let plateNumber = ''
    for (let i = 0; i < this.state.plateCode.length; i++) {
      plateNumber += this.state.plateCode[i]
    }
    this.setState({
      plateNumber: plateNumber
    })
  }
  removeCode = () => {
    let arr = this.state.plateCode
    if (arr.length > 0) {
      arr.pop()
      this.setState({
        plateCode: arr
      })
    } else {
      this.setState({
        platePrefix: '',
        showModel: true,
        showlabgb: true,
        showCityt: true,
        showCodecity: false
      })
    }
    let plateNumber = ''
    for (let i = 0; i < this.state.plateCode.length; i++) {
      plateNumber += this.state.plateCode[i]
    }
    this.setState({
      plateNumber: plateNumber,
      last: false
    })
  }
  chooseImage = () => {
    Taro.getApp().globalData.cameUrl = '/pages/scan/bindQR/bindQR'
    Taro.redirectTo({
      url: '../../chooseImage/chooseImage'
    })
  }
  hrefnavite = e => {
    Taro.navigateTo({
      url: '../../chooseImage/chooseImage'
    })
  }
  naviteJump = () => {
    this.selectComponent('#href').Jump()
  }
  accredit = e => {
    let that = this
    if (!this.state.clickTimeout) {
      return false
    }
    this.setState({
      clickTimeout: false
    })
    let setTim = setTimeout(() => {
      this.setState({
        clickTimeout: true
      })
      clearTimeout(setTim)
      setTim = null
    }, 500)
    if (app.globalData.token) {
      this[e.target.dataset.tap]()
      return
    } else {
      this.setState({
        redrectUrl: e.target.dataset.tap
      })
      Taro.showLoading({
        title: '加载中...'
      })
      app.accredit(e, res => {
        Taro.removeStorageSync('click')
        if (that.data.uuid) {
          res.data.uuid = that.data.uuid
        }
        app.confirm(res.data, () => {
          Taro.hideLoading()
          // this.selectComponent("#componentId").modalCancel();
          that.setState({ phoneAuth: false })
          that[that.data.redrectUrl]()
        })
      })
      // this.selectComponent("#componentId").toBuy(e);
    }
  }
  config = {}

  render() {
    const {
      userInfo: userInfo,
      showlabgb: showlabgb,
      platePrefix: platePrefix,
      plateCode: plateCode,
      showModel: showModel,
      showCodecity: showCodecity,
      last: last,
      codeshow: codeshow,
      codeNo: codeNo,
      codeshowNum: codeshowNum,
      phoneAuth: phoneAuth,
      mobile: mobile,
      showConfirmPanel: showConfirmPanel,
      phoneNumber: phoneNumber,
      plateNumber: plateNumber,
      showCityt: showCityt,
      cityArr: cityArr,
      cityCodeArr: cityCodeArr
    } = this.state
    return (
      <Block>
        <View className="container">
          {/*  <view class="public-view">
                                                     <image src="https://apph5.mmcqing.com/xcx/images/online-public.png" class="image"></image>
                                                     <text>车主通-公众号</text>
                                                     <view class="attr-view"><text>关注</text></view>
                                                   </view>  */}
          <View className="top-view">
            <View>
              <MyComponent
                ref="toast"
                onMyevent={this.modalConfirm}
                id="componentId"
              />
              <Image
                className="image"
                src="https://apph5.mmcqing.com/xcx/images/buy-suc-bg.png"
              />
              <View className="info-view">
                <Image
                  className="icon-image"
                  src={userInfo.avatar}
                  mode="cover"
                />
                {/* <Button
                  className="icon-image"
                  openType="getUserInfo"
                  onGetuserinfo={this.getUserInfo}
                /> */}
                <View className="right-view">
                  <Text>
                    车主您好，欢迎使用“扫码挪车”，请您在下方输入车牌号及手机号，确认提交后，即可完成车辆绑定。
                  </Text>
                </View>
              </View>
              <View className="text-view">
                <View className="form-view">
                  <View className="t-view">
                    <Text>车辆信息</Text>
                  </View>
                  <View className="input-view">
                    <View
                      className={'label ' + (showlabgb ? 'active' : '')}
                      onClick={this.showCity}
                    >
                      {platePrefix}
                      <Image
                        className="code_cellImg"
                        src="https://apph5.mmcqing.com/xcx/images/gb.gif"
                      />
                    </View>
                    <View className="input flex_hm" onClick={this.showCityc}>
                      <View
                        className={
                          'code_cell flex_hm flex_hc ' +
                          (plateCode.length == 0 && showModel && showCodecity
                            ? 'active'
                            : '')
                        }
                      >
                        <View>{plateCode[0]}</View>
                        <Image
                          className="code_cellImg"
                          src="https://apph5.mmcqing.com/xcx/images/gb.gif"
                        />
                      </View>
                      <View
                        className={
                          'code_cell flex_hm flex_hc ' +
                          (plateCode.length == 1 && showModel && showCodecity
                            ? 'active'
                            : '')
                        }
                      >
                        <View>{plateCode[1]}</View>
                        <Image
                          className="code_cellImg"
                          src="https://apph5.mmcqing.com/xcx/images/gb.gif"
                        />
                      </View>
                      <View
                        className={
                          'code_cell flex_hm flex_hc ' +
                          (plateCode.length == 2 && showModel && showCodecity
                            ? 'active'
                            : '')
                        }
                      >
                        <View>{plateCode[2]}</View>
                        <Image
                          className="code_cellImg"
                          src="https://apph5.mmcqing.com/xcx/images/gb.gif"
                        />
                      </View>
                      <View
                        className={
                          'code_cell flex_hm flex_hc ' +
                          (plateCode.length == 3 && showModel && showCodecity
                            ? 'active'
                            : '')
                        }
                      >
                        <View>{plateCode[3]}</View>
                        <Image
                          className="code_cellImg"
                          src="https://apph5.mmcqing.com/xcx/images/gb.gif"
                        />
                      </View>
                      <View
                        className={
                          'code_cell flex_hm flex_hc ' +
                          (plateCode.length == 4 && showModel && showCodecity
                            ? 'active'
                            : '')
                        }
                      >
                        <View>{plateCode[4]}</View>
                        <Image
                          className="code_cellImg"
                          src="https://apph5.mmcqing.com/xcx/images/gb.gif"
                        />
                      </View>
                      <View
                        className={
                          'code_cell flex_hm flex_hc ' +
                          (plateCode.length == 5 && showModel && showCodecity
                            ? 'active'
                            : '')
                        }
                      >
                        <View>{plateCode[5]}</View>
                        <Image
                          className="code_cellImg"
                          src="https://apph5.mmcqing.com/xcx/images/gb.gif"
                        />
                      </View>
                      <View
                        className={
                          'code_cell flex_hm flex_hc ' +
                          ((plateCode.length == 6 &&
                            showModel &&
                            showCodecity) ||
                          last
                            ? 'active'
                            : '')
                        }
                      >
                        <View>{plateCode[6]}</View>
                        <Image
                          className="code_cellImg"
                          src="https://apph5.mmcqing.com/xcx/images/gb.gif"
                        />
                      </View>
                    </View>
                    <View className="chooseImage" onClick={this.chooseImage}>
                      <Image
                        className="chooseImage_icon"
                        src="https://apph5.mmcqing.com/xcx/images/xiangji.png"
                      />
                    </View>
                  </View>
                </View>
                <View className="form-view">
                  <View className="t-view">
                    <Text>联系电话{codeshow}</Text>
                  </View>
                  <View className="input-view">
                    <View className="input">
                      <Input
                        type="number"
                        onFocus={this.focuss}
                        maxlength="11"
                        onInput={this.phoneBlur}
                        placeholder="请输入电话号码"
                        placeholderClass="placeholderClass"
                      />
                    </View>
                  </View>
                </View>
                {codeshow && (
                  <View className="form-view">
                    <View className="t-view">
                      <Text>验证码</Text>
                    </View>
                    <View className="input-view">
                      <View className="input flex">
                        <Input
                          type="number"
                          onFocus={this.focuss}
                          maxlength="6"
                          onInput={this.codeNum}
                          placeholder="请输入验证码"
                          placeholderClass="placeholderClass"
                          value={codeNo}
                        />
                        <Button
                          className="getCode"
                          onClick={this.getCode}
                          hoverClass="getCodeColor"
                        >
                          {codeshowNum}
                        </Button>
                      </View>
                    </View>
                  </View>
                )}
              </View>
            </View>
            <View className="btton mt50">
              <Button
                hoverClass="hoveractive"
                className="btn-apply"
                onClick={this.moveCarCreate}
              >
                立即绑定
              </Button>
              <Text className="font24 flex_hm flex_hc colo">
                其他车主扫描挪车码可以匿名电话或短信通知您进行挪车
              </Text>
              <View className="mt50 ptreport">
                {phoneAuth && (
                  <Button
                    className="gettoken"
                    openType="getPhoneNumber"
                    onGetphonenumber={this.accredit}
                    data-tap="naviteJump"
                  >
                    立即绑定
                  </Button>
                )}
                {/*  <my-invite id='href' bindJump="naviteJump"></my-invite>  */}
              </View>
            </View>
          </View>
          <View className="main-container">
            {/*  <button class="btn-apply" open-type="getPhoneNumber" bindgetphonenumber="moveCarCreate" wx:else>立即绑定</button>  */}
            {/*  <view class="more-server-view">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              <image class="image" src="https://apph5.mmcqing.com/xcx/images/index-car.png"></image>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              <text>更多车主服务</text>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            </view>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            <view class="handle-view">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              <view class="li">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                <image class="image" src="https://apph5.mmcqing.com/xcx/images/index-handle-one.png"></image>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                <text class="t">违章举报</text>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              </view>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              <view class="li">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                <image class="image" src="https://apph5.mmcqing.com/xcx/images/index-handle-two.png"></image>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                <text class="t">特惠加油</text>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              </view>   
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              <view class="li">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                <image class="image" src="https://apph5.mmcqing.com/xcx/images/index-handle-three.png"></image>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                <text class="t ">话费充值</text>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              </view>   
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              <view class="li">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                <image class="image" src="https://apph5.mmcqing.com/xcx/images/index-handle-four.png"></image>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                <text class="t ">更多服务</text>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              </view>     
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            </view>  */}
            <View className="copy-view">
              <Text className="c">本服务由和路宝提供</Text>
              <View className="c">
                客服电话：
                <View onClick={this.telCall} className="tel">
                  <Text>{mobile}</Text>
                </View>
              </View>
            </View>
          </View>
        </View>
        {showConfirmPanel && (
          <View className="modal">
            <View className="modal-main">
              <View className="modal-title">绑定信息</View>
              <View className="modal-content">
                <View className="u-content">
                  <View className="c-c">
                    <Text>是否绑定</Text>
                  </View>
                  <View className="c-c">
                    <Text>{'手机号：' + phoneNumber}</Text>
                  </View>
                  <View className="c-c">
                    {'车牌号：' + platePrefix + plateNumber}
                  </View>
                </View>
                <View className="modal-btn">
                  <Text className="btn cancel" onClick={this.modalCancel}>
                    取消
                  </Text>
                  <Text className="btn confirm" onClick={this.modalConfirm}>
                    确认
                  </Text>
                </View>
              </View>
            </View>
          </View>
        )}
        <View className={'keyboardmode ' + (showModel ? 'active' : '')}>
          <View className="keyboardmode_title">
            <View
              className="modeClose flex_hm flex_hc"
              onClick={this.closeMode}
            >
              关闭
            </View>
          </View>
          <View className={'keyboardmode_city ' + (showCityt ? 'active' : '')}>
            <View className="citybox flex_hm flex_hc">
              {cityArr[0].map((item, index) => {
                return (
                  <View
                    hoverClass="hoveractive"
                    className="citybox_cell flex_hm flex_hc"
                    data-item={item}
                    onClick={this.plateCity}
                    key
                  >
                    {item}
                  </View>
                )
              })}
            </View>
            <View className="citybox flex_hm flex_hc">
              {cityArr[1].map((item, index) => {
                return (
                  <View
                    hoverClass="hoveractive"
                    className="citybox_cell flex_hm flex_hc"
                    data-item={item}
                    onClick={this.plateCity}
                    key
                  >
                    {item}
                  </View>
                )
              })}
            </View>
            <View className="citybox flex_hm flex_hc">
              {cityArr[2].map((item, index) => {
                return (
                  <View
                    hoverClass="hoveractive"
                    className="citybox_cell flex_hm flex_hc"
                    data-item={item}
                    onClick={this.plateCity}
                    key
                  >
                    {item}
                  </View>
                )
              })}
            </View>
            <View className="cityboxLast citybox flex_hm flex_hc">
              {cityArr[3].map((item, index) => {
                return (
                  <View
                    hoverClass="hoveractive"
                    className="citybox_cell flex_hm flex_hc"
                    data-item={item}
                    onClick={this.plateCity}
                    key
                  >
                    {item}
                  </View>
                )
              })}
              <View
                hoverClass="hoveractive"
                className="removePlace citybox_cell flex_hm flex_hc"
                onClick={this.removeCode}
              >
                <Image
                  mode="aspectFit"
                  className="removePlaceimg"
                  src="https://apph5.mmcqing.com/xcx/images/removeCae.png"
                />
              </View>
            </View>
          </View>
          <View
            className={'keyboardmode_code ' + (showCodecity ? 'active' : '')}
          >
            <View className="citycodebox flex_hm flex_hc">
              {cityCodeArr[0].map((item, index) => {
                return (
                  <View
                    hoverClass="hoveractive"
                    className={
                      'citybox_cell flex_hm flex_hc ' +
                      (index < '10' && plateCode.length == 0 ? 'disable' : '')
                    }
                    data-index={index}
                    data-item={item}
                    onClick={this.platecodeCity}
                    key
                  >
                    {item}
                  </View>
                )
              })}
            </View>
            <View className="citycodebox flex_hm flex_hc last">
              {cityCodeArr[1].map((item, index) => {
                return (
                  <View
                    hoverClass="hoveractive"
                    className={
                      'citybox_cell flex_hm flex_hc ' +
                      (index > 3 && plateCode.length < 5 ? 'disable' : '')
                    }
                    data-index={index}
                    data-item={item}
                    onClick={this.platecodeCity}
                    key
                  >
                    {item}
                  </View>
                )
              })}
              <View
                hoverClass="hoveractive"
                className="removePlace citybox_cell flex_hm flex_hc"
                onClick={this.removeCode}
              >
                <Image
                  mode="aspectFit"
                  className="removePlaceimg"
                  src="https://apph5.mmcqing.com/xcx/images/removeCae.png"
                />
              </View>
            </View>
          </View>
        </View>
      </Block>
    )
  }
}

export default _C
