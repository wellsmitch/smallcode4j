import { Block, View, Image, Text, Button, Navigator } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
import './success.scss'
//index.js
//获取应用实例
const app = Taro.getApp()

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    mobile: Taro.getApp().globalData.mobile,
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    type: 'bind',
    canIUse: Taro.canIUse('button.open-type.getUserInfo')
  }

  componentWillMount(options) {
    this.setData({
      type: options.type || 'bind'
    })
  }

  goIndex = () => {
    Taro.reLaunch({
      url: '/pages/index/index'
    })
  }
  telCall = () => {
    Taro.makePhoneCall({
      phoneNumber: this.data.mobile
    })
  }
  config = {}

  render() {
    const { type: type, mobile: mobile } = this.state
    return (
      <View className="container">
        <View className="top-view">
          <Image
            className="top-image"
            src="https://apph5.mmcqing.com/xcx/images/buy-suc-bg.png"
          />
          <View className="center-view">
            <Image
              className="bg-image"
              src="https://apph5.mmcqing.com/xcx/images/buy-suc-circle.png"
            />
            <Image
              className="suc-icon"
              src="https://apph5.mmcqing.com/xcx/images/buy-suc-c.png"
            />
            <View>
              <Text>{type === 'bind' ? '开启成功' : '修改成功'}</Text>
            </View>
          </View>
          <View className="text-view">
            {type === 'bind' ? (
              <Text>
                1、恭喜您成功绑定挪车码，现在别人可以扫码通知您挪车了~
              </Text>
            ) : (
              <Text>
                1、恭喜您成功修改绑定挪车码，现在别人可以扫码通知您挪车了~
              </Text>
            )}
            <Text>2、如果您需要修改挪车码绑定信息，请您重新扫描挪车码。</Text>
          </View>
        </View>
        <View className="main-container">
          <Button
            className="btn-apply"
            hoverClass="btn-applyhover"
            onClick={this.goIndex}
          >
            返 回 首 页
          </Button>
          <Navigator url="/pages/doc/userHelp/userHelp">
            <View className="help-view">
              <Image
                className="icon"
                src="https://apph5.mmcqing.com/xcx/images/buy-suc-qaq.png"
              />
              <Text>查看使用帮助</Text>
            </View>
          </Navigator>
          <View className="copy-view">
            <Text className="c">本服务由和路宝提供</Text>
            <View className="c">
              客服电话：
              <View onClick={this.telCall} className="tel">
                <Text>{mobile}</Text>
              </View>
            </View>
          </View>
        </View>
      </View>
    )
  }
}

export default _C
