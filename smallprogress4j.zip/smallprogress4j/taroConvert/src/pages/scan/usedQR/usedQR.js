import {
  Block,
  View,
  Image,
  Text,
  Button,
  Swiper,
  SwiperItem,
  Navigator,
  Input
} from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
//index.js
//获取应用实例
import { Network, Api } from '../../../utils/index.js'
import MyIntroduce from '../../../components/introduce/introduce'
import MyInvite from '../../../components/invite/invite'
import MyComponent from '../../../components/authorized/authorized'
import './usedQR.scss'
var md5 = require('../../../utils/md5.js')
const app = Taro.getApp()

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    mobile: Taro.getApp().globalData.mobile,
    plateNumber: '',
    phoneNumber: '',
    phoneNumbers: '',
    // modalShow: false,,
    hiddenmodalput: false,
    phoneAuth: '',
    msgCanClick: true,
    openid: '',
    showMsgPanel: '',
    msgBtnText: '',
    msgCode: '',
    focus: false,
    clicke: null,
    settime: true,
    phonetel: app.globalData.userPhone,
    phonetels: app.globalData.userPhone,
    telerror: '',
    telShow: false,
    telValue: '',
    telerr: false,
    clickTimeout: false
  }

  componentWillMount(options) {
    let _param = JSON.parse(options.param || '{}')
    if (_param.uuid) {
      this.setData({
        uuid: _param.uuid
      })
    }
    let adList
    if (_param.list) {
      adList = _param.list
    } else {
      adList = ''
    }
    this.setData({
      plateNumber: _param.carNum, //车牌号
      phoneNumber: _param.phone, //要发送的手机号
      adList: adList
    })
    // this.setData({
    //     plateNumber: '豫A12345',//车牌号
    //     phoneNumber: '18875927085'//要发送的手机号
    // })
    let count = 0
    let timer = setInterval(() => {
      if (app.globalData.login_code) {
        this.setData({ login_code: app.globalData.login_code })
      }
      if (!app.globalData.token) {
        //需授权
        this.setData({ phoneAuth: true })
      } else {
        this.setData({ phoneAuth: false, clickTimeout: true })
        clearInterval(timer)
      }
      count++

      if (count >= 40) {
        this.setData({ clickTimeout: true })
        clearInterval(timer)
      }
    }, 100)
  }

  getCenterTel = () => {
    let telA = app.globalData.userPhone
    let telB = this.data.phoneNumber
    if (telA.substring(0, 2) != '86') {
      telA = '86' + telA
    }
    if (telB.substring(0, 2) != '86') {
      telB = '86' + telB
    }
    let param = {
      // telA: telA,//呼叫电话
      tel: telB //被叫电话,
    }
    if (this.data.uuid) {
      param.scanid = this.data.uuid
    }
    Network.post(
      Api.TELL_BIND,
      {
        params: param,
        tokenNone: true
      },
      res => {
        if (res.code === 200) {
          Taro.makePhoneCall({
            phoneNumber: '+' + res.data.x_no //打电话的手机号
          })
        } else {
          Taro.showToast({
            title: '获取失败，请重试',
            icon: 'none'
          })
        }
      }
    )
  }
  callTel = () => {
    // this.setData({
    //     telShow:true,
    //     phonetel: app.globalData.userPhone,
    //     phonetels: app.globalData.userPhone,
    //     telValue: app.globalData.userPhone
    // })
    this.getCenterTel()
    if (app.globalData.userPhone) {
    }
  }
  telClose = () => {
    this.setData({
      telShow: false,
      telerror: '',
      telerr: false,
      telValue: app.globalData.userPhone
    })
  }
  telSure = () => {
    if (this.data.telValue.trim() == '') {
      if (this.data.phonetels) {
        this.getCenterTel()
      }
      this.telClose()
    } else if (
      this.data.telValue.trim().length < 11 &&
      this.data.telValue.trim() != ''
    ) {
      this.setData({
        telerror: '请填写正确的手机号',
        telerr: true
      })
    } else if (
      this.data.telValue.trim().length == 11 &&
      this.data.telValue.trim() != ''
    ) {
      this.setData({
        phonetel: this.data.telValue.trim()
      })
      this.telClose()
      this.getCenterTel()
    }
  }
  telInput = e => {
    if (e.detail.value.trim().length == 11) {
      this.setData({
        telerror: '',
        telerr: false
      })
    }
    this.setData({
      telValue: e.detail.value
    })
  }
  goIndex = () => {
    Taro.redirectTo({
      url: '/pages/index/index'
    })
  }
  telCall = () => {
    Taro.makePhoneCall({
      phoneNumber: this.data.mobile //客服电话
    })
  }
  accredit = e => {
    let that = this
    if (!this.data.clickTimeout) {
      return false
    }
    this.setData({
      clickTimeout: false
    })
    let setTim = setTimeout(() => {
      this.setData({
        clickTimeout: true
      })
      clearTimeout(setTim)
      setTim = null
    }, 500)
    if (app.globalData.token) {
      this[e.target.dataset.tap]()
      return
    } else {
      this.setData({
        redrectUrl: e.target.dataset.tap
      })
      Taro.showLoading({
        title: '加载中...'
      })
      app.accredit(e, res => {
        Taro.removeStorageSync('click')
        if (that.data.uuid) {
          res.data.uuid = that.data.uuid
        }
        app.confirm(res.data, () => {
          Taro.hideLoading()
          // this.selectComponent("#componentId").modalCancel();
          that.setData({ phoneAuth: false })
          that[that.data.redrectUrl]()
        })
      })
      // this.selectComponent("#componentId").toBuy(e);
    }
  }
  modalConfirm = e => {
    // 弹框确认

    if (this.data.uuid) {
      e.detail.data.uuid = this.data.uuid
    }
    app.confirm(e, () => {
      this.setData({ phoneAuth: false })
      this.selectComponent('#componentId').modalCancel()
      this[this.data.redrectUrl]()
    })
  }
  sendinfo = e => {
    let that = this
    if (!this.data.settime) {
      Taro.showToast({
        title: '请耐心等待车主正在赶来中...',
        icon: 'none'
      })
      return false
    }
    if (this.data.plateNumber && this.data.phoneNumber) {
      my.confirm({
        title: '',
        content: '是否给车主发送短信',
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        success: (result) => {
          if (result.confirm) {
            that.send()
          }
        },
      });
      // Taro.showModal({
      //   title: '',
      //   content: '',
      //   confirmColor: '#333',
      //   success(res) {
      //     if (res.confirm) {
      //       that.send()
      //     }
      //   }
      // })
    } else {
      Taro.showToast({
        title: '信息有误请退出重试',
        icon: 'none'
      })
    }
  }
  send = () => {
    let that = this
    let scanId = '1234567890'
    if (this.data.uuid) {
      scanId = this.data.uuid
    }
    let data = {
      users: this.data.phoneNumber,
      carNum: this.data.plateNumber,
      source: 1,
      scanId: scanId
    }
    let plateNumber = this.data.plateNumber
    let phoneNumber = this.data.phoneNumber
    Network.post(
      Api.MESSAGE_INFO,
      {
        params: {
          users: phoneNumber,
          carNum: plateNumber,
          scanId: scanId
          // smsContent:
          //   '尊敬的车主，您的车辆' +
          //   plateNumber +
          //   '停放的位置，已经影响到了他人通行，请前往处理，谢谢！'
        }
      },
      res => {
        console.log(res)
        console.log(phoneNumber)
        console.log('plateNumber')
        if (res.code == 200) {
          that.setData({
            settime: false
          })
          let tim = setTimeout(() => {
            that.setData({
              settime: true
            })
            clearTimeout(tim)
            tim = null
          }, 300000)

          Taro.showToast({
            title: '短信发送成功',
            icon: 'none'
          })
        } else {
          Taro.showToast({
            title: '发送失败~',
            icon: 'none'
          })
        }
      }
    )
    // Network.post(Api.MESSAGE_INFO, data, function (res) {
    //     if (res.code == 200) {
    //         that.setData({
    //             settime: false
    //         })
    //         let tim = setTimeout(() => {
    //             that.setData({
    //                 settime: true
    //             })
    //             clearTimeout(tim)
    //             tim = null;

    //         }, 300000)

    //         wx.showToast({
    //             title: '短信发送成功',
    //             icon: "none"
    //         })
    //     } else {
    //         wx.showToast({
    //             title: res.message,
    //             icon: "none"
    //         })

    //     }
    // })
    // app.requestPost(Api.SMS_MESSAGE, data, function (res) {
    //     if(res.code==200){
    //         that.setData({
    //             settime:false
    //         })
    //         let tim=setTimeout(()=>{
    //             that.setData({
    //                 settime: true
    //             })
    //             clearTimeout(tim)
    //             tim=null;

    //         },300000)

    //         wx.showToast({
    //             title: '短信发送成功',
    //             icon:"none"
    //         })
    //     }else{
    //         wx.showToast({
    //             title: res.message,
    //             icon: "none"
    //         })

    //     }
    // })
  }
  navTo = () => {
    Taro.navigateTo({
      url: '/pages/buyProgress/buyMain/buyMain'
    })
  }
  goInite = () => {
    Taro.navigateTo({
      url: '/pages/activities/inviteEarnMoney/inviteEarnMoney'
    })
  }
  adBanner = e => {
    if (e.currentTarget.dataset.url) {
      Taro.navigateTo({
        url:
          '../../activities/webView/webView?url=' + e.currentTarget.dataset.url
      })
    }
  }
  config = {}

  render() {
    const {
      plateNumber: plateNumber,
      phoneAuth: phoneAuth,
      clickTimeout: clickTimeout,
      adList: adList,
      mobile: mobile,
      telShow: telShow,
      phonetels: phonetels,
      telerr: telerr,
      telValue: telValue,
      telerror: telerror
    } = this.state
    return (
      <View className="container">
        <MyComponent
          ref="toast"
          onMyevent={this.modalConfirm}
          id="componentId"
        />
        <View className="top-view">
          <Image
            className="image"
            src="https://apph5.mmcqing.com/xcx/images/online-top-bg.png"
          />
          <View className="titlt-view">
            <Text>车辆信息</Text>
          </View>
          <View className="car-view">{plateNumber}</View>
          <View className="text-view">
            <View className="flex1">
              <Image
                className="msg"
                src="https://apph5.mmcqing.com/xcx/images/online-msg.png"
              />
              <View>
                <Text>短信推送</Text>
              </View>
              <View>
                <Text>通知挪车</Text>
              </View>
              <Button className="usertext" onClick={this.sendinfo} />
              {/*  <button wx:else class="usertext" open-type="getPhoneNumber" data-tap="sendinfo" catchgetphonenumber="accredit"></button>  */}
            </View>
            <View className="flex1">
              <Image
                className="tel"
                src="https://apph5.mmcqing.com/xcx/images/online-tel.png"
              />
              <View>
                <Text>匿名电话</Text>
              </View>
              <View>
                <Text>通知挪车</Text>
              </View>
              <Button className="usertext" onClick={this.callTel} />
              {/*  <button wx:else class="usertext" open-type="getPhoneNumber" data-tap="callTel" catchgetphonenumber="accredit"></button>  */}
            </View>
          </View>
        </View>
        <View className="share-view">
          <View className="app-view">
            <Text>申请我的挪车码 >></Text>
            {!phoneAuth ? (
              <Button className="usertext" onClick={this.navTo} />
            ) : (
              <Button
                className="usertext"
                disabled={!clickTimeout}
                openType="getPhoneNumber"
                data-tap="navTo"
                onGetphonenumber={this.accredit}
              />
            )}
          </View>
          {adList.length > 0 && (
            <View className="share-bg-view">
              {adList.length > 1 ? (
                <Swiper
                  indicatorDots={adList.length > 1}
                  autoplay="true"
                  circular="true"
                  interval="1500"
                  duration="500"
                >
                  {adList.map((item, index) => {
                    return (
                      <Block key="key">
                        <SwiperItem>
                          <Image
                            onClick={this.adBanner}
                            src={item.picUrl}
                            data-url={item.linkUrl}
                            className="slide-image img"
                          />
                        </SwiperItem>
                      </Block>
                    )
                  })}
                </Swiper>
              ) : (
                <Image
                  className="img"
                  onClick={this.adBanner}
                  src={adList[0].picUrl}
                  data-url={adList[0].linkUrl}
                  mode="widthFix"
                />
              )}
            </View>
          )}
        </View>
        <View className="main-container">
          <View>
            <MyIntroduce />
          </View>
          <Navigator url="/pages/doc/userHelp/userHelp">
            <View className="help-view">
              <Image
                className="icon"
                src="https://apph5.mmcqing.com/xcx/images/buy-suc-qaq.png"
              />
              <Text>查看使用帮助</Text>
            </View>
          </Navigator>
          <View className="copy-view">
            <Text className="c">本服务由车主通车服提供</Text>
            <View className="c">
              客服电话：
              <View onClick={this.telCall} className="tel">
                <Text>{mobile}</Text>
              </View>
            </View>
          </View>
          {/* <View className={'telconfirm ' + (telShow ? '' : 'view-hide')}>
            <View className="telconfirm_body">
              <View className="telconfirm_body_title">提示</View>
              <View className="telconfirm_body_box">
                <Text className="font28">
                  {'为保证正常通话，请确保' +
                    phonetels +
                    '为本机号码,若不是请修改'}
                </Text>
                <View className={'telPhone ' + (telerr ? 'error' : '')}>
                  <Input
                    type="number"
                    onInput={this.telInput}
                    maxlength="11"
                    value={telValue}
                  />
                </View>
                <View className="telerror">{telerror}</View>
              </View>
              <View className="flex_hm telconfirm_body_foot">
                <View
                  className="flex1 flex_hm flex_hc font30"
                  onClick={this.telClose}
                  hoverClass="bgcolor"
                >
                  取消
                </View>
                <View
                  className="flex1 flex_hm flex_hc font30"
                  onClick={this.telSure}
                  hoverClass="bgcolor"
                >
                  确定
                </View>
              </View>
            </View>
          </View> */}
        </View>
      </View>
    )
  }
}

export default _C
