import { Block, View, Image, Text, Button } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
//index.js
//获取应用实例
const app = Taro.getApp()
import { Network, Api } from '../../../utils/index.js'
import './mainIndex.scss'

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    mobile: '400-1066-899',
    index_imgurl:
      'https://apph5.mmcqing.com/xcx/images/share-top.png?time=' +
      Math.random() * 10,
    showShare: false,
    // isScroll: true,
    inviteBoList: [
      // {phoneNum: '123 **** 5678', inviteTime: '2018-09-25 12:00:00'},
      // {phoneNum: '123 **** 5678', inviteTime: '2018-09-25 12:00:00'}
    ],
    inviteNum: 0,
    userId: '',
    canConvert: 0,
    viewMore: '1' // 0展示查看更多 1不展示查看更多
  }
  onShareAppMessage = obj => {
    if (obj.from === 'button') {
      return {
        title: '邀请好友，免费领取挪车贴！',
        path: `/pages/index/index?recommenduserid=${this.data.userId}`,
        imageUrl: '/static/images/share-icon.png',
        success(res) {
          // 转发成功之后的回调
          if (res.errMsg == 'shareAppMessage:ok') {
            // wx.showToast({
            //     title: '分享成功',
            //     icon: "none"
            // })
          }
        },
        fail(res) {
          // 转发失败之后的回调
          if (res.errMsg == 'shareAppMessage:cancel') {
            // 用户取消转发
            Taro.showToast({
              title: '转发取消',
              icon: 'none'
            })
          } else if (res.errMsg == 'shareAppMessage:fail') {
            // 转发失败，其中 detail message 为详细失败信息
            console.log(res.detail)
            Taro.showToast({
              title: '转发失败',
              icon: 'none'
            })
          }
        },
        complete(res) {
          // 转发结束之后的回调（转发成不成功都会执行）
        }
      }
    }
  }
  stopProp = e => {}
  getCanCanvertNum = () => {
    Network.post(
      Api.CAN_CONVERT,
      {
        params: {},
        loading: false
      },
      data => {
        console.log(data)
        if (data.code === 200) {
          this.setData({
            canConvert: data.data.canConvert || 0
          })
        }
      }
    )
  }
  getUserId = () => {
    Network.get(
      Api.USER_ID,
      {
        params: {},
        loading: false
      },
      data => {
        console.log(data)
        if (data.data.code === 200) {
          this.setData({
            userId: data.data.data.userid || ''
          })
        }
      }
    )
  }

  componentDidShow() {
    this.getInviteCount()
    this.getCanCanvertNum()
    this.getUserId()
  }

  toShareBuy = () => {
    if (this.data.canConvert == '0') {
      Taro.showToast({
        title: '没有足够的挪车贴可兑换',
        icon: 'none'
      })
      return
    }
    Taro.navigateTo({
      url: '/pages/share/shareBuy/shareBuy?num=' + this.data.canConvert
    })
  }
  goShareMore = () => {
    Taro.navigateTo({
      url: '/pages/share/shareMore/shareMore'
    })
  }
  call = () => {
    // 打电话
    Taro.makePhoneCall({
      phoneNumber: this.data.mobile
    })
  }
  getInviteCount = () => {
    Network.post(
      Api.INVITE_COUNT,
      {
        params: {},
        loading: false
      },
      data => {
        // console.log(data);
        if (data.code === 200) {
          this.setData({
            inviteNum: data.data.inviteNum || '0',
            inviteBoList: data.data.inviteBoList || [],
            viewMore: data.data.viewMore || '1'
          })
        }
      }
    )
  }
  shareCancel = () => {
    this.setData({
      showShare: false
      // isScroll: true
    })
  }
  openShare = () => {
    this.setData({
      showShare: true
      // isScroll: true
    })
  }
  config = {}

  render() {
    const {
      index_imgurl: index_imgurl,
      canConvert: canConvert,
      inviteNum: inviteNum,
      inviteBoList: inviteBoList,
      viewMore: viewMore,
      mobile: mobile,
      showShare: showShare
    } = this.state
    return (
      <Block>
        {/*  <scroll-view scroll-y="{{isScroll}}">  */}
        <View className="container">
          <View className="main-container">
            <View className="top-img box-shadow">
              <Image className="image" src={index_imgurl} mode="widthFix" />
            </View>
            <View className="charge-view box-shadow">
              <View className="li-view">
                <View className="num">
                  {canConvert}
                  <Text className="i">张</Text>
                </View>
                <View className="desc">可兑换挪车贴</View>
                <View className="btn" onClick={this.toShareBuy}>
                  立即兑换
                </View>
              </View>
              <View className="li-view">
                <View className="num">
                  {inviteNum}
                  <Text className="i">位</Text>
                </View>
                <View className="desc">邀请好友人数</View>
                <View className="btn" onClick={this.openShare}>
                  立即邀请
                </View>
              </View>
            </View>
            <View className="share-view">
              <View className="share-title">我的邀请</View>
              <Image
                className="img-header"
                src="https://apph5.mmcqing.com/xcx/images/share-bg-h.png"
              />
              <View className="share-content">
                <View className="list-title">邀请5位即可兑换奖品</View>
                <View className="list-content">
                  {inviteBoList.map((invite, index) => {
                    return (
                      <View className="li" key="unique">
                        <Text className="tel">{invite.phoneNum}</Text>
                        <Text className="date">{invite.inviteTime}</Text>
                      </View>
                    )
                  })}
                  {!inviteBoList.length && (
                    <View className="list-none">暂无邀请好友记录</View>
                  )}
                </View>
                {viewMore !== '1' && (
                  <View className="list-more" onClick={this.goShareMore}>
                    查看更多 >>
                  </View>
                )}
              </View>
              <Image
                className="img-footer"
                src="https://apph5.mmcqing.com/xcx/images/share-bg-b.png"
              />
            </View>
            <View className="share-view">
              <View className="share-title">如何邀请</View>
              <Image
                className="img-header"
                src="https://apph5.mmcqing.com/xcx/images/share-bg-h.png"
              />
              <View className="share-content">
                <View className="progress-view">
                  <Image
                    className="image"
                    src="https://apph5.mmcqing.com/xcx/images/share-progress.png"
                    mode="widthFix"
                  />
                  <View className="step-view">
                    <Text>
                      <Text>点击邀请</Text>
                      <Text>发送链接</Text>
                    </Text>
                    <Text>
                      <Text>好友打开链接</Text>
                      <Text>验证手机号</Text>
                    </Text>
                    <Text>
                      <Text>邀请成功</Text>
                      <Text>兑换奖励</Text>
                    </Text>
                  </View>
                </View>
              </View>
              <Image
                className="img-footer"
                src="https://apph5.mmcqing.com/xcx/images/share-bg-b.png"
              />
            </View>
            <View className="share-view">
              <View className="share-title">活动说明</View>
              <Image
                className="img-header"
                src="https://apph5.mmcqing.com/xcx/images/share-bg-h.png"
              />
              <View className="share-content">
                <View className="act-view">
                  <Text>
                    1.
                    活动期间每成功邀请5位好友，即可兑换一张挪车贴，以此累计，无上限；
                  </Text>
                  <Text>
                    2.兑换成功之后，我们会在工作日安排尽快发货，届时系统会向您发送短信通知，请注意查收；
                  </Text>
                  <Text>
                    3. 收到挪车贴后，通过微信扫描二维码可快速绑定车辆信息；
                  </Text>
                  <Text>
                    4.
                    他人可打开微信扫描挪车贴二维码，选择短信或拨打匿名电话通知您挪车；
                  </Text>
                  <Text>5. 活动解释权归和路宝所有。</Text>
                </View>
              </View>
              <Image
                className="img-footer"
                src="https://apph5.mmcqing.com/xcx/images/share-bg-b.png"
              />
            </View>
            <View className="copy-view">
              <Text className="c">本服务由和路宝提供</Text>
              <View className="c">
                客服电话：
                <View onClick={this.call} className="tel">
                  <Text>{mobile}</Text>
                </View>
              </View>
            </View>
          </View>
        </View>
        {/*  </scroll-view>  */}
        {showShare && (
          <View className="share-popup" onTouchMove={this.stopProp}>
            <View className="share-content">
              <View className="img-view">
                <Image
                  className="shake"
                  src="https://apph5.mmcqing.com/xcx/images/share-shake.png"
                />
                <Image
                  className="image"
                  src="https://apph5.mmcqing.com/xcx/images/share-popup.png"
                  mode="widthFix"
                />
              </View>
              <View className="share-btn">
                <View className="cancel" onClick={this.shareCancel}>
                  取消
                </View>
                <Button className="share" openType="share">
                  立即分享
                </Button>
              </View>
            </View>
          </View>
        )}
      </Block>
    )
  }
}

export default _C
