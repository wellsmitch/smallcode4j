import {
  Block,
  View,
  Image,
  Text,
  Input,
  Picker,
  Textarea
} from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
import { Network, Api, validate } from '../../../utils/index.js'

//index.js
//获取应用实例
import './shareBuy.scss'
const app = Taro.getApp()

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    mobile: Taro.getApp().globalData.mobile,
    region: ['河南省', '郑州市', '二七区'],
    // regionText: '河南省-郑州市-二七区',
    customItem: '全部',
    detailNum: 0,
    buyNumber: 1,
    receiver: '',
    receiverPhone: '',
    receiverAdress: '',
    receiverRegion: '河南省-郑州市-二七区',
    remark: '',
    addressReplace: '请填写详细收货地址',
    initNum: 0,
    login_code: '',
    // isScroll: true,
    showKnow: false,
    agreeCheck: true // 协议勾选
  }
  stopProp = e => {}

  componentWillMount(options) {
    console.log(options)
    this.setData({
      login_code: app.globalData.login_code || ''
    })
    if (options.num) {
      this.setData({
        initNum: parseInt(options.num),
        buyNumber: parseInt(options.num)
      })
    }
  }

  tapAgree = () => {
    let _t = !this.data.agreeCheck
    this.setData({
      agreeCheck: _t
    })
  }
  toMainIndex = () => {
    this.setData({
      showKnow: false
      // isScroll: true
    })
    Taro.redirectTo({
      url: '/pages/share/mainIndex/mainIndex'
    })
  }
  buyImm = () => {
    // this.setData({showKnow: true})
    // return;
    if (!this.data.initNum) {
      Taro.showToast({
        title: '可兑换数量不足',
        icon: 'none'
      })
      return
    }
    if (!this.data.receiver.trim()) {
      Taro.showToast({
        title: '请填写收货人姓名',
        icon: 'none'
      })
      return false
    }
    let phoneNumber = this.data.receiverPhone.trim()
    if (!validate.phoneNumber(phoneNumber)) {
      Taro.showToast({
        title: '请输入11位有效的手机号码',
        icon: 'none'
      })
      return false
    }
    if (!this.data.receiverAdress.trim()) {
      Taro.showToast({
        title: '请填写详细收货地址',
        icon: 'none'
      })
      return false
    }
    if (!this.data.agreeCheck) {
      Taro.showToast({
        title: '请勾选服务协议',
        icon: 'none'
      })
      return false
    }
    let _param = {
      buyNumber: this.data.buyNumber,
      receiver: this.data.receiver,
      receiverPhone: this.data.receiverPhone,
      receiverAdress: `${this.data.region.join('')}${this.data.receiverAdress}`,
      type: 0,
      source: 1
    }
    console.warn(_param)
    return false
    Network.post(
      Api.APPOINTMENT_CONVERT,
      {
        params: _param
      },
      data => {
        console.warn(data)
        if (data.code === 200) {
          this.setData({
            showKnow: true
            // isScroll: false
          })
        } else {
          Taro.showToast({
            title: data.message,
            icon: 'none'
          })
        }
      }
    )
  }
  bindRegionChange = e => {
    // console.log(e.detail.value);
    this.setData({
      receiverRegion: e.detail.value.join('-')
    })
  }
  nameBlur = e => {
    // console.log(e);
    // if (!e.detail.value.trim()) {
    //   wx.showToast({title: '请填写收货人姓名', icon: 'none'})
    //   return false;
    // }
    this.setData({
      receiver: e.detail.value
    })
    // return true;
  }
  detailInput = e => {
    this.setData({
      receiverAdress: e.detail.value
    })
    if (e.detail.value) {
      this.setData({
        receiverAdress: e.detail.value
      })
    } else {
      this.setData({
        receiverAdress: '请填写详细收货地址'
      })
    }
    this.setData({
      detailNum: e.detail.value.trim().length
    })
  }
  detailBlur = e => {
    // if (!e.detail.value.trim()) {
    //   wx.showToast({title: '请填写详细收货地址', icon: 'none'});
    //   return false;
    // }
    // console.log();
    this.setData({
      receiverAdress: e.detail.value
    })
    // return true;
  }
  phoneBlur = e => {
    // if (!e.detail.value.trim() || e.detail.value.trim().length < 11) {
    //   wx.showToast({title: '请输入11位有效的手机号码', icon: 'none'});
    //   return false;
    // }
    this.setData({
      receiverPhone: e.detail.value
    })
    // return true;
  }
  numDesc = () => {
    if (this.data.buyNumber >= 2) {
      let _d = this.data.buyNumber - 1
      this.setData({
        buyNumber: _d
        // totalPrice: parseFloat(this.data.singlePrice * _d).toFixed(2)
      })
    }
  }
  numAdd = () => {
    let _d = this.data.buyNumber + 1
    if (_d <= this.data.initNum) {
      this.setData({
        buyNumber: _d
      })
    }
  }
  goServAgree = () => {
    Taro.navigateTo({
      url: '/pages/doc/servAgree/servAgree'
    })
  }
  telCall = () => {
    Taro.makePhoneCall({
      phoneNumber: this.data.mobile
    })
  }
  config = {}

  render() {
    const {
      buyNumber: buyNumber,
      region: region,
      customItem: customItem,
      receiverRegion: receiverRegion,
      showKnow: showKnow,
      addressReplace: addressReplace,
      detailNum: detailNum,
      mobile: mobile,
      agreeCheck: agreeCheck
    } = this.state
    return (
      <Block>
        {/* index.wxml */}
        <View className="container">
          <View className="top-view">
            <Image
              className="image-bg"
              src="https://apph5.mmcqing.com/xcx/images/buy-top-bg.png"
            />
            <View className="content-view">
              <Image
                className="image"
                src="https://apph5.mmcqing.com/xcx/images/buy-qr.png"
              />
              <View className="right-view">
                <View className="t-text">
                  <Text>挪车贴</Text>
                  <Text className="t-num">x1</Text>
                </View>
                <View>
                  <Text>材质：可移不干胶</Text>
                </View>
                <View>
                  <Text>尺寸：81mm*89mm</Text>
                </View>
              </View>
            </View>
            <View className="remain-view">
              <Text>
                注：收到快递后请<Text className="or">绑定</Text>
                挪车码后使用，如有疑问可查看“我的-使用帮助”
              </Text>
            </View>
          </View>
          <View className="main-container">
            <View className="num-view">
              <View className="left">兑换数量</View>
              <View className="right">
                <View className="content-view">
                  <Text className="desc" onClick={this.numDesc} />
                  <Input className="input" value={buyNumber} disabled />
                  <Text className="add" onClick={this.numAdd} />
                </View>
              </View>
            </View>
            <View className="form-view">
              <View className="input-view">
                <Text className="label">收货人</Text>
                <View className="wid60">
                  <Input
                    type="text"
                    cursorSpacing="30"
                    adjustPosition="false"
                    onInput={this.nameBlur}
                    className="input"
                    placeholder="请输入收货人姓名"
                    placeholderClass="placehoderClass"
                  />
                </View>
              </View>
              <View className="input-view">
                <Text className="label">联系电话</Text>
                <View className="wid60">
                  <Input
                    type="number"
                    onInput={this.phoneBlur}
                    maxlength="11"
                    className="input"
                    placeholder="请输入手机号码"
                    placeholderClass="placehoderClass"
                    cursorSpacing="30"
                    adjustPosition="false"
                  />
                </View>
              </View>
              <Picker
                mode="region"
                onChange={this.bindRegionChange}
                value={region}
                customItem={customItem}
              >
                <View className="input-view more-right">
                  <Text>所在区域</Text>
                  <View className="right-text">{receiverRegion}</View>
                </View>
              </Picker>
              {showKnow ? (
                <View className="textarea">{addressReplace}</View>
              ) : (
                <Textarea
                  className="form-textarea"
                  onInput={this.detailInput}
                  maxlength="60"
                  placeholder="请填写详细收货地址"
                  placeholderClass="placehoderClass"
                  cursorSpacing="60"
                  adjustPosition="false"
                />
              )}
              {/* <View className="textarea-label">
                <Text>{detailNum}</Text>/60
              </View> */}
            </View>
            <View className="copy-view">
              <Text className="c">本服务由和路宝提供</Text>
              <View className="c">
                客服电话：
                <View onClick={this.telCall} className="tel">
                  <Text>{mobile}</Text>
                </View>
              </View>
            </View>
          </View>
        </View>
        <View className="agree-view">
          {!agreeCheck && <View className="before" onClick={this.tapAgree} />}
          {agreeCheck && (
            <Image
              src="https://apph5.mmcqing.com/xcx/images/check.png"
              className="icon"
              onClick={this.tapAgree}
            />
          )}
          我同意
          <Text className="orange-text" onClick={this.goServAgree}>
            《服务协议》
          </Text>
          中的说明
        </View>
        <View className="bottom-fixed">
          <View className="m-view">共计0元</View>
          {/*  <view class="buy-submit gray" wx:if="{{initNum == 0}}">立即购买</view>  */}
          <View className="buy-submit" onClick={this.buyImm}>
            立即兑换
          </View>
        </View>
        {showKnow && (
          <View className="suc-modal" onTouchMove={this.stopProp}>
            <View className="suc-content">
              <Image
                src="https://apph5.mmcqing.com/xcx/images/share-buy-suc.png"
                className="main-img"
                mode="widthFix"
              />
              <View className="btn" onClick={this.toMainIndex}>
                我知道啦！
              </View>
            </View>
          </View>
        )}
      </Block>
    )
  }
}

export default _C
