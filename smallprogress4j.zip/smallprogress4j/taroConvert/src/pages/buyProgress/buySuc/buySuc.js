import { Block, View, Image, Text, Button, Navigator } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
import './buySuc.scss'
//index.js
//获取应用实例
const app = Taro.getApp()

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    mobile: Taro.getApp().globalData.mobile,
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: Taro.canIUse('button.open-type.getUserInfo')
  }
  bindViewTap = () => {
    Taro.navigateTo({
      url: '../logs/logs'
    })
  }

  componentWillMount() {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      Taro.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  }

  getUserInfo = e => {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
  goIndex = () => {
    Taro.redirectTo({
      url: '/pages/index/index'
    })
  }
  telCall = () => {
    Taro.makePhoneCall({
      phoneNumber: this.data.mobile
    })
  }
  config = {}

  render() {
    const { mobile: mobile } = this.state
    return (
      <View className="container">
        <View className="top-view">
          <Image
            className="top-image"
            src="https://apph5.mmcqing.com/xcx/images/buy-suc-bg.png"
          />
          <View className="center-view">
            <Image
              className="bg-image"
              src="https://apph5.mmcqing.com/xcx/images/buy-suc-circle.png"
            />
            <Image
              className="suc-icon"
              src="https://apph5.mmcqing.com/xcx/images/buy-suc-c.png"
            />
            <View>
              <Text>购买成功</Text>
            </View>
          </View>
          <View className="desc-view">
            <Text>
              我们已收到您的挪车码邮寄申请，预计1-3个工作日
              发出。收到后请使用微信扫码绑定。
            </Text>
          </View>
        </View>
        <View className="main-container">
          <Button className="btn-apply" onClick={this.goIndex}>
            返 回 首 页
          </Button>
          <Navigator url="/pages/doc/userHelp/userHelp">
            <View className="help-view">
              <Image
                className="icon"
                src="https://apph5.mmcqing.com/xcx/images/buy-suc-qaq.png"
              />
              <Text>查看使用帮助</Text>
            </View>
          </Navigator>
          <View className="copy-view">
            <Text className="c">本服务由和路宝提供</Text>
            <View className="c">
              客服电话：
              <View onClick={this.telCall} className="tel">
                <Text>{mobile}</Text>
              </View>
            </View>
          </View>
        </View>
      </View>
    )
  }
}

export default _C
