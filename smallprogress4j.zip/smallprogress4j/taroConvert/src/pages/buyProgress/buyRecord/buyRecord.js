import { Block, View, ScrollView, Text, Image } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
//index.js
//获取应用实例
import { Api, Network } from '../../../utils/index.js'
import './buyRecord.scss'
const app = Taro.getApp()

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    mobile: Taro.getApp().globalData.mobile,
    orderList: [],
    nodata: false,
    statusWitch: {
      '0': '待付款',
      '1': '待发货',
      '2': '交易关闭',
      '3': '交易完成',
      '4': '已发货'
    }
  }

  componentWillMount() {
    // console.warn(date)
    this.orderListGet()
  }

  formatTime = (timestamp, datePrefix = '-', timePrefix = ':') => {
    let date = new Date(timestamp)
    const year = date.getFullYear()
    const month =
      date.getMonth() + 1 >= 10
        ? date.getMonth() + 1
        : `0${date.getMonth() + 1}`
    const day = date.getDate() >= 10 ? date.getDate() : `0${date.getDate()}`
    const hour = date.getHours() >= 10 ? date.getHours() : `0${date.getHours()}`
    const minute =
      date.getMinutes() >= 10 ? date.getMinutes() : `0${date.getMinutes()}`
    const second =
      date.getSeconds() >= 10 ? date.getSeconds() : `0${date.getSeconds()}`
    return `${year}${datePrefix}${month}${datePrefix}${day}  ${hour}${timePrefix}${minute}${timePrefix}${second}`
    // return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
  }
  orderListGet = () => {
    Network.post(
      Api.EWM_DETAIL,
      {
        params: {
          type: 0
        }
      },
      res => {
        if (res.code === 200) {
          let nodata = res.data.orderList.length < 1 ? true : false
          this.setData({
            orderList: res.data.orderList.map(item => {
              item.createDate = this.formatTime(item.createDate)
              item.stateText = this.data.statusWitch[item.state]
              return item
            }),
            nodata: nodata
          })
        }
      }
    )
  }
  telCall = () => {
    Taro.makePhoneCall({
      phoneNumber: this.data.mobile
    })
  }
  config = {
    navigationBarTitleText: '购买记录'
  }

  render() {
    const { orderList: orderList, nodata: nodata, mobile: mobile } = this.state
    return (
      <View className='container'>
        <ScrollView scrollY>
          <View className='main-container'>
          {orderList.length > 0 ? (
            orderList.map((order, index) => {
              // eslint-disable-next-line react/jsx-key
              return <View className='list-view'>
                <View className='li-view'>
                    <View className='t-view'>
                        <Text>下单时间：{order.createDate}</Text>
                        <Text className='status'>{order.stateText}</Text>
                    </View>
                    <View className='c-view'>
                        <View className='p-view'>
                            <Text className='label-view'>支付金额：</Text>￥{order.totalPrice}</View>
                        <View className='p-view'>
                            <Text className='label-view'>购买数量：</Text>{order.buyNumber}套</View>
                        <View className='p-view'>
                            <Text className='label-view'>客户姓名：</Text>{order.receiver}</View>
                        <View className='p-view'>
                            <Text className='label-view'>联系电话：</Text>{order.receiverPhone}</View>
                        <View className='p-view'>
                            <Text className='label-view'>邮寄地址：</Text>
                            <Text className='flex-addr'>{order.receiverAdress}</Text>
                        </View>
                    </View>
                    {
                      order.wlName && order.oddNumber && <View class='express-view'>
                          <View className='p-view'>
                              <Text className='label-view'>快递公司：</Text>{order.wlName}</View>
                          <View className='p-view'>
                              <Text className='label-view'>快递单号：</Text>{order.oddNumber}</View>
                      </View>
                    }
                </View>
              </View>
            })
            
          ) : (
            <View  className='flex_hm flex_hc flex_v nodataBox'>
                <Image className='nodata' mode='widthFix' src='https://apph5.mmcqing.com/xcx/images/nodata.png'></Image>
                <Text className='nodata_text'>暂无记录</Text>
            </View>
          )}
          <View className='copy-view'>
              <Text className='c'>本服务由和路宝提供</Text>
              <View className='c'>客服电话：
                  <View bindtap='telCall' className='tel'>
                      <Text>{ mobile }</Text>
                  </View>
              </View>
          </View>
          {/* {orderList.map((item, index) => {
            return (
              <View className='main-container'>
                {orderList.length > 0 && (
                  <Block>
                    {orderList.map((order, index) => {
                      return (
                        <View className='list-view' key='unique'>
                          <View className='li-view'>
                            <View className='t-view'>
                              <Text>{'下单时间：' + order.createDate}</Text>
                              <Text className='status'>{order.stateText}</Text>
                            </View>
                            <View className='c-view'>
                              <View className='p-view'>
                                <Text className='label-view'>支付金额：</Text>
                                {'￥' + order.totalPrice}
                              </View>
                              <View className='p-view'>
                                <Text className='label-view'>购买数量：</Text>
                                {order.buyNumber + '套'}
                              </View>
                              <View className='p-view'>
                                <Text className='label-view'>客户姓名：</Text>
                                {order.receiver}
                              </View>
                              <View className='p-view'>
                                <Text className='label-view'>联系电话：</Text>
                                {order.receiverPhone}
                              </View>
                              <View className='p-view'>
                                <Text className='label-view'>邮寄地址：</Text>
                                <Text className='flex-addr'>
                                  {order.receiverAdress}
                                </Text>
                              </View>
                            </View>
                            {order.wlName && order.oddNumber && (
                              <View className='express-view'>
                                <View className='p-view'>
                                  <Text className='label-view'>快递公司：</Text>
                                  {order.wlName}
                                </View>
                                <View className='p-view'>
                                  <Text className='label-view'>快递单号：</Text>
                                  {order.oddNumber}
                                </View>
                              </View>
                            )}
                          </View>
                        </View>
                      )
                    })}
                  </Block>
                )}
                {orderList.length < 1 && nodata && (
                  <View className='flex_hm flex_hc flex_v nodataBox'>
                    <Image
                      className='nodata'
                      mode='widthFix'
                      src='https://apph5.mmcqing.com/xcx/images/nodata.png'
                    />
                    <Text className='nodata_text'>暂无记录</Text>
                  </View>
                )}
                <View className='copy-view'>
                  <Text className='c'>本服务由和路宝提供</Text>
                  <View className='c'>
                    客服电话：
                    <View onClick={this.telCall} className='tel'>
                      <Text>{mobile}</Text>
                    </View>
                  </View>
                </View>
              </View>
            )
          })} */}
          </View>
        </ScrollView>
      </View>
    )
  }
}

export default _C
