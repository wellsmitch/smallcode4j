import { Block, View, Image, Text, Input, Button } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
//index.js
//获取应用实例
import { Api, Network, validate } from '../../../utils/index.js'
import './onlineExpMain.scss'
const app = Taro.getApp()

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    mobile: Taro.getApp().globalData.mobile,
    multiIndex: [0, 0],
    multiArray: [],
    platePrefix: '',
    codeList: {
      // '豫': ['A', 'B', 'C', 'D', 'E', 'F'],
      // '鄂': ['C', 'D', 'E', 'F', 'G', 'H']
    },
    plateNumber: '',
    phoneNumber: '',
    canIUse: Taro.canIUse('button.open-type.getUserInfo'),
    showConfirmPanel: false,
    codeshow: false,
    codeshowNum: '获取验证码',
    canGetCode: true, // 是否可以获取验证码
    codeNo: '',
    submitBtn: false,
    showModel: false,
    cityCodeArr: [],
    cityArr: [],
    showlabgb: false,
    showCityt: true,
    showCodecity: false,
    plateCode: [],
    sett: true
  }
  bindViewTap = () => {
    Taro.navigateTo({
      url: '../logs/logs'
    })
  }
  codeNum = e => {
    //验证码输入
    this.setData({
      codeNo: e.detail.value
    })
  }
  getCode = () => {
    if (this.data.codeshowNum == '获取验证码' && this.data.canGetCode) {
      this.data.canGetCode = false
      if (this.data.phoneNumber.length != 11) {
        Taro.showToast({
          title: '请输入11位手机号码',
          icon: 'none'
        })
        return false
      }
      app.msgGets(this.data.phoneNumber, res => {
        this.setData({
          codeshowNum: 60,
          submitBtn: true
        })
        let setTime = setInterval(() => {
          let num = this.data.codeshowNum
          num--
          this.setData({
            codeshowNum: num
          })
          if (num < 1) {
            clearInterval(setTime)
            setTime = null
            this.setData({
              codeshowNum: '获取验证码',
              canGetCode: true
            })
          }
        }, 1000)
      })
    }
  }

  componentWillMount() {
    var that = this
    this.carInfoGet()
    Taro.getSetting({
      success: function(res) {
        if (res.authSetting['scope.camera']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称
          that.setData({
            sett: false
          })
        } else {
          that.setData({
            sett: true
          })
        }
      }
    })
  }

  componentWillUnmount () {
    Taro.getApp().globalData.cardata = '';
  }
  componentDidShow() {
    let cardata = Taro.getApp().globalData.cardata;

    if (cardata.length > 5) {
      let arr = []
      for (let i = 0; i < cardata.length; i++) {
        arr.push(cardata[i])
      }

      let platePrefix = arr[0]
      let arrcode = arr.slice(1)
      console.log(arrcode)
      this.setData({
        platePrefix: platePrefix,
        plateCode: arrcode
      })
      let plateNumber = ''
      for (let i = 0; i < this.data.plateCode.length; i++) {
        plateNumber += this.data.plateCode[i]
      }
      this.setData({
        plateNumber: plateNumber
      })
      console.log(this.data.plateNumber)
    }
  }

  carInfoGet = () => {
    let prefixList = Taro.getStorageSync('CAR_PRFIX_LIST')
    console.log(prefixList)
    // if (prefixList) { // 默认从缓存取
    //     this.setData({
    //         codeList: prefixList
    //     });
    //     this.dataCityInit();
    // } else {
    // Network.post(Api.RULE_CARD_INFO, {
    //     params: {
    //         time: 0
    //     }
    // }, (data) => {
    //     console.log(data)
    //     if (data.code === 200) {
    //         let _store = {};
    //         (data.data || []).map(item => {
    //             _store[item.title] = (item.capitals || []).map(item2 => {
    //                 return item2.title;
    //             })
    //         })
    //         // wx.setStorageSync('CAR_PRFIX_LIST', _store);
    //         this.setData({
    //             codeList: _store
    //         });
    //         this.dataCityInit();
    //     }
    // })
    // }
    this.dataCityInit()
  }
  dataCityInit = () => {
    // 请求后台
    // let _l = Object.keys(this.data.codeList);
    // let _t = [
    //     [..._l],
    //     [...this.data.codeList[_l[0]]]
    // ];
    // console.log(_t)

    let _t = []
    _t[0] = [
      '豫',
      '冀',
      '皖',
      '琼',
      '京',
      '沪',
      '黑',
      '陕',
      '甘',
      '津',
      '贵',
      '川',
      '藏',
      '宁',
      '粤',
      '赣',
      '桂',
      '鲁',
      '辽',
      '湘',
      '新',
      '渝',
      '苏',
      '云',
      '青',
      '晋',
      '鄂',
      '蒙',
      '吉',
      '闽',
      '浙',
      '使'
    ]
    _t[1] = [
      [
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        0,
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'J',
        'K',
        'L',
        'M',
        'N',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V'
      ],
      ['W', 'X', 'Y', 'Z', '学', '领', '警', '挂']
    ]
    this.setData({
      multiArray: _t,
      cityArr: [
        _t[0].slice(0, 10),
        _t[0].slice(10, 19),
        _t[0].slice(19, 27),
        _t[0].slice(27)
      ],
      cityCodeArr: _t[1]
    })
  }
  phoneBlur = e => {
    this.setData({
      phoneNumber: e.detail.value
    })
    if (this.data.phoneNumber.length == 11) {
      this.setData({
        codeshow: true
      })
    } else {
      this.setData({
        codeshow: false
      })
    }
  }
  plateBlur = e => {
    this.setData({
      plateNumber: e.detail.value
    })
  }
  bindMultiPickerChange = e => {
    this.setData({
      multiIndex: e.detail.value
    })
  }
  bindMultiPickerColumnChange = e => {
    // console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    let data = {
      multiArray: this.data.multiArray,
      multiIndex: this.data.multiIndex
    }
    data.multiIndex[e.detail.column] = e.detail.value
    if (e.detail.column === 0) {
      let _c = this.data.multiArray[0][e.detail.value]
      data.multiArray[1] = this.data.codeList[_c]
    }
    this.setData(data)
    let _p = `${data.multiArray[0][data.multiIndex[0]]}${
      data.multiArray[1][data.multiIndex[1]]
    }`
    this.setData({
      platePrefix: _p
    })
  }

  bindUser () {
    console.log(1231231)
    Network.post(
      Api.MOVE_CAR_CEWM,
      {
        params: {
          plateNum: `${this.data.platePrefix}${this.data.plateNumber}`,
          phoneNum: this.data.phoneNumber,
          code: this.data.codeNo
        }
      },
      res => {
        Taro.hideLoading()
        if (res.code && res.code == 200) {
          
          Taro.getApp().globalData.cardata = '';
          // wx.showToast({title: '申请成功'});
          Taro.setStorage({
            key: 'EX_QR_PIC_URL',
            data: res.data.movecar_pic_url
          })
          Taro.redirectTo({
            url: `/pages/onlineExp/createQR/createQR?imgUrl=${
              res.data.movecar_pic_url
            }`
          })
        } else {
          if (res.code == -1) {
            Taro.showToast({
              title: res.message,
              icon: 'none'
            })
          } else {
            Taro.showToast({
              title: '申请失败，请重试',
              icon: 'none'
            })
          }
        }
      }
    )
  }

  moveCarCreate = () => {
    let plateNumber = this.data.plateNumber.trim()
    if (!this.data.platePrefix || !plateNumber || plateNumber.length < 6) {
      Taro.showToast({
        title: '请输入有效车牌号',
        icon: 'none'
      })
      return
    }
    let phoneNumber = this.data.phoneNumber
    if (!phoneNumber || !validate.phoneNumber(phoneNumber)) {
      Taro.showToast({
        title: '请输入11位有效的手机号码',
        icon: 'none'
      })
      return
    }
    if (!this.data.submitBtn) {
      Taro.showToast({
        title: '请先发送验证码',
        icon: 'none'
      })
      return
    }
    let codeNoNumber = this.data.codeNo
    if (!codeNoNumber || !validate.codeNumber(codeNoNumber)) {
      Taro.showToast({
        title: '请输入6位数字验证码',
        icon: 'none'
      })
      return
    }
    Taro.showLoading({
      title: '加载中...'
    })
    console.log('aaaaaaaaaaaaaaaa')
    if(Taro.getApp().globalData.token){
      console.log('123131223')
      this.bindUser();
      return;
    }
    my.httpRequest({
      method: 'post',
      url: Taro.getApp().globalData.apiUrl + 'api/thirdparty/bind', // 该url是自己的服务地址，实现的功能是服务端拿到authcode去开放平台进行token验证
      data: {
        type: 'hlbsm-zfbxcx',
        openid: Taro.getApp().globalData.openId,
        phone: this.data.phoneNumber,
        password: this.data.codeNo,
      },
      success: (res) => {
        if(res.data.code==200){
            Taro.getApp().globalData.token = res.data.data.token;
            Taro.getApp().globalData.phone = res.data.data.phone;
            Taro.getApp().globalData.isBind = true;
            this.bindUser();
        }else{
          Taro.hideLoading();
          my.alert({
            title:'提示',
            content:res.data.message
          })
        }
      }
    })
    
  }
  telCall = () => {
    Taro.makePhoneCall({
      phoneNumber: this.data.mobile
    })
  }
  showCity = e => {
    this.setData({
      showModel: true,
      showlabgb: true,
      showCityt: true,
      showCodecity: false
    })
  }
  showCityc = () => {
    let last = false
    console.log(this.data.showModel, this.data.plateCode.length)
    if (!this.data.showModel && this.data.plateCode.length == 7) {
      last = true
    } else {
      last = false
    }
    this.setData({
      showModel: true,
      showlabgb: false,
      showCityt: false,
      showCodecity: true,
      last: last
    })
  }
  plateCity = e => {
    if (this.data.plateCode.length < 6) {
      this.setData({
        platePrefix: e.target.dataset.item,
        showlabgb: false,
        showCityt: false,
        showCodecity: true
      })
    } else {
      this.setData({
        platePrefix: e.target.dataset.item,
        showModel: false,
        showlabgb: false,
        showCityt: false,
        showCodecity: true
      })
    }
  }
  closeMode = () => {
    this.setData({
      showModel: false,
      last: false
    })
  }
  platecodeCity = e => {
    if (e.target.dataset.item < 10 && this.data.plateCode.length == 0) {
      return
    }
    console.log(e.target.dataset.item > 'Z')
    if (e.target.dataset.item > 'Z' && this.data.plateCode.length < 5) {
      return
    }
    if (this.data.plateCode.length < 6) {
      let code = this.data.plateCode
      code.push(e.target.dataset.item)
      this.setData({
        plateCode: code
      })
    } else {
      if (this.data.plateCode.length == 6) {
        let code = this.data.plateCode
        code.push(e.target.dataset.item)
        if (this.data.platePrefix.length < 1) {
          this.setData({
            plateCode: code,
            showModel: true,
            showlabgb: false,
            showCityt: true,
            showCodecity: false
          })
        } else {
          this.setData({
            plateCode: code,
            showModel: false,
            showlabgb: false,
            showCityt: false,
            showCodecity: true,
            last: false
          })
        }
      } else {
        this.setData({
          showModel: false,
          showlabgb: false,
          showCityt: false,
          showCodecity: true
        })
      }
    }
    let plateNumber = ''
    for (let i = 0; i < this.data.plateCode.length; i++) {
      plateNumber += this.data.plateCode[i]
    }
    this.setData({
      plateNumber: plateNumber
    })
    console.log(this.data.plateNumber)
  }
  removeCode = () => {
    let arr = this.data.plateCode
    if (arr.length > 0) {
      arr.pop()
      this.setData({
        plateCode: arr
      })
    } else {
      this.setData({
        platePrefix: '',
        showModel: true,
        showlabgb: true,
        showCityt: true,
        showCodecity: false
      })
    }
    let plateNumber = ''
    for (let i = 0; i < this.data.plateCode.length; i++) {
      plateNumber += this.data.plateCode[i]
    }
    this.setData({
      plateNumber: plateNumber,
      last: false
    })
    console.log(this.data.plateNumber)
  }
  chooseImage = () => {
    Taro.getApp().globalData.cameUrl = '/pages/onlineExp/onlineExpMain/onlineExpMain'
    Taro.redirectTo({
      url: '../../chooseImage/chooseImage'
    })
  }
  focuss = () => {
    this.setData({
      showModel: false,
      showlabgb: false,
      showCityt: true,
      showCodecity: false
    })
  }
  config = {
    navigationBarTitleText: '线 上 体 验'
  }

  render() {
    const {
      showlabgb: showlabgb,
      platePrefix: platePrefix,
      plateCode: plateCode,
      showModel: showModel,
      showCodecity: showCodecity,
      last: last,
      codeshow: codeshow,
      codeNo: codeNo,
      codeshowNum: codeshowNum,
      mobile: mobile,
      showCityt: showCityt,
      cityArr: cityArr,
      cityCodeArr: cityCodeArr
    } = this.state
    return (
      <View className="container">
        {/*  <view class="public-view">
                                              <image src="https://apph5.mmcqing.com/xcx/images/online-public.png" class="image"></image>
                                              <text>和路宝-公众号</text>
                                              <view class="attr-view"><text>关注</text></view>
                                            </view>  */}
        <View className="top-view">
          <Image
            className="image"
            src="https://apph5.mmcqing.com/xcx/images/online-top-bg.png"
          />
          <View className="text-view">
            <View className="form-view">
              <View className="t-view">
                <Text>车辆信息</Text>
              </View>
              <View className="input-view">
                <View
                  className={'label ' + (showlabgb ? 'active' : '')}
                  onClick={this.showCity}
                >
                  {platePrefix}
                  <Image
                    className="code_cellImg"
                    src="https://apph5.mmcqing.com/xcx/images/gb.gif"
                  />
                </View>
                <View className="input flex_hm" onClick={this.showCityc}>
                  <View
                    className={
                      'code_cell flex_hm flex_hc ' +
                      (plateCode.length == 0 && showModel && showCodecity
                        ? 'active'
                        : '')
                    }
                  >
                    <View>{plateCode[0]}</View>
                    <Image
                      className="code_cellImg"
                      src="https://apph5.mmcqing.com/xcx/images/gb.gif"
                    />
                  </View>
                  <View
                    className={
                      'code_cell flex_hm flex_hc ' +
                      (plateCode.length == 1 && showModel && showCodecity
                        ? 'active'
                        : '')
                    }
                  >
                    <View>{plateCode[1]}</View>
                    <Image
                      className="code_cellImg"
                      src="https://apph5.mmcqing.com/xcx/images/gb.gif"
                    />
                  </View>
                  <View
                    className={
                      'code_cell flex_hm flex_hc ' +
                      (plateCode.length == 2 && showModel && showCodecity
                        ? 'active'
                        : '')
                    }
                  >
                    <View>{plateCode[2]}</View>
                    <Image
                      className="code_cellImg"
                      src="https://apph5.mmcqing.com/xcx/images/gb.gif"
                    />
                  </View>
                  <View
                    className={
                      'code_cell flex_hm flex_hc ' +
                      (plateCode.length == 3 && showModel && showCodecity
                        ? 'active'
                        : '')
                    }
                  >
                    <View>{plateCode[3]}</View>
                    <Image
                      className="code_cellImg"
                      src="https://apph5.mmcqing.com/xcx/images/gb.gif"
                    />
                  </View>
                  <View
                    className={
                      'code_cell flex_hm flex_hc ' +
                      (plateCode.length == 4 && showModel && showCodecity
                        ? 'active'
                        : '')
                    }
                  >
                    <View>{plateCode[4]}</View>
                    <Image
                      className="code_cellImg"
                      src="https://apph5.mmcqing.com/xcx/images/gb.gif"
                    />
                  </View>
                  <View
                    className={
                      'code_cell flex_hm flex_hc ' +
                      (plateCode.length == 5 && showModel && showCodecity
                        ? 'active'
                        : '')
                    }
                  >
                    <View>{plateCode[5]}</View>
                    <Image
                      className="code_cellImg"
                      src="https://apph5.mmcqing.com/xcx/images/gb.gif"
                    />
                  </View>
                  <View
                    className={
                      'code_cell flex_hm flex_hc ' +
                      ((plateCode.length == 6 && showModel && showCodecity) ||
                      last
                        ? 'active'
                        : '')
                    }
                  >
                    <View>{plateCode[6]}</View>
                    <Image
                      className="code_cellImg"
                      src="https://apph5.mmcqing.com/xcx/images/gb.gif"
                    />
                  </View>
                  {/*  <input maxlength="6" type="text" bindinput="plateBlur" placeholder="请输入车牌号" placeholder-class="placeholderClass" />  */}
                </View>
                <View className="chooseImage" onClick={this.chooseImage}>
                  <Image
                    className="chooseImage_icon"
                    src="https://apph5.mmcqing.com/xcx/images/xiangji.png"
                  />
                </View>
              </View>
            </View>
            <View className="form-view">
              <View className="t-view">
                <Text>联系电话</Text>
              </View>
              <View className="input-view">
                <View className="input">
                  <Input
                    type="number"
                    onFocus={this.focuss}
                    maxlength="11"
                    onInput={this.phoneBlur}
                    placeholder="请输入电话号码"
                    placeholderClass="placeholderClass"
                  />
                </View>
              </View>
            </View>
            {codeshow && (
              <View className="form-view">
                <View className="t-view">
                  <Text>验证码</Text>
                </View>
                <View className="input-view">
                  <View className="input flex">
                    <Input
                      type="number"
                      onFocus={this.focuss}
                      maxlength="6"
                      onInput={this.codeNum}
                      placeholder="请输入验证码"
                      placeholderClass="placeholderClass"
                      value={codeNo}
                    />
                    <Button
                      className="getCode"
                      onClick={this.getCode}
                      hoverClass="getCodeColor"
                    >
                      {codeshowNum}
                    </Button>
                  </View>
                </View>
              </View>
            )}
          </View>
          <View className="desc-view">请先绑定车牌号，以便享受挪车服务</View>
        </View>
        <View className="main-container">
          <View className="btn-apply" onClick={this.moveCarCreate}>
            生成挪车码
          </View>
        </View>
        <View className="copy-view">
          <Text className="c">本服务由和路宝提供</Text>
          <View className="c">
            客服电话：
            <View onClick={this.telCall} className="tel">
              <Text>{mobile}</Text>
            </View>
          </View>
        </View>
        <View className={'keyboardmode ' + (showModel ? 'active' : '')}>
          <View className="keyboardmode_title">
            <View
              className="modeClose flex_hm flex_hc"
              onClick={this.closeMode}
            >
              关闭
            </View>
          </View>
          <View className={'keyboardmode_city ' + (showCityt ? 'active' : '')}>
            <View className="citybox flex_hm flex_hc">
              {cityArr[0].map((item, index) => {
                return (
                  <View
                    hoverClass="hoveractive"
                    className="citybox_cell flex_hm flex_hc"
                    data-item={item}
                    onClick={this.plateCity}
                    key
                  >
                    {item}
                  </View>
                )
              })}
            </View>
            <View className="citybox flex_hm flex_hc">
              {cityArr[1].map((item, index) => {
                return (
                  <View
                    hoverClass="hoveractive"
                    className="citybox_cell flex_hm flex_hc"
                    data-item={item}
                    onClick={this.plateCity}
                    key
                  >
                    {item}
                  </View>
                )
              })}
            </View>
            <View className="citybox flex_hm flex_hc">
              {cityArr[2].map((item, index) => {
                return (
                  <View
                    hoverClass="hoveractive"
                    className="citybox_cell flex_hm flex_hc"
                    data-item={item}
                    onClick={this.plateCity}
                    key
                  >
                    {item}
                  </View>
                )
              })}
            </View>
            <View className="cityboxLast citybox flex_hm flex_hc">
              {cityArr[3].map((item, index) => {
                return (
                  <View
                    hoverClass="hoveractive"
                    className="citybox_cell flex_hm flex_hc"
                    data-item={item}
                    onClick={this.plateCity}
                    key
                  >
                    {item}
                  </View>
                )
              })}
              <View
                hoverClass="hoveractive"
                className="removePlace citybox_cell flex_hm flex_hc"
                onClick={this.removeCode}
              >
                <Image
                  mode="aspectFit"
                  className="removePlaceimg"
                  src="https://apph5.mmcqing.com/xcx/images/removeCae.png"
                />
              </View>
            </View>
          </View>
          <View
            className={'keyboardmode_code ' + (showCodecity ? 'active' : '')}
          >
            <View className="citycodebox flex_hm flex_hc">
              {cityCodeArr[0].map((item, index) => {
                return (
                  <View
                    hoverClass="hoveractive"
                    className={
                      'citybox_cell flex_hm flex_hc ' +
                      (index < '10' && plateCode.length == 0 ? 'disable' : '')
                    }
                    data-index={index}
                    data-item={item}
                    onClick={this.platecodeCity}
                    key
                  >
                    {item}
                  </View>
                )
              })}
            </View>
            <View className="citycodebox flex_hm flex_hc last">
              {cityCodeArr[1].map((item, index) => {
                return (
                  <View
                    hoverClass="hoveractive"
                    className={
                      'citybox_cell flex_hm flex_hc ' +
                      (index > 3 && plateCode.length < 5 ? 'disable' : '')
                    }
                    data-index={index}
                    data-item={item}
                    onClick={this.platecodeCity}
                    key
                  >
                    {item}
                  </View>
                )
              })}
              <View
                hoverClass="hoveractive"
                className="removePlace citybox_cell flex_hm flex_hc"
                onClick={this.removeCode}
              >
                <Image
                  mode="aspectFit"
                  className="removePlaceimg"
                  src="https://apph5.mmcqing.com/xcx/images/removeCae.png"
                />
              </View>
            </View>
          </View>
        </View>
      </View>
    )
  }
}

export default _C
