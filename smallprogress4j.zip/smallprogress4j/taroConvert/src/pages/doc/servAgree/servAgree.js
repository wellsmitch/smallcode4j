import { Block, View, Image, ScrollView, Text } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
import './servAgree.scss'
//index.js
//获取应用实例
const app = Taro.getApp()

@withWeapp('Page')
class _C extends Taro.Component {
  state = {
    mobile: Taro.getApp().globalData.mobile
  }

  componentWillMount() {}

  telCall = () => {
    Taro.makePhoneCall({
      phoneNumber: this.data.mobile
    })
  }
  config = {
    navigationBarTitleText: '服务协议'
  }

  render() {
    const { mobile: mobile } = this.state
    return (
      <Block>
        {/* index.wxml */}
        <View>
          {/* <ScrollView scrollY> */}
            <Image className="container-img" model='aspectFit' src="https://apph5.mmcqing.com/xcx/images/zfb-service.jpg" />
            {/* <View className="main-container">
              <View className="main-title">
                <Text>扫码挪车服务协议</Text>
              </View>
              <View className="list-panel">
                <Text className="t-view">协议简述</Text>
                <Text className="c-view">
                  本协议是使用和路宝扫码挪车服务的用户（以下简称“用户”或“您”）和和路宝之间关于用户使用和路宝挪车码服务（以下简称“本服务”）所达成的。请您仔细阅读本协议，您在购买“和路宝”挪车码后，本协议即构成对双方有约束力的法律文件。本服务是指您在线申请购买挪车码并绑定车辆和手机号等相关信息后，如您临时停车挡住其他车主出行，他人扫描您本人申请并绑定的二维码后，可通过二维码虚拟电话或短信通知您及时挪车的服务。该二维码称为“挪车码”。
                </Text>
                <Text className="t-view">一、服务及使用说明</Text>
                <Text className="c-view">
                  1.您使用本服务生成的挪车码为您个人专属挪车码。您在收到挪车贴后请及时扫码绑定车辆信息和您的联系方式。您在完成绑定后请将挪车贴粘贴在挡风玻璃显眼处。此时如您临时停车挡住他人出行时，他人可通过扫码虚拟电话或短信通知您及时挪车。
                </Text>
                <Text className="c-view">
                  2.系统通过虚拟电话或短信的方式通知挪车，双方电话号码互不可见，保证隐私安全。
                </Text>
                <Text className="c-view">
                  3.如您需要重新绑定车辆信息及联系方式，您可打开微信，扫描挪车码输入新的信息或进入和路宝首页，点击我的，选择我的挪车码，输入新的信息即可重新绑定。
                </Text>
                <Text className="t-view">二、您的权利和义务</Text>
                <Text className="c-view">
                  1.针对本服务，您理解并同意挪车码绑定粘贴后他可通过扫码虚拟电话或短信通知您挪车。
                </Text>
                <Text className="c-view">
                  2.针对本服务，如您还有其他疑问可致电客服电话进行答疑。客服电话位于扫码挪车首页最下方。
                </Text>
                <Text className="c-view">
                  3.您购买挪车码，即视为您已阅读、理解
                  并完全同意本协议的各项内容，并具有独立承担法律责任的能力。
                </Text>
                <Text className="c-view">
                  4.和路宝在必要时可修改本协议，您可以及时查看。如您继续使用本服务，则视为您已接收修订的服务协议。
                </Text>
                <Text className="t-view">三、和路宝的权利和义务</Text>
                <Text className="c-view">
                  1.您同意，根据业务发展等情况，和路宝可能调整“扫码挪车”所支持的服务内容，例如对本服务进行升级、拓展、调整收费价格及方式等
                </Text>
                <Text className="c-view">
                  2.和路宝将运用各种安全技术和程序建立完善的管理制度来保护您的个人信息，以免遭受未经授权的访问、使用或披露。和路宝不对外向任何第三方提供、公开或共享您的资料，但下列情况除外：
                </Text>
                <Text className="c-view">1）有关法律要求披漏的；</Text>
                <Text className="c-view">
                  2）国家相关机关、部门基于法定程序要求提供的；
                </Text>
                <Text className="c-view">
                  3）为完成公司合并、分立、收购或资产转让而转移的。
                </Text>
                <Text className="c-view">
                  3.和路宝将按照您填写的挪车码邮寄地址为您寄送服务物料。和路宝不承担责任，包括但不仅限于：
                </Text>
                <Text className="c-view">
                  1）因不可抗力、系统故障、通信故障、网络拥堵、供电系统故障、恶意攻击等造成未能及时、准确、完整地提供本服务。
                </Text>
                <Text className="c-view">
                  2）如用户利用系统差错、故障或其他原因导致的漏洞，损害和路宝的权益，和路宝将终止为该用户提供本服务，并保留追究法律责任的权利。
                </Text>
                <Text className="c-view">
                  3）和路宝负责对扫码挪车上的信息进行审核与更新，但并不就信息的时效性、准确性以及服务功能的完整性和可靠性承担任何义务和赔偿责任。
                </Text>
                <Text className="t-view">四、挪车服务费用</Text>
                <Text className="c-view">
                  1.费用明细：车贴物料费：全国统一价19.90元（偏远地区包括新疆维吾尔自治区、西藏自治区等，暂不支持邮寄。挪车码在使用过程中没有额外费用，仅会在拨叫过程中产生拨叫本人通话资费标准的市话费。）
                </Text>
                <Text className="t-view">五、争议的解决</Text>
                <Text className="c-view">
                  1.本协议签定地为河南省郑州市中原区。
                </Text>
                <Text className="c-view">
                  2.本协议的签订、生效、履行争议的解决均适用中华人民共和国法律。
                </Text>
                <Text className="c-view">
                  3、本协议下的任何争议，双方应友好协商解决。协商不成的，您同意将协议提交本协议签订地有管辖权的人民法院管辖。
                </Text>
              </View>
              <View className="copy-view">
                <Text className="c">本服务由和路宝提供</Text>
                <View className="c">
                  客服电话：
                  <View onClick={this.telCall} className="tel">
                    <Text>{mobile}</Text>
                  </View>
                </View>
              </View>
            </View> */}
          {/* </ScrollView> */}
        </View>
      </Block>
    )
  }
}

export default _C
