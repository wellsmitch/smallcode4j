import Taro, { Component, Config } from '@tarojs/taro'
import { View, Image, Input, Button, Text } from '@tarojs/components'

import { IMAGE_HOTS } from '../../utils/base'

const util = require('../../utils/_md5.js');

import './login.scss'

class Index extends Component {

  config: Config = {
    navigationBarTitleText: '扫码挪车'
  }
  state = {
    isLogin:false,
    isCode:false,
    from:'',
    goodsId:'',
    phone:'',
    code:'',
    IsLoginShow:false,
    sms_zt: '发送验证码',
    second: 60,
    nullHouse1: true,
    nullHouse2: false,
    mode:'widthFix'
  }
  bindKeyInput (e) {
    this.setState({
        phone: e.detail.value,
    });
  }
  bindKeyCode (e) {
    this.setState({
        code: e.detail.value
    });
  }
  
  
  getcode(){
    var phone = this.state.phone;
    if(!phone){
      my.alert({
        title: '提示',
        content: '手机号不能为空' 
      });
    }else{
      let phoneReg = /^1[0-9]{10}$/;
      if (!phoneReg.test(phone)){
        my.alert({
          title:'提示',
          content:'请输入正确的手机号'
        })
      }else{
        let that = this;
        that.countdown(that);
        let random = this.randomWord(true, 32, 32);
        let timestamp =  new Date().getTime();
        let secret_key = '1234567';
        console.log('Taro')
        let signature = util.hexMD5('phone=' + phone + '&random=' + random + '&timestamp=' + timestamp + '&secret_key=' + secret_key);
        // console.log(signature);
        my.httpRequest({
          method: 'post',
          url: Taro.getApp().globalData.apiUrl + 'api/oauth/sms/bind', // 该url是自己的服务地址，实现的功能是服务端拿到authcode去开放平台进行token验证
          data: {
            phone: phone,
            random: random,
            timestamp: timestamp,
            signature: signature,
          },
          success: (res) => {
            //console.log(res);
            if(res.data.code==200){
              
            }
          }
        })
      }
    }
  }
  login(){
    let that = this;
    let phone = this.state.phone;
    let code = this.state.code;
    if(!phone){
      my.alert({
        title: '提示',
        content:'手机号不能为空'
      })
      return false;
    }
    if(!code){
      my.alert({
        title: '提示',
        content: '验证码不能为空'
      })
      return false;
    }
    my.httpRequest({
      method: 'post',
      url: Taro.getApp().globalData.apiUrl + 'api/thirdparty/bind', // 该url是自己的服务地址，实现的功能是服务端拿到authcode去开放平台进行token验证
      data: {
        type: 'hlbsm-zfbxcx',
        openid: Taro.getApp().globalData.openId,
        phone:phone,
        password: code,
      },
      success: (res) => {
        if(res.data.code==200){
            Taro.getApp().globalData.token = res.data.data.token;
            Taro.getApp().globalData.phone = res.data.data.phone;
            Taro.getApp().globalData.isBind = true;
            if(Taro.getApp().globalData.goToUrl == '/pages/login/login'){
              my.navigateBack({
                delta: 1
              })
            }else {
              my.redirectTo({
                url: Taro.getApp().globalData.goToUrl
              })
            }
            // Taro.navigateTo({
            //     url: Taro.getApp().globalData.goToUrl;
            //   })
        //   that.setState({
        //     phone:'',
        //     code:''
        //   })
        //   if(that.state.from=='my'){
        //     my.switchTab({
        //       url:'/pages/my/index'
        //     })
        //   }else{
        //     my.redirectTo({
        //       url:'/pages/productDetails/index?id='+that.state.goodsId
        //     })
        //   }
        }else{
          my.alert({
            title:'提示',
            content:res.data.message
          })
        }
        //that.countdown(that);
      }
    })
  }
  randomWord(randomFlag, min, max){//生成随机数
    var str = "",
      pos,
    range = min,
    arr =['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
    // 随机产生
    if(randomFlag) {
      range = Math.round(Math.random() * (max - min)) + min;
    }
    for(var i = 0; i<range; i++){
    pos = Math.round(Math.random() * (arr.length - 1));
    str += arr[pos];
  }
  return str;
  }
  countdown(that){
    var second = that.state.second;
    if(second==0){
      that.setState({
        second: 60,
        nullHouse1: true,
        nullHouse2: false
      });
      return;
    }
    var time = setTimeout(function(){
      that.setState({
        second: second - 1,
        nullHouse1: false,
        nullHouse2: true
      })
      this.countdown(that);
    }.bind(this),1000)
  }

  render () {
    
    return (
        <View className='loginBox'>
            <View className="login-title">验证码登录</View>
            <View className="login-form">
            <View className="login-row">
                <View className="login-label">手机号</View>
                <Input type='number' onInput={this.bindKeyInput} placeholder="请输入手机号"/>
            </View>
            <View className="login-row">
                <View className="login-label">验证码</View>
                <Input type='number' maxLength={6} onInput={this.bindKeyCode} placeholder="请输入验证码"/>
                {
                    this.state.nullHouse1 && <Button type="default" onClick={()=>this.getcode()} data-mess="{{sms_zt}}">{this.state.sms_zt}</Button>
                }
                {
                    this.state.nullHouse2 && <Button type="default">{this.state.second}s后重新获取</Button>
                }
            </View>
            <View className="login-btn">
                <Button className="default" onClick={this.login}>登录</Button>
            </View>
            </View>
        </View>
    )
  }
}

// #region 导出注意
//
// 经过上面的声明后需要将导出的 Taro.Component 子类修改为子类本身的 props 属性
// 这样在使用这个子类时 Ts 才不会提示缺少 JSX 类型参数错误
//
// #endregion

export default Index
