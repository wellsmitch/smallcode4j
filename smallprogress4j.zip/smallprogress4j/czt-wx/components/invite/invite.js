var app = getApp();
Component({
    properties: {},
    data: {

    },
    methods: {
        Jump() {
            // this.triggerEvent('Jump', {}, {});
            wx.navigateTo({
                url: '/pages/activities/inviteEarnMoney/inviteEarnMoney',
            })
        }
    }
})