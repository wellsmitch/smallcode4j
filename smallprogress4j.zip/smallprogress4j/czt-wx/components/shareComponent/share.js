var app = getApp(); 
Component({
  properties: {},
  data: {
  },
  methods: {  
  }
})