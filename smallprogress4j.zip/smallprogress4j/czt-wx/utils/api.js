// let _prefix = 'https://apps.mmcqing.com:8084';
let _prefix = 'https://apps.mmcqing.com:18089';
// let _prefix = 'https://www.mmcqing.com:8083';
// let _prefix = 'http://www.pgyer.com/mmcq'
const Api = {
    HTTPS: _prefix,
    FULL_USER_INFO: _prefix + '/api/thirdparty/xcx/user', // 用户信息补全
    INTERFACE_TEST: _prefix + '/test',
    openId: _prefix +'/api/thirdparty/wx/xcx/openid',//获取openid;
    DYNAMIC_PRICE: _prefix + '/api/movecar/unitPrice', // 动态获取车贴价格
    MOVE_CAR_CEWM: _prefix + '/api/movecar/cewm', // 体验码申请
    RULE_CARD_INFO: _prefix + '/api/v3/rule/carInfo', // 城市简称集合
    EWM_DETAIL: _prefix + '/api/movecar/ewmdetail', // 订单或挪车码列表
    C_ORDER: _prefix + '/api/movecar/cOrder', // 购买下单
    BIND_EWM: _prefix + '/api/movecar/bindewm', // 绑挪车码
    CEWM_INFO: _prefix + '/api/movecar/cewminfo', // 我的订单，挪车码的数量统计
    XCX_PAY: _prefix + '/api/weixin/xcx/pay', // 小程序统一支付
    UPDATE_BIND_EWM: _prefix + '/api/movecar/updateEwm', // 更改绑定车贴
    AUTH_LOGIN: _prefix + '/api/thirdparty/login', // 授权登录
    AUTH_BIND: _prefix + '/api/thirdparty/bind', // 授权绑定接口 
    PARE_WM: _prefix + '/api/xcx/parewm', // 判断扫码跳转
    PHONE_NUMBER_GET: _prefix + '/api/thirdparty/phone', // 手机号解析
    SMS_GET: _prefix + '/api/oauth/sms/bind', // 发送短信接口
    HOME_RESOURCES: _prefix + "/api/v3/xcx/h5/resources", //首页功能接口
    SMS_MESSAGE: _prefix +"/api/push/message",//发送短信通知车主挪车
    CLOUD_MIRROR: _prefix +"/api/v1/cloud-mirror/",//绑定设备接口
    IMG_EXAMPLE: _prefix+"/api/v1/video/queryTransgressCodeList",//图片示例接口
    INVITE_COUNT: _prefix + '/api/movecar/inviteCount', // 统计用户邀请好友数 和展示详情
    USER_ID: _prefix + '/api/v3/user/token/user', // 查看用戶的userid
    CAN_CONVERT: _prefix + '/api/movecar/canConvert', // 可兑换车贴数量
    VIEW_MORE: _prefix + '/api/movecar/viewMore', // 查看更多分享好友
    TELL_BIND: _prefix + '/api/new/third/tell/bind', // 电话拨打/new/third/tell/bind
    APPOINTMENT_CONVERT: _prefix + '/api/movecar/convert', // 免费兑换接口
    MESSAGE_INFO: _prefix +"/api/movecar/push/message",
    GET_MOBILE_SMS: _prefix + '/api/mobile/dsms', // 获取短信验证码（新的）
    lpr: _prefix+'/api/ocr/xlpr',//解析车牌接口
    lpraddcarmsg: _prefix + '/api/ocr/xsz ',//添加车辆信息  解析车牌接口
    inviteInfo: _prefix+"/api/movecar/inviteInfo",//统计用户邀请成功数，购买数量，佣金
    withdraw: _prefix +"/api/movecar/withdraw",//提现申请
    movecarInviteCount: _prefix + "/api/movecar/movecarInviteCount",//统计邀请好友购买挪车贴信息
    withdrawRecord: _prefix +"/api/movecar/withdrawRecord",//佣金提现记录
    faceInvite: _prefix +"/api/movecar/faceInvite",//面对面邀请生成二维码
    addcarmsg: _prefix + "/api/v3/user/addcar",//添加车辆信息
    searchcartype: _prefix + "/api/v3/czt/car/type",//查询车辆类型
    vipopen: _prefix + "/api/v3/czt/dg",//开通vip接口
    phoneok: _prefix + "/api/v3/czt/phone/msg", //手机号运行商信息接口
    basephone: _prefix +  "/api/parking/user/phone", //查询之前的手机号
}
export default Api;