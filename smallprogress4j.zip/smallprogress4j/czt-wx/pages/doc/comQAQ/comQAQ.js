//index.js
//获取应用实例
const app = getApp();
Page({
  data: {
    mobile: getApp().globalData.mobile
  },
  onLoad: function () {
  },
  telCall: function () {
    wx.makePhoneCall({
      phoneNumber: this.data.mobile
    })
  }
})
