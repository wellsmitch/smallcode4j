import {
    Network,
    Api
} from "../../utils/index";
var md5 = require('../../utils/md5.js');
//index.js
//获取应用实例
// var WXBizDataCrypt = require('../../utils/WXBizDataCrypt')

const app = getApp();
Page({
    data: {
        imgSrc: app.globalData.imgUrlHost,
        mobile: getApp().globalData.mobile,
        motto: 'Hello World',
        priceImg: 'https://apph5.mmcqing.com/xcx/images/czt/index-top-pic.png?time=' + Math.random() * 10,
        userInfo: {

        },
        hasUserInfo: false,
        canIUse: wx.canIUse('button.open-type.getUserInfo'),
        session_key: '',
        login_code: '',
        phoneAuth: false,
        showMsgPanel: false,
        phoneNumber: '',
        msgBtnText: '发送短信验证码',
        msgCanClick: true,
        timer: null,
        msgCode: '',
        openId: '',
        redrectUrl: '',
        toParam: '',
        userInfo: true,
        recommenduserid: '',
        clickTimeout: false,
        userid:""
    },
    gonavTo() {
        wx.redirectTo({
            url: '/pages/userCenter/userCenter'
        })
    },
    bindShareUser: function() {},
    calcTokenGet: function() {
        let count = 0;
        let timer = setInterval(() => {
            if (app.globalData.login_code) {
                this.setData({
                    login_code: app.globalData.login_code
                });
            }
            // console.log(app.globalData.token);
            if (!app.globalData.token) { //需授权
                this.setData({
                    phoneAuth: true
                });
            } else {
                this.setData({
                    phoneAuth: false,
                    clickTimeout:true
                });
                clearInterval(timer);
            }
            count++;
            if (count >= 15) {
                this.setData({
                    clickTimeout: true
                });
                clearInterval(timer);
            }
        }, 100)
    },
    onShow: function() {
        // console.log(this.data.recommenduserid);
        this.setting(); //检查授权
        this.calcTokenGet();

    },
    onLoad: function(options) {

        if (options.recommenduserid) {
            this.setData({
                recommenduserid: options.recommenduserid
            });
        }
        if (options.q) {
            let opac = decodeURIComponent(options.q || '');
            let usertype = opac.split('?u=')[1];
            this.setData({
                userid: usertype
            });
        }
        if (options.u){
            
            this.setData({
                userid: options.u
            });  
        }
    },
    modalConfirm: function(e) { // 弹框确认
        let _e = e;
        _e.detail.recommenduserid = this.data.recommenduserid;
        app.confirm(_e, () => {
            // this.selectComponent("#componentId").modalCancel();
            this.setData({
                phoneAuth: false
            });
            if (app.globalData.login_code) {
                this.fullUserINFO();
            }
            wx.navigateTo({
                url: this.data.redrectUrl
            })
        })
    },
    toBuyCenter(e) { //我的授权 

        if (app.globalData.token) {
            wx.navigateTo({
                url: '/pages/userCenter/userCenter'
            })
            return;
        } else {
            this.setData({
                redrectUrl: '/pages/userCenter/userCenter'
            })
            let _e = e;
            if (this.data.recommenduserid) {
                _e.detail.recommenduserid = this.data.recommenduserid;
            }
            this.bindPhone(e);
        }
    },
    toBuy: function(e) { // 购买授权判断
        console.log(e)
        if (!this.data.clickTimeout) {
            return;
        }
        this.setData({
            clickTimeout: false
        })
        let setTim = setTimeout(() => {
            this.setData({
                clickTimeout: true
            })
            clearTimeout(setTim);
            setTim = null;
        }, 500)
        if (app.globalData.token) {
            if(this.data.userid){
                wx.navigateTo({
                    url: '/pages/buyProgress/buyMain/buyMain?userid=' + this.data.userid
                })
            }else{
                wx.navigateTo({
                    url: '/pages/buyProgress/buyMain/buyMain'
                })
            }
            
            return;
        } else {
            if (this.data.userid) {
                this.setData({
                    redrectUrl: '/pages/buyProgress/buyMain/buyMain?userid=' + this.data.userid
                })
            } else {
                this.setData({
                    redrectUrl: '/pages/buyProgress/buyMain/buyMain'
                })
            }
            
            
            let _e = e;
            if (this.data.recommenduserid) {
                _e.detail.recommenduserid = this.data.recommenduserid;
            }
            this.bindPhone(e);
        }

    },
    bindPhone(e) {
        console.log(e)
        let that = this;
        wx.showLoading({
            title: '加载中...',
        })
        app.accredit(e, (res) => {
            console.log(res)
            wx.removeStorageSync("click");
            // wx.hideLoading();
            console.log(that.data.recommenduserid)
            if (that.data.recommenduserid) {
                res.data.recommenduserid = that.data.recommenduserid;
            }
            console.log(res)
            app.confirm(res.data, () => {
                wx.hideLoading();
                // this.selectComponent("#componentId").modalCancel();
                that.setData({
                    phoneAuth: false
                });
                if (app.globalData.login_code) {
                    that.fullUserINFO();
                }
                wx.navigateTo({
                    url: that.data.redrectUrl
                })
            })
        });
    },
    goOnlineExp: function(e) { // 体验授权
        if (app.globalData.token) { // 有toen则跳回
            wx.navigateTo({
                url: '/pages/onlineExp/onlineExpMain/onlineExpMain'
            })
            return;
        }
        this.setData({
            redrectUrl: '/pages/onlineExp/onlineExpMain/onlineExpMain'
        })
        let _e = e;
        if (this.data.recommenduserid) {
            _e.detail.recommenduserid = this.data.recommenduserid;
        }
        this.bindPhone(e);
    },
    telCall: function() { // 打电话
        wx.makePhoneCall({
            phoneNumber: this.data.mobile
        })
    },
    fullUserINFO: function() { // 补全用户信息
        wx.getSetting({
            success: function(res) {
                if (res.authSetting['scope.userInfo']) {
                    // 已经授权，可以直接调用 getUserInfo 获取头像昵称
                    console.log(123)
                    if (app.globalData.token) {
                        wx.login({
                            success: res => {
                                Network.post(Api.AUTH_LOGIN, {
                                    params: {
                                        type: 'czt-xcx',
                                        code: res.code,
                                        nickname: app.globalData.userInfo.nickName,
                                        headimgurl: app.globalData.userInfo.avatarUrl
                                    },
                                    loading: false
                                }, (res) => {
                                    // console.error(res);
                                })
                            }
                        })
                       
                    }
                }
            }
        })

    },
    toCenter: function(e) { // 跳转到个人中心
        let _e = e.detail;
        if (_e.errMsg === 'getUserInfo:ok') { // 授权成功
            console.log(e);
            app.globalData.userInfo = JSON.parse(_e.rawData);
            console.log(app.globalData);
            if (app.globalData.login_code) {
                this.fullUserINFO();
            }
            this.setting()
            this.gonavTo()
        }else{
            this.gonavTo()
        }
        // 授权处理

    },
    setting() { //检查授权
        let that = this;
        wx.getSetting({
            success(res) {
                console.log(res)
                if (!res.authSetting['scope.userInfo']) {
                    that.setData({
                        userInfo: true
                    })


                } else {
                    wx.getUserInfo({
                        success: function(res) {
                            app.globalData.userInfo = JSON.parse(res.rawData);
                        },
                        fail: function() {
                            wx.showToast({
                                title: '获取用户信息失败',
                                icon: "none"
                            })
                        },
                        complete: function() {
                            console.log("获取用户信息完成！")
                        }
                    })
                    // app.globalData.userInfo = JSON.parse(_e.rawData);
                    that.setData({
                        userInfo: false
                    })
                }

            }
        })
    }
})