//index.js
//获取应用实例
import {
    Api,
    Network
} from '../../../utils/index'
const app = getApp()
Page({
    data: {},
    request: function(options) {
        let _url = decodeURIComponent(options.q || '');
        let _sendInfo = _url.split('?')[1];
      // _sendInfo ='p=olgO6EaK_1';
    ///////////////////////////////
      // _sendInfo = 'p=X0VaaVzr_1'
          // ///////////////////////////////
        // _sendInfo = 'p=VMu6uh8k_1';
        // _sendInfo = "p=olgO6EaK_1";
        // _sendInfo = "p=KEpssmVs_1";
      Network.get(`${Api.PARE_WM}?${_sendInfo}&source=3`, { loading:false}, (res) => {
          console.log(res)
          app.globalData.isvip = res.data.data.state
          // return;
            wx.hideLoading();
            if (res.data && res.data.code === 200) {
                let _ret = res.data.data;   
                switch (_ret.resPage) {
                    case '0': // 详情页
                        let param = res.data.data || {};
                        wx.redirectTo({
                            url: '/pages/scan/usedQR/usedQR?param=' + JSON.stringify(param)
                        })
                        break; // 修改
                    case '1'://
                        let cparam = {
                            carNum: _ret.carNum,
                            phone: _ret.phone,
                            id: _ret.id,
                            type: 1
                        }
                        wx.redirectTo({
                            url: '/pages/scan/modifyQR/modifyQR?param=' + JSON.stringify(cparam)
                        })
                        break;
                    case '2': // 绑定
                        wx.redirectTo({
                            url: '/pages/scan/bindQR/bindQR?id=' + _ret.id
                        })
                        break;
                    case '3': // 绑定
                        wx.redirectTo({
                            url: '/pages/onlineExp/createQR/createQR?imgUrl=' + _ret.car_pic_url
                        })
                        break;
                    case '4': // 绑定
                        let params = res.data.data || {};
                        wx.redirectTo({
                            url: '/pages/scan/usedQR/usedQR?param=' + JSON.stringify(params)
                        })
                        break;
                    case '5': // 绑定
                        wx.redirectTo({
                            url: '/pages/onlineExp/createQR/createQR?imgUrl=' + _ret.car_pic_url
                        })
                        break;
                }
            } else {

            }
        })
    },
    onLoad: function(options) {
        wx.showLoading({
            title: '加载中...',
            mask: true
        })
        let count = 0;
        let timer = setInterval(() => {
            if (app.globalData.token) {
                this.request(options);
                clearInterval(timer)
            }
            if (app.globalData.notoken){
                this.request(options);
                clearInterval(timer)
            }
            count++;
            if (count === 20) {
                this.request(options);
                clearInterval(timer);
            }
        }, 150)
    }
})