//index.js
//获取应用实例
import {
    Api,
    Network,
    validate
} from '../../../utils/index'
const app = getApp()
Page({
    data: {
        mobile: getApp().globalData.mobile,
        multiIndex: [0, 0],
        multiArray: [],
        platePrefix: '',
        codeList: {},
        plateNumber: '',
        phoneNumber: '',
        userInfo: {
            avatarUrl: `https://apph5.mmcqing.com/xcx/images/wx-ic-bg.jpg`
        },
        hasUserInfo: false,
        moveCarId: '',
        canIUse: wx.canIUse('button.open-type.getUserInfo'),
        moveData: '',
        canClick: true,
        storeOld: {
            plateNumber: '',
            phoneNumber: ''
        },
        // msgBtnText: '发送短信验证码',
        showConfirmPanel: false,
        codeshow: false,
        codeshowNum: "获取验证码",
        canGetCode: true,   // 是否可以获取验证码
        codeNo: "",
        submitBtn: false,
        showModel: false,
        cityCodeArr: [],
        cityArr: [],
        showlabgb: false,
        showCityt: true,
        showCodecity: false,
        plateCode: [],
        cardata: ""
    },
    getCode() {
      if (this.data.codeshowNum == "获取验证码" && this.data.canGetCode) {
        this.data.canGetCode = false;
            if (this.data.phoneNumber.length!=11){
                wx.showToast({
                    title: '请输入11位手机号码',
                    icon:'none'
                })
                return false;
            }
            app.msgGets(this.data.phoneNumber, (res) => {
                this.setData({
                    codeshowNum: 60,
                    submitBtn: true
                })
                let setTime = setInterval(() => {
                    let num = this.data.codeshowNum;
                    num--
                    this.setData({
                        codeshowNum: num
                    })
                    if (num < 1) {
                        clearInterval(setTime);
                        setTime = null;
                        this.setData({
                            codeshowNum: "获取验证码",
                          canGetCode: true
                        })
                    }
                }, 1000)
            });

        }

    },
    getUserInfo: function(e) { // 首次授权执行
        let detail = e.detail;
        if (detail.errMsg === 'getUserInfo:ok') { // 授权成功
            app.globalData.userInfo = detail.userInfo;
            this.setData({
                userInfo: detail.userInfo
            });
        } else {
            wx.showToast({
                content: '授权失败',
                icon: 'none'
            });
        }
    },
    getStoreUserInfo: function() { // 已经授权执行缓存取
        if (app.globalData.userInfo) {
            this.setData({
                userInfo: app.globalData.userInfo
            });
        } else {
            wx.getSetting({
                success: (res) => {
                    if (res.authSetting['scope.userInfo']) { // 已授权
                        wx.getUserInfo({
                            success: (res) => {
                                app.globalData.userInfo = res.userInfo;
                                this.setData({
                                    userInfo: res.userInfo
                                });
                                if (this.userInfoReadyCallback) {
                                    this.userInfoReadyCallback(res)
                                }
                            }
                        })
                    }
                }
            })
        }
    },
    onLoad: function(options) {
      // debugger
        this.getStoreUserInfo();
        this.setData({
            moveData: JSON.parse(options.param)
        });
        let platecar = this.data.moveData.carNum.slice(1, 9);
        let arr=[];
        for (let i = 0; i < platecar.length;i++){
            arr.push(platecar[i])
        }
        this.setData({
            platePrefix: this.data.moveData.carNum.slice(0, 1),
            plateNumber: this.data.moveData.carNum.slice(1, 9),
            phoneNumber: this.data.moveData.phone,
            moveCarId: this.data.moveData.id,
            plateCode:arr

        })
        this.setData({
            storeOld: {
                phoneNumber: this.data.moveData.phone,
                plateNumber: this.data.moveData.carNum
            }
        })
        this.carInfoGet();

    },
    onShow() {
        if (this.data.cardata.length > 5) {
            let arr = [];
            for (let i = 0; i < this.data.cardata.length; i++) {
                arr.push(this.data.cardata[i])
            }

            let platePrefix = arr[0];
            let arrcode = arr.slice(1);
            this.setData({
                platePrefix: platePrefix,
                plateCode: arrcode
            })
            let plateNumber = "";
            for (let i = 0; i < this.data.plateCode.length; i++) {
                plateNumber += this.data.plateCode[i];
            }
            this.setData({
                plateNumber: plateNumber,
            })

        }
    },
    carInfoGet: function() {
        // let prefixList = wx.getStorageSync('CAR_PRFIX_LIST');
        // if (prefixList) { // 默认从缓存取
        //     this.setData({
        //         codeList: prefixList
        //     });
        //     this.dataCityInit();
        // } else {
        //     Network.post(Api.RULE_CARD_INFO, {
        //         params: {
        //             time: 0
        //         }
        //         // loading: false
        //     }, (data) => {
        //         if (data.code === 200) {
        //             let _store = {};
        //             (data.data || []).map(item => {
        //                 _store[item.title] = (item.capitals || []).map(item2 => {
        //                     return item2.title;
        //                 })
        //             })
        //             wx.setStorageSync('CAR_PRFIX_LIST', _store);
        //             this.setData({
        //                 codeList: _store
        //             });
        //             this.dataCityInit();
        //         }
        //     })
        // }
        this.dataCityInit();
    },
    dataCityInit: function() {
        // 请求后台
        let _t = []
        _t[0] = ["豫", "冀", "皖", "琼", "京", "沪", "黑", "陕", "甘", "津", "贵", "川", "藏", "宁", "粤", "赣", "桂", "鲁", "辽", "湘", "新", "渝", "苏", "云", "青", "晋", "鄂", "蒙", "吉", "闽", "浙", "使"]
        _t[1] = [[1, 2, 3, 4, 5, 6, 7, 8, 9, 0, "A", "B", "C", "D", "E", "F", "G", "H", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "U", "V"], ["W", "X", "Y", "Z", "学", "领", "警", "挂"]]
        this.setData({
            multiArray: _t,
            cityArr: [_t[0].slice(0, 10), _t[0].slice(10, 19), _t[0].slice(19, 27), _t[0].slice(27)],
            cityCodeArr: _t[1],
        })
    },
    codeNum(e) { //验证码输入
        this.setData({
            codeNo: e.detail.value
        });
    },
    phoneBlur: function(e) {//手机号输入
        this.setData({
            phoneNumber: e.detail.value
        });
        if (this.data.phoneNumber != this.data.storeOld.phoneNumber && this.data.phoneNumber.length==11) {
            this.setData({
                codeshow: true
            })
        } else {
            this.setData({
                codeshow: false
            })
        }
    },
    plateBlur: function(e) {//车牌号输入
        this.setData({
            plateNumber: e.detail.value
        });
        if (this.data.phoneNumber != this.data.storeOld.phoneNumber && this.data.phoneNumber.length == 11) {
            this.setData({
                codeshow: true
            })
        } else {
            this.setData({
                codeshow: false
            })
        }
    },
    bindMultiPickerChange: function(e) {
        this.setData({
            multiIndex: e.detail.value
        })
    },
    bindMultiPickerColumnChange: function(e) {
        let data = {
            multiArray: this.data.multiArray,
            multiIndex: this.data.multiIndex
        };
        data.multiIndex[e.detail.column] = e.detail.value;
        if (e.detail.column === 0) {
            let _c = this.data.multiArray[0][e.detail.value];
            data.multiArray[1] = this.data.codeList[_c];
        }
        this.setData(data);
        let _p = `${data.multiArray[0][data.multiIndex[0]]}${data.multiArray[1][data.multiIndex[1]]}`
        this.setData({
            platePrefix: _p
        });
    },
    moveCarCreate: function() {
       
        let plateNumber = this.data.plateNumber.trim();
        if (!this.data.platePrefix||!plateNumber || plateNumber.length < 6 ) {
            wx.showToast({
                title: '请输入有效车牌号',
                icon: 'none'
            });
            return;
        }
        let phoneNumber = this.data.phoneNumber;
        if (!phoneNumber || !validate.phoneNumber(phoneNumber)) {
            wx.showToast({
                title: '请输入11位有效的手机号码',
                icon: 'none'
            });
            return;
        }
       
        let param = {
            plateNum: `${this.data.platePrefix}${this.data.plateNumber}`,
            phoneNum: this.data.phoneNumber,
            id: this.data.moveCarId,
            code: this.data.codeNo
        }
        let phone = this.data.storeOld.phoneNumber;
        let plate = this.data.storeOld.plateNumber.slice(2);
        if (phone !== phoneNumber ) {
            if (!this.data.submitBtn) {
                wx.showToast({
                    title: '请发送验证码',
                    icon: "none"
                })
                return false;
            }
            let codeNoNumber = this.data.codeNo
            if (!codeNoNumber || !validate.codeNumber(codeNoNumber)) {
                wx.showToast({
                    title: '请输入6位数字验证码',
                    icon: 'none'
                });
                return;
            }
        }
        if (!this.data.canClick) {
            return;
        }
        this.setData({
            canClick: false
        });
        Network.post(Api.UPDATE_BIND_EWM, {
            params: param,
            loading: false
        }, (res) => {
          console.log(res,99999999)
            this.setData({
                canClick: true
            })
            if (res.code && res.code == 200) {
             
                // wx.showToast({title: '修改成功'});
                wx.redirectTo({
                    url: '/pages/scan/success/success?type=modify'
                })
            } else {
                // wx.hideLoading();
                wx.showToast({
                    title: res.message,
                    icon: 'none',
                    duration: 5000
                });
            }
        }, () => {
            this.setData({
                canClick: true
            })
        })
    },
    telCall: function() {
        wx.makePhoneCall({
            phoneNumber: this.data.mobile
        })
    },
    showCity: function (e) {
        this.setData({
            showModel: true,
            showlabgb: true,
            showCityt: true,
            showCodecity: false
        })


    },
    focuss() {
        this.setData({
            showModel: false,
            showlabgb: false,
            showCityt: true,
            showCodecity: false
        })
    },
    showCityc() {
        let last = false;
        if (!this.data.showModel && this.data.plateCode.length == 7) {
            last = true;
        } else {
            last = false;
        }
        this.setData({
            showModel: true,
            showlabgb: false,
            showCityt: false,
            showCodecity: true,
            last: last
        })
    },
    plateCity(e) {
        if (this.data.plateCode.length < 6) {
            this.setData({
                platePrefix: e.target.dataset.item,
                showlabgb: false,
                showCityt: false,
                showCodecity: true
            })
        } else {
            this.setData({
                platePrefix: e.target.dataset.item,
                showModel: false,
                showlabgb: false,
                showCityt: false,
                showCodecity: true
            })
        }
    },
    closeMode() {
        this.setData({
            showModel: false,
            last: false
        })
    },
    platecodeCity(e) {

        // this.plateNumber + e.target.dataset.item
        if (e.target.dataset.item < 10 && this.data.plateCode.length == 0) {
            return;
        }
        if (e.target.dataset.item > "Z" && this.data.plateCode.length < 5) {
            return;
        }
        if (this.data.plateCode.length < 6) {
            let code = this.data.plateCode;
            code.push(e.target.dataset.item);
            this.setData({
                plateCode: code,
            })
        } else {
            if (this.data.plateCode.length == 6) {
                let code = this.data.plateCode;
                code.push(e.target.dataset.item);
                if (this.data.platePrefix.length < 1) {
                    this.setData({
                        plateCode: code,
                        showModel: true,
                        showlabgb: false,
                        showCityt: true,
                        showCodecity: false
                    })
                } else {
                    this.setData({
                        plateCode: code,
                        showModel: false,
                        showlabgb: false,
                        showCityt: false,
                        showCodecity: true,
                        last: false
                    })
                }

            } else {
                this.setData({
                    showModel: false,
                    showlabgb: false,
                    showCityt: false,
                    showCodecity: true,
                   
                })
            }

        }

        let plateNumber = "";
        for (let i = 0; i < this.data.plateCode.length; i++) {
            plateNumber += this.data.plateCode[i];
        }
        this.setData({
            plateNumber: plateNumber,
        })

    },
    removeCode() {
        let arr = this.data.plateCode;
        if (arr.length > 0) {
            arr.pop();
            this.setData({
                plateCode: arr
            })
        } else {
            this.setData({
                platePrefix: "",
                showModel: true,
                showlabgb: true,
                showCityt: true,
                showCodecity: false
            })
        }
        let plateNumber = "";
        for (let i = 0; i < this.data.plateCode.length; i++) {
            plateNumber += this.data.plateCode[i];
        }
        this.setData({
            plateNumber: plateNumber,
            last: false
        })
    },
    chooseImage() {
        wx.navigateTo({
            url: '../../chooseImage/chooseImage'
        })
    },
    hrefnavite(e){
    }
})