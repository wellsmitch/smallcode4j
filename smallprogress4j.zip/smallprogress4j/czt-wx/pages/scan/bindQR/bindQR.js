//index.js
//获取应用实例
import {
  Api,
  Network,
  validate
} from '../../../utils/index'
const app = getApp()
Page({
  data: {
    mobile: getApp().globalData.mobile,
    multiIndex: [0, 0],
    multiArray: [],
    platePrefix: '',
    codeList: {},
    plateNumber: '',
    phoneNumber: '',
    moveCarId: '',
    authShow: false,
    authInfo: {
      phoneNumber: '',
      openid: ''
    },
    userInfo: {
      avatarUrl: `https://apph5.mmcqing.com/xcx/images/wx-ic-bg.jpg`
    },
    msgBtnText: '发送短信验证码',
    msgCanClick: true,
    showMsgPanel: false,
    showModal: false,
    timer: null,
    msgCode: '',
    test: {
      a: 1
    },
    // msgBtnText: '发送短信验证码',
    showConfirmPanel: false,
    codeshow: false,
    codeshowNum: "获取验证码",
    codeNo: "",
    submitBtn: false,
    showModel: false,
    cityCodeArr: [],
    cityArr: [],
    showlabgb: false,
    showCityt: true,
    showCodecity: false,
    plateCode: [],
    cardata: "",
    clickTimeout: true,
    phoneAuth: "",
    userphone: '',
    userisvip: false,
    oldVip: true,

    oldVip1: true,

    tokenphone:''
  },

  // 弹窗 start
  // tanchaung: function () {
  //   this.setData({
  //     showModal: true
  //   })

  // },
  calcTokenGet: function () {
    let count = 0;
    let timer = setInterval(() => {
      if (app.globalData.login_code) {
        this.setData({
          login_code: app.globalData.login_code
        });
      }
      // console.log(app.globalData.token);
      if (!app.globalData.token) { //需授权
        this.setData({
          phoneAuth: true
        });
      } else {
        this.setData({
          phoneAuth: false,
          clickTimeout: true
        });
        this.getPhone();
        clearInterval(timer);
      }
      count++;
      if (count >= 15) {
        this.setData({
          clickTimeout: true
        });
        clearInterval(timer);
      }
    }, 100)
  },
  hideModal: function() {
    this.setData({
      showModal: false
    });
  },
  // isvip() {

  // },
  onCancel: function() {
    this.setData({
      showModal: false
    });
    // this.hideModal();
  },
  // onConfirm: function () {
  //   this.hideModal();
  //   wx.navigateTo({
  //     url: '../../chooseImage/chooseImage'
  //   })
  // },

  // 开通vip
  openvip() {
    // 历史vip客户
    console.log(this.data.oldVip, 'rrrtttt')
    if (this.data.oldVip) {
      console.log(app.globalData.province, app.globalData.company)
      Network.post(Api.vipopen, {
        params: {
          type: '01',
          province: '河南',
          company: '移动'
        }
      }, (res) => {
        console.log(res,8888888866666)
        if (res.code == 200) {
          wx.redirectTo({
            url: '/pages/userCenter/userCenter'
          })
        }
      })
    } else {
      wx.redirectTo({
        url: '/pages/scan/addvip/addvip'
      })
    }


  },
  // 弹窗 end



  getCode() {
    var that = this;
    if (this.data.codeshowNum == "获取验证码") {
      if (this.data.phoneNumber.length != 11) {
        wx.showToast({
          title: '请输入11位手机号码',
          icon: 'none'
        })
        return false;
      }
      console.log(this.data.tokenphone,888888888)
      if (this.data.tokenphone){
        console.log('进入有token的手机号的逻辑')
        // 发送验证码
        app.msgGets(this.data.phoneNumber, (res) => {
          that.setData({
            codeshowNum: 60,
            submitBtn: true
          })
          let setTime = setInterval(() => {
            let num = that.data.codeshowNum;
            num--
            that.setData({
              codeshowNum: num
            })
            if (num < 1) {
              clearInterval(setTime);
              setTime = null;
              that.setData({
                codeshowNum: "获取验证码"
              })
            }
            // console.log('验证码动作')
          }, 1000)
        });
      }else{
        wx.request({
          url: Api.phoneok, // 仅为示例，并非真实的接口地址
          method: 'post',
          data: {
            phone: that.data.phoneNumber
          },
          header: {
            'content-type': 'application/x-www-form-urlencoded' // 默认值
          },
          success(res) {
            console.log(res,'wwwwwwwwwwww')
            if (res.data.data.province != '河南') {
              wx.showToast({
                title: '请输入归属地为河南省得手机号',
                icon: 'none'
              });
              return;
            } else if (res.data.data.company != '移动') {
              wx.showToast({
                title: '请输入中国移动手机号',
                icon: 'none'
              });
              return;
            } else {
              app.globalData.mobliePhoneNumber = that.data.phoneNumber;
              app.globalData.province = res.data.data.province;
              app.globalData.company = res.data.data.company;
              // 发送验证码
              app.msgGets(this.data.phoneNumber, (res) => {
                that.setData({
                  codeshowNum: 60,
                  submitBtn: true
                })
                let setTime = setInterval(() => {
                  let num = that.data.codeshowNum;
                  num--
                  that.setData({
                    codeshowNum: num
                  })
                  if (num < 1) {
                    clearInterval(setTime);
                    setTime = null;
                    that.setData({
                      codeshowNum: "获取验证码"
                    })
                  }
                }, 1000)
              });

            }
          }
        })
      }

      // Network.post(Api.phoneok, {
      //   params: {
      //     phone: that.data.phoneNumber
      //   }
      // }, (res) => {
      //   if (res.data.province != '河南') {
      //     wx.showToast({
      //       title: '请输入归属地为河南省得手机号',
      //       icon: 'none'
      //     });
      //     return;
      //   } else if (res.data.company != '移动') {
      //     wx.showToast({
      //       title: '请输入中国移动手机号',
      //       icon: 'none'
      //     });
      //     return;
      //   }else {
      //     app.globalData.mobliePhoneNumber = that.data.phoneNumber;
      //     app.globalData.province = res.data.province;
      //     app.globalData.company = res.data.company;
      // 发送验证码
      // app.msgGets(this.data.phoneNumber, (res) => {
      //   this.setData({
      //     codeshowNum: 60,
      //     submitBtn: true
      //   })
      //   let setTime = setInterval(() => {
      //     let num = this.data.codeshowNum;
      //     num--
      //     this.setData({
      //       codeshowNum: num
      //     })
      //     if (num < 1) {
      //       clearInterval(setTime);
      //       setTime = null;
      //       this.setData({
      //         codeshowNum: "获取验证码"
      //       })
      //     }
      //   }, 1000)
      // });
      // }
      // })


    }

  },
  getUserInfo: function(e) { // 首次授权执行
    let detail = e.detail;
    if (detail.errMsg === 'getUserInfo:ok') { // 授权成功
      app.globalData.userInfo = detail.userInfo;
      this.setData({
        userInfo: detail.userInfo
      });
    } else {
      wx.showToast({
        content: '授权失败',
        icon: 'none'
      });
    }
  },
  getStoreUserInfo: function() { // 已经授权执行缓存取
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo
      });
    } else {
      wx.getSetting({
        success: (res) => {
          if (res.authSetting['scope.userInfo']) { // 已授权
            wx.getUserInfo({
              success: (res) => {
                app.globalData.userInfo = res.userInfo;
                this.setData({
                  userInfo: res.userInfo
                });
                if (this.userInfoReadyCallback) {
                  this.userInfoReadyCallback(res)
                }
              }
            })
          }
        }
      })
    }
  },
  getPhone(){
    Network.post(Api.basephone, { params: {} }, (res) => {
      if (res.code == 200) {
        console.log(res)
        this.setData({
          tokenphone:res.data.phone
        })
      }
    })
  },
  onLoad: function(options) {
    this.getStoreUserInfo();
    let phoneAuth = false
    if (app.globalData.token) {
      phoneAuth = false;
    } else {
      phoneAuth = true
    }
    this.setData({
      moveCarId: options.id,
      phoneAuth: phoneAuth
    });
    this.carInfoGet();


  },
  onShow() {
    this.calcTokenGet();
    if (this.data.cardata.length > 5) {
      let arr = [];
      for (let i = 0; i < this.data.cardata.length; i++) {
        arr.push(this.data.cardata[i])
      }

      let platePrefix = arr[0];
      let arrcode = arr.slice(1);
      this.setData({
        platePrefixdrefix,
        plateCode: arrcode
      })
      let plateNumber = "";
      for (let i = 0; i < this.data.plateCode.length; i++) {
        plateNumber += this.data.plateCode[i];
      }
      this.setData({
        plateNumber: plateNumber,
      })

    }
  },
  carInfoGet: function() { // 获取车牌信息
    // let prefixList = wx.getStorageSync('CAR_PRFIX_LIST');
    // if (prefixList) { // 默认从缓存取
    //     this.setData({
    //         codeList: prefixList
    //     });
    //     this.dataCityInit();
    // } else {
    // Network.post(Api.RULE_CARD_INFO, {
    //     params: {
    //         time: 0
    //     }
    // }, (data) => {
    //     if (data.code === 200) {
    //         let _store = {};
    //         (data.data || []).map(item => {
    //             _store[item.title] = (item.capitals || []).map(item2 => {
    //                 return item2.title;
    //             })
    //         })
    //         wx.setStorageSync('CAR_PRFIX_LIST', _store);
    //         this.setData({
    //             codeList: _store
    //         });
    //         this.dataCityInit();
    //     }
    // });
    // };
    this.dataCityInit();
  },
  dataCityInit: function() { // 处理
    // 请求后台
    // let _l = Object.keys(this.data.codeList);
    // let _t = [
    //     [..._l],
    //     [...this.data.codeList[_l[0]]]
    // ];
    // let _p = `${_t[0][0]}${_t[1][0]}`;
    let _t = []
    _t[0] = ["豫", "冀", "皖", "琼", "京", "沪", "黑", "陕", "甘", "津", "贵", "川", "藏", "宁", "粤", "赣", "桂", "鲁", "辽", "湘", "新", "渝", "苏", "云", "青", "晋", "鄂", "蒙", "吉", "闽", "浙", "使"]
    _t[1] = [
      [1, 2, 3, 4, 5, 6, 7, 8, 9, 0, "A", "B", "C", "D", "E", "F", "G", "H", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "U", "V"],
      ["W", "X", "Y", "Z", "学", "领", "警", "挂"]
    ]
    this.setData({
      multiArray: _t,
      cityArr: [_t[0].slice(0, 10), _t[0].slice(10, 19), _t[0].slice(19, 27), _t[0].slice(27)],
      cityCodeArr: _t[1],
    })

  },
  phoneBlur: function(e) { // 手机号失去焦点获取值
    this.setData({
      phoneNumber: e.detail.value
    });
    if (this.data.phoneNumber.length == 11) {
      this.setData({
        codeshow: true
      })
    } else {
      this.setData({
        codeshow: false
      })
    }
  },
  codeNum(e) { //验证码输入
    this.setData({
      codeNo: e.detail.value
    });
  },
  plateBlur: function(e) { // 车牌号输入
    this.setData({
      plateNumber: e.detail.value
    });
    if (this.data.phoneNumber.length == 11 && this.data.plateNumber.length > 5 && this.data.plateNumber.length < 8) {
      this.setData({
        codeshow: true
      })
    } else {
      this.setData({
        codeshow: false
      })
    }
  },
  bindMultiPickerChange: function(e) {
    this.setData({
      multiIndex: e.detail.value
    })
  },
  bindMultiPickerColumnChange: function(e) {
    let data = {
      multiArray: this.data.multiArray,
      multiIndex: this.data.multiIndex
    };
    data.multiIndex[e.detail.column] = e.detail.value;
    if (e.detail.column === 0) {
      let _c = this.data.multiArray[0][e.detail.value];
      data.multiArray[1] = this.data.codeList[_c];
    }
    this.setData(data);
    let _p = `${data.multiArray[0][data.multiIndex[0]]}${data.multiArray[1][data.multiIndex[1]]}`
    this.setData({
      platePrefix: _p
    });
  },
  moveCarCreate: function(e) { // 点击判断是否需要授权

    let plateNumber = this.data.plateNumber.trim();
    if (!this.data.platePrefix || !plateNumber || plateNumber.length < 6) {
      wx.showToast({
        title: '请输入有效车牌号',
        icon: 'none'
      });
      return;
    }
    let phoneNumber = this.data.phoneNumber;
    if (!phoneNumber || !validate.phoneNumber(phoneNumber)) {
      wx.showToast({
        title: '请输入11位有效的手机号码',
        icon: 'none'
      });
      return;
    }
    if (!this.data.submitBtn) {
      wx.showToast({
        title: '请先发送验证码',
        icon: 'none'
      })
      return;
    }
    let codeNoNumber = this.data.codeNo
    if (!codeNoNumber || !validate.codeNumber(codeNoNumber)) {
      wx.showToast({
        title: '请输入6位数字验证码',
        icon: 'none'
      });
      return;
    }

    this.setData({
      showConfirmPanel: true
    });

  },
  modalConfirm: function(e) { // 弹框确认操作

  console.log('1:11111')
  
  var that = this;
    console.log(that.data.phoneNumber, that.data.codeNo, '0000000000000')
    this.setData({
      showConfirmPanel: false
    });
    console.log('2:11111')
    if (wx.getStorageSync("TOKEN")) {
      console.log(123333333333333)
      wx.showLoading({
        title: '加载中...',
      })
      this.binNCM();
    } else {
      console.log(45646666666666666)
      wx.showLoading({
        title: '加载中...',
      })
   
      app.getOpenid((res) => {
        app.getOpenids({
          phone: that.data.phoneNumber,
          codeNum: that.data.codeNo
        }, (res) => {
          console.log(res, 'ppppppppppppppp')
          console.log(res,)
          if (res.code == 2001) { //请求成功
          console.log(res,'ppppppppppppppp')
            wx.setStorageSync("TOKEN", res.data.token);
            app.globalData.token = res.data.token;
            this.setData({
              token: true
            })
            this.binNCM();
          } else {
            wx.hideLoading();
            wx.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
      })
    }



  },
  focuss() {
    this.setData({
      showModel: false,
      showlabgb: false,
      showCityt: true,
      showCodecity: false
    })
  },
  binNCM() {
    let that = this;
    Network.post(Api.BIND_EWM, {
      params: {
        plateNum: `${this.data.platePrefix}${this.data.plateNumber}`,
        phoneNum: this.data.phoneNumber,
        id: this.data.moveCarId,
        code: this.data.codeNo
      },
      loading: false
    }, function(res) {
      console.log(res,'')
      wx.hideLoading();
      if (res.code && res.code == 200) {
        wx.redirectTo({
          url: '/pages/scan/success/success?type=bind'
        })
      } else if (res.code == Number('-100') && res.data.state == '0') {
        // 
        console.log(that.data, 'jjjjjjjj')
        if (that.data.tokenphone) {
          that.setData({ //第一次添加会员
            showModal: true,
            oldVip: false
          })
        }else{
          that.setData({ //第一次添加会员
            tokenphone: that.data.phoneNumber,
            showModal: true,
            oldVip: false
          })
        }
        wx.redirectTo({
          url: '/pages/addvip/addvip'
        })

      } else if (res.code == Number('-100') && res.data.state == '1') {
        if (that.data.tokenphone){
          that.setData({ //第一次添加会员
            showModal: true,
            oldVip: true
          })
        }else{
          that.setData({ //第一次添加会员
            tokenphone: that.data.phoneNumber,
            showModal: true,
            oldVip: true
          })
        }
        Network.post(Api.vipopen, {
          params: {
            type: '01',
            province: app.globalData.province,
            company: app.globalData.company
          }
        }, (res) => {
          console.log(res,6666)
          if (res.code == 200) {
            wx.redirectTo({
              url: '/pages/userCenter/userCenter'
            })
          }
        })
        
      }else{
        wx.showToast({
          title: res.message,// 验证码不正确
          icon: 'none',
          duration: 5000
        });
      }
    })
  },
  modalCancel() {
    this.setData({
      showConfirmPanel: false
    });
  },
  telCall: function() {
    wx.makePhoneCall({
      phoneNumber: this.data.mobile
    })
  },
  showCity: function(e) {
    this.setData({
      showModel: true,
      showlabgb: true,
      showCityt: true,
      showCodecity: false
    })


  },
  showCityc() {
    let last = false;
    if (!this.data.showModel && this.data.plateCode.length == 7) {
      last = true;
    } else {
      last = false;
    }
    this.setData({
      showModel: true,
      showlabgb: false,
      showCityt: false,
      showCodecity: true,
      last: last
    })
  },
  plateCity(e) {
    if (this.data.plateCode.length < 6) {
      this.setData({
        platePrefix: e.target.dataset.item,
        showlabgb: false,
        showCityt: false,
        showCodecity: true
      })
    } else {
      this.setData({
        platePrefix: e.target.dataset.item,
        showModel: false,
        showlabgb: false,
        showCityt: false,
        showCodecity: true
      })
    }
  },
  closeMode() {
    this.setData({
      showModel: false,
      last: false
    })
  },
  platecodeCity(e) {

    if (e.target.dataset.item < 10 && this.data.plateCode.length == 0) {
      return;
    }
    if (e.target.dataset.item > "Z" && this.data.plateCode.length < 5) {
      return;
    }
    if (this.data.plateCode.length < 6) {
      let code = this.data.plateCode;
      code.push(e.target.dataset.item);
      this.setData({
        plateCode: code,
      })
    } else {
      if (this.data.plateCode.length == 6) {
        let code = this.data.plateCode;
        code.push(e.target.dataset.item);
        if (this.data.platePrefix.length < 1) {
          this.setData({
            plateCode: code,
            showModel: true,
            showlabgb: false,
            showCityt: true,
            showCodecity: false
          })
        } else {
          this.setData({
            plateCode: code,
            showModel: false,
            showlabgb: false,
            showCityt: false,
            showCodecity: true,
            last: false
          })
        }

      } else {
        this.setData({
          showModel: false,
          showlabgb: false,
          showCityt: false,
          showCodecity: true
        })
      }

    }
    let plateNumber = "";
    for (let i = 0; i < this.data.plateCode.length; i++) {
      plateNumber += this.data.plateCode[i];
    }
    this.setData({
      plateNumber: plateNumber,
    })

  },
  removeCode() {
    let arr = this.data.plateCode;
    if (arr.length > 0) {
      arr.pop();
      this.setData({
        plateCode: arr
      })
    } else {
      this.setData({
        platePrefix: "",
        showModel: true,
        showlabgb: true,
        showCityt: true,
        showCodecity: false
      })
    }
    let plateNumber = "";
    for (let i = 0; i < this.data.plateCode.length; i++) {
      plateNumber += this.data.plateCode[i];
    }
    this.setData({
      plateNumber: plateNumber,
      last: false
    })
  },
  chooseImage() {
    wx.navigateTo({
      url: '../../chooseImage/chooseImage'
    })
  },
  hrefnavite(e) {
    wx.navigateTo({
      url: '../../chooseImage/chooseImage'
    })
  },
  naviteJump() {
    this.selectComponent("#href").Jump();
  },
  accredit(e) {
    let that = this;
    if (!this.data.clickTimeout) {
      return false;
    }
    this.setData({
      clickTimeout: false
    })
    let setTim = setTimeout(() => {
      this.setData({
        clickTimeout: true
      })
      clearTimeout(setTim);
      setTim = null;
    }, 500)
    if (app.globalData.token) {
      this[e.target.dataset.tap]();
      return;
    } else {
      this.setData({
        redrectUrl: e.target.dataset.tap
      })
      wx.showLoading({
        title: '加载中...',
      })
      app.accredit(e, (res) => {
        wx.removeStorageSync("click");
        if (that.data.uuid) {
          res.data.uuid = that.data.uuid;
        }
        app.confirm(res.data, () => {
          wx.hideLoading();
          // this.selectComponent("#componentId").modalCancel();
          that.setData({
            phoneAuth: false
          });
          that[that.data.redrectUrl]();
        })
      });
      // this.selectComponent("#componentId").toBuy(e);
    }
  }

})