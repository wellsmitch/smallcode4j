//index.js
//获取应用实例
import {
  Api,
  Network,
  validate
} from '../../../utils/index'
const app = getApp()
Page({
  data: {
    cartypearr: [],
    cartypearrdata: [],
    registertime:['11111','222222', '333333'],
    yearj:['aaaa','bbbb','ccccc'],
    region: [],
    receiverRegion: '',//注册时间
    pretime:'',//上次年检时间
    // customItem: '全部',
    carsbcode:'',//车辆识别代码
    engincode:'',//发动机号
    index:'',
    platePrefix:'豫',//省会简称
    plateNumber: '',//车牌号
    cartype:'',//车辆类型
    cartype_data:'',
    multiArray: [],
    cityCodeArr:[],
    cityArr:[],
    showModel:false,
    showlabgb:false,
    showCityt:true,
    showCodecity:false,
    plateCode: [],
    platecode_:'',
    cardata:'豫',
    url: '',
    base64: '',
  },
  onLoad: function() {
   
    this.dataCityInit();
    this.getcartype(this.data.cartypearr)
   
  },

  dataCityInit() {
    let _t = []
    _t[0] = ["豫", "冀", "皖", "琼", "京", "沪", "黑", "陕", "甘", "津", "贵", "川", "藏", "宁", "粤", "赣", "桂", "鲁", "辽", "湘", "新", "渝", "苏", "云", "青", "晋", "鄂", "蒙", "吉", "闽", "浙", "使"]
    _t[1] = [[1, 2, 3, 4, 5, 6, 7, 8, 9, 0, "A", "B", "C", "D", "E", "F", "G", "H", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "U", "V"], ["W", "X", "Y", "Z", "学", "领", "警", "挂"]]
    this.setData({
      multiArray: _t,
      cityArr: [_t[0].slice(0, 10), _t[0].slice(10, 19), _t[0].slice(19, 27), _t[0].slice(27)],
      cityCodeArr: _t[1],
    })
  },
  // 车辆类型
  cartype(e) {
    this.setData({
      index: e.detail.value,
      cartype: this.data.cartypearr[e.detail.value],
      cartype_data: this.data.cartypearrdata[e.detail.value]
    })
    console.log(this.data.cartype)
  },
  // 获取车辆类型
  getcartype() {
    var that = this;
    Network.post(Api.searchcartype, {params:{}}, (res) => {
      console.log(12431234, res)
      let cartypearr_ = [];
      res.data.forEach(function(e,i) {
        cartypearr_.push(e.name)
        that.data.cartypearrdata.push(e.type)
      })
      that.setData({
        cartypearr: cartypearr_
      })
      console.log(that.data.cartypearr)
    })
  },
  // 注册时间
  bindRegionChange: function (e) {
    this.setData({
      receiverRegion: e.detail.value
    })
  },
  // 上次年检时间
  pretime(e) {
    this.setData({
      pretime: e.detail.value
    })
  },
  carscan: function (e) {
    this.setData({
      carsbcode: e.detail.value
    });
  },
  engincode: function (e) {
    this.setData({
      engincode: e.detail.value
    });
    console.log(e)
    // return true;
  },

  showCity: function (e) {
    console.log(342324)
    this.setData({
      showModel: true,
      showlabgb: true,
      showCityt: true,
      showCodecity: false
    })


  },
  showCityc() {
   console.log('r5wrew')
    let last = false;
    console.log(this.data.showModel, this.data.plateCode.length)
    if (!this.data.showModel && this.data.plateCode.length == 7) {
      last = true;
    } else {
      last = false;
    }
    this.setData({
      showModel: true,
      showlabgb: false,
      showCityt: false,
      showCodecity: true,
      last: last
    })
  },
  plateCity(e) {
    console.log(789789)
 
    if (this.data.plateCode.length < 6) {
      this.setData({
        platePrefix: e.target.dataset.item,
        showlabgb: false,
        showCityt: false,
        showCodecity: true
      })
    } else {
      this.setData({
        platePrefix: e.target.dataset.item,
        showModel: false,
        showlabgb: false,
        showCityt: false,
        showCodecity: true
      })
    }
  },

  platecodeCity(e) {
    if (e.target.dataset.item < 10 && this.data.plateCode.length == 0) {
      return;
    }
    console.log(e.target.dataset.item > "Z")
    if (e.target.dataset.item > "Z" && this.data.plateCode.length < 5) {
      return;
    }
    if (this.data.plateCode.length < 6) {
      let code = this.data.plateCode;
      code.push(e.target.dataset.item);
      this.setData({
        plateCode: code,
      })
    } else {
      if (this.data.plateCode.length == 6) {
        let code = this.data.plateCode;
        code.push(e.target.dataset.item);
        if (this.data.platePrefix.length < 1) {
          this.setData({
            plateCode: code,
            showModel: true,
            showlabgb: false,
            showCityt: true,
            showCodecity: false
          })
        } else {
          this.setData({
            plateCode: code,
            showModel: false,
            showlabgb: false,
            showCityt: false,
            showCodecity: true,
            last: false
          })
        }

      } else {
        this.setData({
          showModel: false,
          showlabgb: false,
          showCityt: false,
          showCodecity: true
        })
      }

    }
    let plateNumber = "";
    for (let i = 0; i < this.data.plateCode.length; i++) {
      plateNumber += this.data.plateCode[i];
    }
    this.setData({
      plateNumber: plateNumber,
    })
    console.log(this.data.plateNumber)

  },
  removeCode() {
    let arr = this.data.plateCode;
    if (arr.length > 0) {
      arr.pop();
      this.setData({
        plateCode: arr
      })
    } else {
      this.setData({
        platePrefix: "",
        showModel: true,
        showlabgb: true,
        showCityt: true,
        showCodecity: false
      })
    }
    let plateNumber = "";
    for (let i = 0; i < this.data.plateCode.length; i++) {
      plateNumber += this.data.plateCode[i];
    }
    this.setData({
      plateNumber: plateNumber,
      last: false
    })
    console.log(this.data.plateNumber)
  },
  // 关闭键盘
  closeMode() {
    this.setData({
      showModel: false,
      last: false
    })
  },
// 拍摄车辆拍照 start///////////
  chooseImage() {
    var _this = this;
    //调用上传
    _this.wx_chooseImage(1, "[compressed']", " ['album', 'camera']", function (images) {
      var url = images.tempFilePaths[0];

      //图片转换 base64
      _this.wx_getFileSystemManager_readFile(url, "base64", function (data) {
        var base64 = "data:image/jpeg;base64," + data.data;
        _this.setData({ url: url, base64 })
        // console.log(base64)
        Network.post(Api.lpraddcarmsg, {
          params: {
            carImg: base64
          }
        }, (res) => {
          console.log(res)
        })
      })
    });

    // wx.navigateTo({
    //   url: '../../chooseImage/chooseImage?pathpic=lpraddcarmsg'
    // })
  },
  wx_chooseImage: function (count, sizeType, sourceType, callback) {
    var _this = this;
    wx.chooseImage({
      count: count,
      sizeType: sizeType,
      sourceType: sourceType,
      success: function (res) {
        callback(res);
      }
    });
  },
  wx_getFileSystemManager_readFile: function (filePath, encoding, callback) {
    var _this = this;
    wx.getFileSystemManager().readFile({
      filePath: filePath,
      encoding: encoding,
      success: function (res) {
        callback(res);
      }
    });
  },



// 拍摄车辆拍照 end///////////


  // 提交添加车辆信息
  addCarMsg() {
    var that = this;
    console.log(this.data.platePrefix, this.data.index, this.data.carsbcode)
    if (this.data.platePrefix == '' || this.data.plateNumber == '') {
      wx.showToast({
        title: '车辆号码有误',
        icon: 'none'
      });
      return;
    } else if (this.data.index == '') {
      wx.showToast({
        title: '请选择车辆类型',
        icon: 'none'
      });
      return;
    } else if (this.data.carsbcode == '') {
      wx.showToast({
        title: '车辆识别代号不能为空',
        icon: 'none'
      });
      return;
    } else if (this.data.engincode == '') {
      wx.showToast({
        title: '发动机号不能为空',
        icon: 'none'
      });
      return;
    } 
    // else if (this.data.receiverRegion == '') {
    //   wx.showToast({
    //     title: '注册时间不能为空',
    //     icon: 'none'
    //   });
    //   return;
    // } else if (this.data.pretime == '') {
    //   wx.showToast({
    //     title: '上次年检时间不能为空',
    //     icon: 'none'
    //   });
    //   return;
    // }
    else {
      console.log('提交的添加车辆的信息：', this.data.platePrefix + this.data.plateNumber,
        this.data.cartype_data, this.data.engincode, this.data.carsbcode, this.data.receiverRegion, this.data.pretime,

      )
      Network.post(Api.addcarmsg, { 
        params: {
          source: 1,
          type: 0, //1修改0：添加
          carcode: that.data.carsbcode, //车辆识别代码后四位
          enginetype: that.data.engincode,//发动机型号后四位
          cartype: that.data.cartype,//车辆类型
          // id: //编辑需要
          carnum: that.data.platePrefix + that.data.plateNumber,//车牌
          registdate: that.data.receiverRegion,//注册时间：
          checkdate: that.data.pretime//上次年检时间
        }
      }, (res) => {
          console.log(12431234,res)
          if(res.code == 200) {
            console.log(app.globalData.province, app.globalData.company)
            Network.post(Api.vipopen, {
              params: {
                type: '01',
                // province: app.globalData.province,
                // company: app.globalData.company
                  province: '河南',
                company: '移动'
              }
            }, (res) => {
              console.log(res)
              if (res.code == 200) {
                wx.redirectTo({
                  url: '/pages/userCenter/userCenter'
                })
              }
            })
          }else {
            wx.showToast({
              title: '请填写正确的车辆信息',
              icon:"none"
            })
          }
      })
    }
   
  }
 
})