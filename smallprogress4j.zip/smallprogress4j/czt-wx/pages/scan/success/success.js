//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    mobile: getApp().globalData.mobile,
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    type: 'bind',
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  onLoad: function (options) {
    this.setData({
      type: options.type || 'bind'
    })
  },
  goIndex: function () {
      wx.reLaunch({
      url: '/pages/index/index'
    })
  },
  telCall: function () {
    wx.makePhoneCall({
      phoneNumber: this.data.mobile
    })
  }
})
