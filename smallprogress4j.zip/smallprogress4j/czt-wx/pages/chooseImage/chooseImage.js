
import {
    Api,
    Network,
    validate
} from '../../utils/index'
const app = getApp()
Page({
    data: {
        showBox:true,
        clicktime:true
    },
    onLoad: function (options) {
      console.log(options)
      this.setData({
        addmsgpath: options.pathpic//lpraddcarmsg
      })
        setTimeout(()=>{
            this.ctx = wx.createCameraContext();
        },200)
      
        
    },
    onReady: function () {

    },
    onShow: function () {
        let that=this;
        if (this.data.showBox){
            return;
        }
        wx.getSetting({
            success(res) {
                console.log(res.authSetting["scope.camera"])
                if (res.authSetting["scope.camera"]) {
                    that.setData({
                        showBox: true
                    })
                } else {
                    that.setData({
                        showBox: false
                    })
                }   
                           
            }
        })
    },
    onHide: function () {

    },
    takePhoto(){
      var that = this;
        if (!this.data.clicktime) {
            return;
        }
        this.setData({
            clicktime:false
        })
        var that = this;
        this.ctx.takePhoto({
            quality: 'high',
            success: (res) => {
                that.setData({
                    src: res.tempImagePath
                })
                wx.showLoading({
                    title: '识别中',
                })
              console.log(that.data.addmsgpath,666666)
              let urlOther = ''
              // if (that.data.addmsgpath == 'lpraddcarmsg') {
              //   urlOther = 'lpraddcarmsg'
              // }else {
                urlOther = Api.lpr
              // }
                const uploadTask = wx.uploadFile({
                    url: urlOther , // 仅为示例，非真实的接口地址
                    filePath: res.tempImagePath,
                    name: 'imgBase',
                    header: {
                        'content-type': 'multipart/form-data'
                    },
                    formData: {
                       
                    },
                    success(res) {
                        if (res.statusCode==200){
                            let cardata = JSON.parse(res.data);
                            console.log(JSON.parse(res.data))
                            if (cardata.code == 200) {
                                that.setimg(cardata.data[0].carNum)
                            }else{                                
                                wx.showToast({
                                    title: cardata.message,
                                    icon: 'none',
                                    duration: 2000
                                })
                                that.setData({
                                    src:""
                                })
                            }
                        }else{
                            wx.showToast({
                                title: "车牌解析失败，请重试！",
                                icon: 'none',
                                duration: 2000
                            })
                            that.setData({
                                src: ""
                            })
                            
                        }
                       
                        // do something
                    },
                    fail: function (res) {
                        console.log(res);
                        typeof fail == "function" && fail(res.data);
                        wx.showToast({
                            title: "网络异常，请重试！",
                            icon: 'none',
                            duration: 2000
                        })
                        that.setData({
                            src: ""
                        })
                    },
                    complete:function(){
                        that.setData({
                            clicktime: true
                        })
                    }
                })
            }
        })
    },
    setimg(data){
      wx.showToast({
        title: data,
        icon: 'none',
        duration: 2000
      })
        var pages = getCurrentPages();
        var currPage = pages[pages.length - 1];   //当前页面
        var prevPage = pages[pages.length - 2];  //上一个页面
      if (prevPage.dataplatePrefix) {
          prevPage.setData({
            cardata: data,
            platePrefix: data.substring(0, 1),
            plateNumber: data.substring(1, 10)
          })
        }else {
          prevPage.setData({
            cardata: data
          })
        }
       

        wx.navigateBack();  
    }, 
    callback(){
        var that=this;
    },
    error(){
        this.setData({
            showBox: false
        })
    }
})