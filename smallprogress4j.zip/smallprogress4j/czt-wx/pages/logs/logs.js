//logs.js
// import Utils from '../../utils/index'
const app = getApp();
Page({
  data: {
    logs: []
  },
  onLoad: () => {
    // console.log(Utils);
    // this.setData({
    //   logs: (wx.getStorageSync('logs') || []).map(log => {
    //     return util.formatTime(new Date(log))
    //   })
    // })
  }
})
