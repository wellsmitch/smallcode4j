//index.js
//获取应用实例
// import Utils from '../../../utils/index'
const app = getApp()
Page({
    data: {
        mobile: getApp().globalData.mobile,
        qrUrl: 'https://apph5.mmcqing.com/xcx/images/czt/buy-qr.png',
        openSet:false
    },
    onLoad: function (options) {
        
        this.setData({ qrUrl: "" })
        console.log(options.imgUrl)
        if (options.imgUrl) {
            console.log(options.imgUrl)
            this.setData({ qrUrl: options.imgUrl })
        }  
        // canvas 画图
        var query = wx.createSelectorQuery();
        //选择id
        var that = this;
        const ctx = wx.createCanvasContext('share');
        let width,height;
        // wx.getImageInfo({
        //     src: that.data.qrUrl,    //请求的网络图片路径            
        //     success: function (res) {
        //         console.log(res)
        //         //请求成功后将会生成一个本地路径即res.path,然后将该路径缓存到storageKeyUrl关键字中
        //         that.setData({
        //             qrUrl: res.path
        //         })
        //         imgcanvas()
        //     },
        //     fail() {
        //         wx.showToast({
        //             title: '二维码加载失败',
        //             icon: "none"
        //         })
        //         imgcanvas()
        //     }

        // })
        function imgcanvas(){
            query.select('.bg').boundingClientRect(function (rect) {
                width = rect.width;
                height = rect.height;
                ctx.drawImage("https://apph5.mmcqing.com/xcx/images/czt/buy-qr.png", 0, 0, rect.width, rect.height)
            }).exec();
           let w=0,h=0;
            query.select('.picBox').boundingClientRect(function (rect) {
                console.log(that.data.qrUrl)
                w = rect.width;
                h = rect.height;
                // ctx.drawImage(that.data.qrUrl, width / 2 - rect.width / 2, height / 2 - rect.height / 2, rect.width, rect.height)
                // ctx.draw()
                // ctx.restore();
            }).exec();
            query.select('.pic').boundingClientRect(function (rects) {
                console.log(that.data.qrUrl)
                ctx.drawImage(that.data.qrUrl, width / 2 -w / 2, height / 2 - h / 2, rects.width, rects.height)
                ctx.draw()
            }).exec();
        }
        
    },
    storePic: function () {
        let that=this;
        wx.getSetting({
            success: (response) => {            
                if (!response.authSetting['scope.writePhotosAlbum']) {
                    wx.authorize({
                        scope: 'scope.writePhotosAlbum',
                        success: (res) => {
                            console.log(res)
                            that.imgDownload()
                        },
                        fail(){
                            that.setData({
                                openSet:true
                            }) 
                        }
                    })

                }else{
                    that.setData({
                        openSet: false
                    }) 
                    this.imgDownload()
                }
            }
        })  
    },
    imgDownload() {
        wx.showLoading({
            title: '加载中...',
        })
        wx.canvasToTempFilePath({
            canvasId: 'share',
            success: function (res) {
                console.log(res)
                wx.hideLoading()
                wx.getImageInfo({
                    src: res.tempFilePath,
                    success: function (ret) {
                        //console.log(ret)
                        var path = ret.path;
                       // console.log(path)
                        wx.saveImageToPhotosAlbum({
                            filePath: path,
                            success(result) {
                                //console.log(result)
                                wx.showToast({
                                    title: '保存成功',
                                    icon:"none"
                                })
                            }
                        })
                    }
                })
            }
        })        
    },
    telCall: function () {
        wx.makePhoneCall({
            phoneNumber: this.data.mobile
        })
    }
})
