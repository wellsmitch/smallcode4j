import {util,  Network, Api } from "../../utils/index";

//index.js
//获取应用实例
// var WXBizDataCrypt = require('../../utils/WXBizDataCrypt')

const app = getApp();
Page({
  data: {
    token: '',
    msg_code: '',
    phone: '',
  },
  onLoad: function (options) {
    // let _page = getCurrentPages();
    // let _prevPage = _page[_page.length - 2];
    // _prevPage.setData({})
    this.setData({phone: options.phoneNum});
  },
  register: function () {
  }
})
