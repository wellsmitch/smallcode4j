import {
    Network,
    Api,
    validate
} from "../../../utils/index";

//index.js
//获取应用实例
const app = getApp();
Page({
    data: {
        mobile: getApp().globalData.mobile,
        region: ['河南省', '郑州市', '二七区'],
        // regionText: '河南省-郑州市-二七区',
        customItem: '全部',
        detailNum: 0,
        buyNumber: 1,
        receiver: '',
        receiverPhone: '',
        receiverAdress: '',
        receiverRegion: '河南省-郑州市-二七区',
        remark: '',
        singlePrice: '8.0',     // 单价
        totalPrice: '8.0',      // 总价
        totalGoodsPrice: '0.0',     // 商品总价
        servicePrice: '0.0',    // 信息服务费
        initServicePrice: '0.0',    // 信息服务费
        freight: '0.0',     // 运费
        login_code: '',
        agreeCheck: true, // 协议勾选
        userArr:""

    },
    onLoad: function(option) {
        console.log(option)
        let userArr="";
        if (option.userid){
            userArr = option.userid.split("_");
            console.log(userArr)
            console.log(userArr.length)
        }
        this.moveCarGet();
        this.setData({
            login_code: app.globalData.login_code || '',
            userArr: userArr
        });
    },
    moveCarGet: function() {
        Network.post(Api.DYNAMIC_PRICE, {
            params: {
                buyNumber: 1
            },
            loading: false
        }, data => {
            if (data.code === 200) {
                this.setData({
                    freight: parseFloat(data.data.freight).toFixed(2),
                    singlePrice: parseFloat(data.data.unitPrice).toFixed(2),
                    initServicePrice: parseFloat(data.data.servicePrice).toFixed(2),
                    totalGoodsPrice: parseFloat(data.data.unitPrice).toFixed(2),
                    servicePrice: parseFloat(data.data.servicePrice).toFixed(2),
                    totalPrice: parseFloat(Number(data.data.unitPrice)+Number(data.data.freight)+Number(data.data.servicePrice)).toFixed(2)
                })
            }
        })
    },
    tapAgree: function() {
        let _t = !this.data.agreeCheck;
        this.setData({
            agreeCheck: _t
        })
    },
    buyImm: function() {
        if (!this.data.receiver.trim()) {
            wx.showToast({
                title: '请填写收货人姓名',
                icon: 'none'
            })
            return false;
        }
        let phoneNumber = this.data.receiverPhone.trim();
        if (!validate.phoneNumber(phoneNumber)) {
            wx.showToast({
                title: '请输入11位有效的手机号码',
                icon: 'none'
            })
            return false;
        }
        if (!this.data.receiverAdress.trim()) {
            wx.showToast({
                title: '请填写详细收货地址',
                icon: 'none'
            })
            return false;
        }
        if (!this.data.agreeCheck) {
            wx.showToast({
                title: '请勾选服务协议',
                icon: 'none'
            })
            return false;
        }
        let _param = {
            buyNumber: this.data.buyNumber,//数量
            receiver: this.data.receiver,//姓名
            receiverPhone: this.data.receiverPhone,//手机号
            receiverAdress: this.data.receiverAdress,//地址
            receiverRegion: this.data.receiverRegion,
            totalPrice: this.data.totalPrice,//总价
        }
       
        if (typeof this.data.userArr == "object" && this.data.userArr.length>0){
            _param.inviteUserId = this.data.userArr[0];
            _param.inviteSource = this.data.userArr[1];
        }
        Network.post(Api.C_ORDER, {
            params: {
                params: JSON.stringify(_param)
            }
        }, data => {
            if (data.code === 200) {
                this.cxxPay(data.data.orderNumber);
            } else {
                wx.showToast({
                    title: data.message,
                    icon: 'none'
                });
            }
        })
    },
    cxxPay: function(orderId) {
        // 先检查session是否过期
        let _fn = (orderId, code = this.data.login_code) => {
            Network.post(Api.XCX_PAY, {
                params: {
                    code: code,
                    tradeType: 'czt-xcx',
                    orderNumber: orderId
                }
            }, (res) => {
                if (res.code === 200) {
                    console.log(res.data);
                    this.wxPluginPay(res.data);
                }
            })
        }

        wx.login({
            success: (res) => {
                app.globalData.login_code = res.code;
                this.setData({
                    login_code: res.code
                });
                _fn(orderId, res.code);
            }
        })
        // wx.checkSession({
        //     success: () => { // 没有过期
        //         _fn(orderId, this.data.login_code)
        //     },
        //     fail: () => {
        //         wx.login({
        //             success: (res) => {
        //                 app.globalData.login_code = res.code;
        //                 this.setData({
        //                     login_code: res.code
        //                 });
        //                 _fn(orderId, res.code);
        //             }
        //         })
        //     }
        // })
    },
    wxPluginPay: function(data) {
        let _param = {
            timeStamp: data.timeStamp,
            nonceStr: data.nonceStr,
            package: `${data.package}`,
            signType: 'MD5',
            paySign: data.paySign,
            success: () => {
                wx.redirectTo({
                    url: '/pages/buyProgress/buySuc/buySuc'
                })
            },
            fail: (res) => {
                console.warn(res);
            }
        }
        console.log(_param);
        wx.requestPayment(_param);
    },
    bindRegionChange: function(e) {
        // console.log(e.detail.value);
        this.setData({
            receiverRegion: e.detail.value.join('-')
        })
    },
    nameBlur: function(e) {
        // console.log(e);
        // if (!e.detail.value.trim()) {
        //   wx.showToast({title: '请填写收货人姓名', icon: 'none'})
        //   return false;
        // }
        this.setData({
            receiver: e.detail.value
        });
        // return true;
    },
    detailInput: function(e) {
        this.setData({
            receiverAdress: e.detail.value
        });
        this.setData({
            detailNum: e.detail.value.trim().length
        })
    },
    detailBlur: function(e) {
        // if (!e.detail.value.trim()) {
        //   wx.showToast({title: '请填写详细收货地址', icon: 'none'});
        //   return false;
        // }
        // console.log();
        this.setData({
            receiverAdress: e.detail.value
        });
        // return true;
    },
    phoneBlur: function(e) {
        // if (!e.detail.value.trim() || e.detail.value.trim().length < 11) {
        //   wx.showToast({title: '请输入11位有效的手机号码', icon: 'none'});
        //   return false;
        // }
        this.setData({
            receiverPhone: e.detail.value
        });
        // return true;
    },
    accAdd: function (arg1,arg2){ 
        var r1,r2,m; 
        try{r1=arg1.toString().split(".")[1].length}catch(e){r1=0} 
        try{r2=arg2.toString().split(".")[1].length}catch(e){r2=0} 
        m=Math.pow(10,Math.max(r1,r2)) 
        return (arg1*m+arg2*m)/m 
    },
    numDesc: function() {
        if (this.data.buyNumber >= 2) {
            let _d = this.data.buyNumber - 1,
                toFixedTotalGoodsPrice = parseFloat(this.data.singlePrice * _d).toFixed(2),
                toFixedServicePrice = parseFloat(this.data.initServicePrice * _d).toFixed(2),
                toFixedTotalPrice = parseFloat(this.accAdd(this.accAdd(this.data.singlePrice * _d,this.data.freight),toFixedServicePrice)).toFixed(2);
            this.setData({
                buyNumber: _d,
                totalGoodsPrice: toFixedTotalGoodsPrice,
                servicePrice: toFixedServicePrice,
                totalPrice: toFixedTotalPrice
            })
        }
    },
    numAdd: function() {
        let _d = this.data.buyNumber + 1,
            toFixedTotalGoodsPrice = parseFloat(this.data.singlePrice * _d).toFixed(2),
            toFixedServicePrice = parseFloat(this.data.initServicePrice * _d).toFixed(2),
            toFixedTotalPrice = parseFloat(this.accAdd(this.accAdd(this.data.singlePrice * _d,this.data.freight),toFixedServicePrice)).toFixed(2);
        this.setData({
            buyNumber: _d,
            totalGoodsPrice: toFixedTotalGoodsPrice,
            servicePrice: toFixedServicePrice,
            totalPrice: toFixedTotalPrice
        })
    },
    goServAgree: function() {
        wx.navigateTo({
            url: '/pages/doc/servAgree/servAgree'
        })
    },
    telCall: function() {
        wx.makePhoneCall({
            phoneNumber: this.data.mobile
        })
    }
})