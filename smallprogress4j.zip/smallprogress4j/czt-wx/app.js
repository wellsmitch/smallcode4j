//app.js

import { util, Network, Api } from "./utils/index";
var md5 = require('./utils/md5.js');
App({
    onLaunch: function () {
        // 登录
        let that = this;
        // wx.showLoading({
        //     title: '加载中...',
        //     mask: true
        // })
        
        wx.removeStorageSync('LOGIN_CODE');
        wx.removeStorageSync('TOKEN');
        wx.login({
            success: res => {
                this.globalData['login_code'] = res.code;
                wx.setStorageSync('LOGIN_CODE', res.code);
                Network.post(Api.AUTH_LOGIN, {
                    params: {
                        type: 'czt-xcx',
                        code: res.code
                    },
                    tokenNone: true,
                    loading: false
                }, (res) => {
                    console.log('-------------------')
                    console.log(res)
                    if (res.code === 200) {
                        if (!res.data.token) {
                            this.globalData['notoken'] = true;
                        }
                        try {
                            if (!res.data.isBind) throw "none"
                            wx.setStorageSync('TOKEN', res.data.token);
                            this.globalData['token'] = res.data.token;
                            this.globalData['notoken'] = "yes";
                            this.globalData['userPhone'] = res.data.phone || '';
                        } catch (e) {
                            wx.setStorageSync('isbind',e);
                            this.globalData['sessionId'] = res.data.sessionKey;
                            this.globalData['openId'] = res.data.openid;
                            // wx.login({
                            //     success: (res) => {
                            //         that.globalData.login_code = res.code;
                            //     }
                            // })
                        }
                        this.medata();
                       
                    }else{
                        // wx.showToast({ title: res.message, icon: 'none' })
                        
                    }                   
                })
            }
        })
        wx.getSystemInfo({
            success: function (res) {
                var version = res.SDKVersion;
              console.log(res)
              console.log('resresresresresresres')
                version = version.replace(/\./g, "")
                if (parseInt(version) >190) {// 小于1.2.0的版本
                    that.checkForUpdateApp();
                }
            }
        })        
    },
    login(){

    },
    globalData: {
        imgUrlHost: 'https://apph5.mmcqing.com/xcx/images/czt/',
        sessionId: '',
        userPhone: '',
        usercode:"",
        userInfo: null,
        userid: 123,
        openId: '',
        https: Api.HTTPS,
        token: "",
        notoken:false,
        medetails: "",
        mobile:"12580"
    },
    requestGet(url, data, callback) {
        let that = this;
        wx.request({//获取违法类型
            url: url, //仅为示例，并非真实的接口地址            
            method: "GET",
            data: data,
            header: {
                token: wx.getStorageSync('TOKEN'),
                "content-Type": "application/x-www-form-urlencoded"
            },
            success: function (res) {
                if (res.data.code == 200) {
                    callback(res.data)
                } else if (res.data.code == 401) {
                    that.logout()
                } else {
                    wx.showToast({
                        title: res.data.message,
                        icon: 'none',
                        duration: 2000
                    })
                }
            },
            fail() {
                wx.showToast({
                    title: "服务器繁忙！请稍后重试",
                    icon: 'none',
                    duration: 2000
                })
            }
        })
    },
    requestPost(url, data, callback) {
        let that = this;
        wx.request({
            url: url,            
            method: "POST",
            data: data,
            header: {
                token: wx.getStorageSync('TOKEN'),
                "content-Type": "application/x-www-form-urlencoded"
            },
            success: function (res) {
                if (res.data.code == 200) {
                    callback(res.data)
                } else if (res.data.code == 401) {
                    logout()
                } else {
                    wx.showToast({
                        title: res.data.message,
                        icon: 'none',
                        duration: 2000
                    })
                }
            },
            fail() {
                wx.showToast({
                    title: "服务器繁忙！请稍后重试",
                    icon: 'none',
                    duration: 2000
                })
            }
        })
    },
    request(url, method, data, callback) {
        wx.request({
            url: url,
            method: method,
            data: data,
            header: {
                token: wx.getStorageSync('TOKEN'),
                "content-Type": "application/x-www-form-urlencoded"
            },
            success: function (res) {
                if (res.data.code == 200) {
                    callback(res.data)
                } else if (res.data.code == 401) {
                    logout()
                } else {
                    wx.showToast({
                        title: res.data.message,
                        icon: 'none',
                        duration: 2000
                    })
                }
            },
            fail() {
                wx.showToast({
                    title: "服务器繁忙！请稍后重试",
                    icon: 'none',
                    duration: 2000
                })
            }
        })
    },
    logout() {
        // wx.reLaunch({
        //     url: "../homePage/homePage",
        // })
    },
    medata() {
        let that = this;
        this.requestGet(this.globalData.https + "/api/v1/me/detail", {}, function (res) {
            that.globalData.medetails = res.data;
        })
    },
    showTo() {
        wx.showToast({
            title: '功能即将开放，敬请期待',
            icon: 'none'
        })
    },
    navtab(e) {
        if (e.currentTarget.dataset.nav == 0) {
            return false;
        } else if (e.currentTarget.dataset.nav == 1) {
            this.showTo(e)
        } else {
            if (e.currentTarget.dataset.nav == "../index/index") {
                wx.navigateTo({
                    url: e.currentTarget.dataset.nav,   //注意switchTab只能跳转到带有tab的页面，不能跳转到不带tab的页面
                })
            } else {
                wx.redirectTo({
                    url: e.currentTarget.dataset.nav,   //注意switchTab只能跳转到带有tab的页面，不能跳转到不带tab的页面
                })
            }

        }
    },
    accredit(e,callback){//获取手机号 bind1-1
        let that =this;
        if (e.detail.errMsg === 'getPhoneNumber:ok') {//授权
            wx.checkSession({
                success: () => {
                    // that.authBind(e.detail.encryptedData, e.detail.iv, (res) => {
                    //      callback(res)
                    // });
                    wx.login({
                        success: (res) => {
                            that.globalData.login_code = res.code;
                            that.authBind({
                                encryptedData: e.detail.encryptedData,
                                iv: e.detail.iv
                                // recommenduserid: e.detail.recommenduserid
                            }, (res) => {
                                 callback(res)
                            });
                        }
                    })
                },
                fail: () => {
                    wx.login({
                        success: (res) => {
                            console.log(res)
                            that.globalData.login_code = res.code;
                            that.authBind({
                                encryptedData: e.detail.encryptedData,
                                iv: e.detail.iv
                                // recommenduserid: e.detail.recommenduserid
                            },(res)=>{
                                 callback(res)
                            });
                        }
                    })
                }
            })
        } else {
            wx.showToast({ title: '授权失败', icon: 'none' })
        }
    },
    authBind(params, callback) {//解析获得的手机号bind1-2
        let that = this;
        let _param = {
            encryptedData: params.encryptedData,
            iv: params.iv,
            type: 'czt-xcx',
            code: that.globalData.login_code
        }
        if(that.globalData.sessionId !=''){
            _param.sessionKey = that.globalData.sessionId;
        }
        Network.post(Api.AUTH_LOGIN, {
            params: _param,
            loading: false,
            tokenNone: true
        }, (res) => {        
            if (res.code === 200) {
                callback(res) 
            }
        })
        
    },
    msgGet(phone){//发送验证码 
        let timestamp = new Date().getTime();
        let _param = {
            timestamp: timestamp,
            phone: phone,
            source: '1',
            // type: 'bind',
            random: md5(timestamp + ''),
            signature: md5(`phone=${phone}&random=${md5(timestamp + '')}&timestamp=${timestamp + ''}&secret_key=${'1234567'}`)
        }
       
        Network.post(Api.SMS_GET, {
            params: _param,
            loading: false,
        }, (res) => {
            if(res.code==200){
                wx.showToast({
                    title: res.message,
                    icon:"none"
                })
            }
        })
    },
    getOpenid(call) {//判断是否绑定手机号 bind2-2
        if (wx.getStorageSync('isbind')=="none"){
            // this.getOpenids(info)
            call()
        }else{
            this.getIsBind(()=>{
                call()
            });
        }
    },
    getIsBind(call) {//延迟判断是否绑定手机号 bind2-3
        const s = 0;
        let count = 0;
        let timer = setInterval(() => {
            if (wx.getStorageSync('isbind') == "none"){
                call();
                clearTimeout(timer);
                timer = null;
            }
            count++;
            if (count >= 200) {
                call();
                clearTimeout(timer);
                timer = null;
            }
        }, 100)
      
    },
    getOpenids(info, call) {//获取openid bind2-4
        this.binphone({data:{}},info,call)
        // wx.login({
        //     success: res => {
        //         let rescode = res;
        //         //绑定
        //         Network.post(Api.openId,{
        //             params:{
        //                 type:'czt-xcx',
        //                 code:res.code
        //             },
        //             tokenNone:true,
        //             loading:false
        //         },(data)=>{
        //             that.binphone(data,info,(res)=>{
                        
        //                 call(res)
        //             })
        //         })
        //     }
        // })
    },
    binphone(res, info, call) {//绑定手机号 bind2-
        let _param = {
            openid: this.globalData.openId,
            type: 'cztxcx',
            password: info.codeNum,//验证码
            // password:"953086",
            phone: info.phone
        }
        Network.post(Api.AUTH_BIND, {
            params: _param,
            loading: false
        }, (res) => {
            call(res)
            if (res.code == 200) {
                
            } else if (res.code == -1) {
                wx.showToast({
                    title: res.message,
                    icon: "none"
                })
            }
        })
    },
    msgGets(phone, callback) {//绑定挪车吗发送短信 bind2-1
        let timestamp = new Date().getTime();
        let _param = {
            timestamp: timestamp,
            phone: phone,
            source: '1',
            // type: 'bind',
            random: md5(timestamp + ''),
            signature: md5(`phone=${phone}&random=${md5(timestamp + '')}&timestamp=${timestamp + ''}&secret_key=${'1234567'}`)
        }
        Network.post(Api.SMS_GET, {
            params: _param,
            loading: false,

        }, (res) => {
            if(res.code==200){
                callback(res);
                
            }
        })
    },
    confirm(e, callback) {//bind1-3
        // return ;
        let that = this;
        // if (comfirmData.msgCode.trim() < 6) {
        //     wx.showToast({ title: '请输入6位短信验证码', icon: 'none' });
        //     return;
        // }
        let _param = {
            openid: e.openid,
            type: 'czt-xcx',
            // password: e.msgCode,
            // password:"953086",
            phone: e.phone
        }
        if(!!e.unionId){
            _param.unionID = e.unionId;
        }
        if (e.uuid){
            _param.scanid = e.uuid;
        }
        if (e.recommenduserid) {
            _param.recommenduserid = e.recommenduserid;
        }
        Network.post(Api.AUTH_BIND, {
            params: _param,
            loading: false
        }, (res) => {
            if (res.code == 200) {
                this.globalData.token = "";
                wx.removeStorageSync('TOKEN');
                this.globalData.token = res.data.token;
                wx.setStorageSync('TOKEN', res.data.token);
                this.globalData.userPhone = res.data.phone || '';
                //调用成功隐藏弹出框
                callback()
            } else if (res.code == -1) {
                wx.showToast({
                    title: res.message,
                    icon: "none"
                })
            }
        })
    },
    checkForUpdateApp() {
        const updateManager = wx.getUpdateManager()
        updateManager.onCheckForUpdate(function (res) {
            // 请求完新版本信息的回调
            console.log(res.hasUpdate)
        })
        updateManager.onUpdateReady(function () {
            wx.showModal({
                title: '更新提示',
                content: '新版本已经准备好，是否重启应用？',
                success(res) {
                    if (res.confirm) {
                        updateManager.applyUpdate()
                    }
                }
            })
        })
        updateManager.onUpdateFailed(function () {
            // 新版本下载失败
        })
    },
})