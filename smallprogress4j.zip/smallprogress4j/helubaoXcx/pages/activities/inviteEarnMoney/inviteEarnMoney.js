import { util, Network, Api } from "../../../utils/index";
var md5 = require('../../../utils/md5.js');
var app = getApp(); 
Page({

    /**
     * 页面的初始数据
     */
    data: {
        num:{},
        modeShow:false,
        userId:''
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
        this.getUserId()
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        this.getnumber();       
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },  
    getUserId: function () {
        Network.get(Api.USER_ID, {
            params: {},
            loading: false
        }, (data) => {
            if (data.data.code === 200) {
                this.setData({
                    userId: data.data.data.userid || ''
                })
            }
        })
    },
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function (obj) {
        let name;
        if (app.globalData.userInfo) {
            name = app.globalData.userInfo.nickName;
        } else {
           name = "";
        }
        if (obj) {
            return {
                title: name +'超值推荐 和路宝智能挪车贴汽车停车牌 保护隐私安全可靠',
                path: `/pages/index/index?u=${this.data.userId}_1`,
                imageUrl: 'https://apph5.mmcqing.com/xcx/images/invitePer.png',
                success(res) { // 转发成功之后的回调
                    if (res.errMsg == 'shareAppMessage:ok') {
                        // wx.showToast({
                        //     title: '分享成功',
                        //     icon: "none"
                        // })
                        // this.setData({
                        //     modeShow: false
                        // })
                    }
                },
                fail(res) { // 转发失败之后的回调
                    if (res.errMsg == 'shareAppMessage:cancel') { // 用户取消转发
                        wx.showToast({
                            title: '转发取消',
                            icon: "none"
                        })
                    } else if (res.errMsg == 'shareAppMessage:fail') {
                        // 转发失败，其中 detail message 为详细失败信息
                        wx.showToast({
                            title: '转发失败',
                            icon: "none"
                        })
                    }
                },
                complete(res) {
                    // 转发结束之后的回调（转发成不成功都会执行）
                }
            }
        }
    },
    getnumber(){
        // buyNum  好友购买数量
        // amount  总奖励佣金
        //successNum 邀请成功次数
        //withdrawAmount 已提现金额
        //availableAmount 用户可提现佣金
        Network.post(Api.inviteInfo,{},res=>{
            if(res.code==200){
                res.data.amount=parseFloat(res.data.amount);
                this.setData({
                    num: res.data
                })
            }else{
                wx.showToast({
                    title: res.message,
                    icon:"none"
                })
            }
        },()=>{
            wx.showToast({
                title: "请求失败，请稍后重试",
                icon: "none"
            })
        })
        
    },
    inviteEarnmoney(e){
        
    },
    goRecord(){
        wx.navigateTo({
            url: '../invitationRecord/invitationRecord'
        })
    },
    navtve(){
        wx.navigateTo({
            url: '../myCommission/myCommission'
        })
    },
    navtionm(){
        wx.navigateTo({
            url: '../invitationToScanCode/invitationToScanCode'
        })
    },
    move(){

    },
    showModel(){
        this.setData({
            modeShow:true
        })
    },
    closeMode(){
        this.setData({
            modeShow: false
        })
    }
})