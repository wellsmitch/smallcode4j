import { util, Network, Api } from "../../../utils/index";
var md5 = require('../../../utils/md5.js');
var app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        num:{
            availableAmount:0,
            amount:0,
            withdrawAmount:0,
            successNum:0,
            buyNum:0
        }
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        this.getNum()
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    // onShareAppMessage: function () {

    // },
    getNum(){
         // buyNum  好友购买数量
        // amount  总奖励佣金
        //successNum 邀请成功次数
        //withdrawAmount 已提现金额
        //availableAmount 用户可提现佣金
        Network.post(Api.inviteInfo, {}, res => {
            if (res.code == 200) {
                let datanum = res.data;
                
                this.setData({
                    num: datanum
                })
            } else {
                wx.showToast({
                    title: res.message,
                    icon: "none"
                })
            }
        }, () => {
            wx.showToast({
                title: "请求失败，请稍后重试",
                icon: "none"
            })
        })
    },
    gointive(){
        wx.navigateBack({
            delta:1
        })
    },
    goapplyCash(){
        wx.navigateTo({
            url: '../applyCash/applyCash?moneyNum=' + this.data.num.availableAmount,
        })
        
    },
    toggleNum(str){
        return parseFloat(str)
    }
})