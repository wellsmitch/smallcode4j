import { util, Network, Api } from "../../../utils/index";
var md5 = require('../../../utils/md5.js');
var app = getApp();
Page({
    data: {
        offset: 0,
        limit: 5,
        list: [],
        ajaxData: true,
        nolist: true,
        num:""
    },
    onLoad: function (options) {

    },
    onReady: function () {
        this.getContent()
    },
    onShow: function () {
     
    },
    onHide: function () {

    },
    onUnload: function () {

    },
    addoffset(){
        if (!this.data.ajaxData || !this.data.nolist) {
            return;
        }
        let offset = this.data.offset;
        this.setData({
            offset: offset + 1
        })
        this.getContent()
    },
    getContent(){
        if (this.data.ajaxData) {
            this.setData({
                ajaxData: false
            })
            Network.post(Api.movecarInviteCount, {
                lading: true, params: {
                    offset: this.data.offset * this.data.limit,
                    limit: this.data.limit,
                }
            }, res => {
                if (res.code == 200) {
                    let list = this.data.list;
                    if (res.data.length < 1) {
                        this.setData({
                            nolist: false
                        })
                        return;
                    }
                    list = list.concat(res.data);
                    this.setData({
                        list: list,
                        num: res.num
                    })
                    
                } else {
                    wx.showToast({
                        title: res.message,
                        icon: "none"
                    })
                }
                this.setData({
                    ajaxData: true
                })
            }, () => {
                wx.showToast({
                    title: "请求失败，请稍后重试",
                    icon: "none"
                })
                this.setData({
                    ajaxData: true
                })
            })
        }
        
    },
    goinvite(){
        wx.navigateBack({
            delta: 1 
        })
        // url = '../inviteEarnMoney/inviteEarnMoney'
    }
})