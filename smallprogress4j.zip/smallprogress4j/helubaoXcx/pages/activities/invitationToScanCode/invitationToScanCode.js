import { util, Network, Api } from "../../../utils/index";
var md5 = require('../../../utils/md5.js');
var app = getApp(); 
Page({
    data: {
        src:"",
        bgurl:'',
        settingState:false
    },
    onLoad: function (options) {
    },
    onReady: function () {
        this.getCode();
        this.getbgurl();
        this.getSetting()
    },
    getSetting(){
        let that = this;
        wx.getSetting({
            success: (response) => {
                if (response.authSetting['scope.writePhotosAlbum']) {
                    that.setData({
                        settingState: true
                    })
                } else {
                    wx.authorize({
                        scope: 'scope.writePhotosAlbum',
                        success: (res) => {
                            that.setData({
                                settingState: true
                            })
                        },
                        fail() {
                            that.setData({
                                settingState: false
                            })
                        }
                    })
                }
            },
        })
    },
    getCode(){
        wx.showLoading({
            title: '加载中...',
        })
        Network.post(Api.faceInvite, {
            params: {},
            loading: false
        }, data => {
            console.log(data)
            if (data.code === 200) {
                this.setData({
                    src:data.data
                })
                this.getcanvas();
                wx.hideLoading();
            }
        })
    },
    getcanvas(){
        // canvas 画图
        var that = this;
        wx.getImageInfo({
            src: this.data.src,    //请求的网络图片路径            
            success: function (res) {
                that.setData({
                    codeurl: res.path
                })
                if(that.data.bgurl) {
                    that.dramCode();
                }
            },
            fail() {
                wx.showToast({
                    title: '二维码加载失败',
                    icon: "none"
                })
            }
        })
    },
    getbgurl(){
        var that = this;
        wx.getImageInfo({
            src: "https://apph5.mmcqing.com/xcx/images/mdmbg.png",    //请求的网络图片路径            
            success: function (res) {
                that.setData({
                    bgurl: res.path
                })
                if(that.data.src) {
                    that.dramCode();
                }
            },
            fail() {
            }
        })
    },
    dramCode(){
        if (!this.data.bgurl || !this.data.codeurl){
            return;
        }
        var query = wx.createSelectorQuery();
        const ctx = wx.createCanvasContext('share');
        ctx.drawImage(this.data.bgurl, 0, 0, 375, 582);
        ctx.drawImage(this.data.codeurl, 75, 190, 226, 226);
        ctx.draw();
    },
    storePic() {
        if (!this.data.settingState) {
           return;
        }
        wx.showLoading({
            title: '加载中...',
        })
        var that=this;
        wx.canvasToTempFilePath({
            canvasId: 'share',
            success: function (res) {
                wx.hideLoading()
                wx.getImageInfo({
                    src: res.tempFilePath,
                    success: function (ret) {
                        var path = ret.path;
                        wx.saveImageToPhotosAlbum({
                            filePath: path,
                            success(result) {
                                wx.showToast({
                                    title: '保存成功',
                                    icon: "none"
                                })
                            }
                        })
                    }
                })
            }
        })
    },
    opensettingCallback(e){
        if (e.detail.authSetting["scope.writePhotosAlbum"]){
            this.setData({
                settingState:true
            })
        }
    }
})