import { util, Network, Api } from "../../../utils/index";
var md5 = require('../../../utils/md5.js');
var app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        offset:0,
        limit:10,
        list:[],
        ajaxData:true,
        nolist:true
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
        this.getlist();
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
        var that = this;
        // 显示加载图标
       
        if (!this.data.ajaxData ||!this.data.nolist){
            return ;
        }
        let offset = this.data.offset;
        this.setData({
            offset: offset+1
        })
        this.getlist()
        
    },

    /**
     * 用户点击右上角分享
     */
    // onShareAppMessage: function () {

    // }
    getlist(){
        if(this.data.ajaxData){
            this.setData({
                ajaxData:false
            })
            Network.post(Api.withdrawRecord, {params:{
                offset: this.data.offset * this.data.limit,
                limit: this.data.limit,
            },loading:true}, res => {
                if (res.code == 200) {
                    let list = this.data.list;
                    if (res.data.length<1){
                        this.setData({
                            nolist: false
                        })
                        return;
                    }
                    list = res.data.concat(list);
                   
                    this.setData({
                        list: list
                    })
                } else {
                    wx.showToast({
                        title: res.message,
                        icon: "none"
                    })
                }
                this.setData({
                    ajaxData: true
                })
            }, () => {
                wx.showToast({
                    title: "请求失败，请稍后重试",
                    icon: "none"
                })
                this.setData({
                    ajaxData: true
                })
            })
        }
        
    }
})