import { util, Network, Api } from "../../../utils/index";
var md5 = require('../../../utils/md5.js');
var app = getApp();
Page({
    data: {
        moneyNum:'',
        extractMoney:'',
        submitType:true
    },
    onLoad: function (options) {
        this.setData({
            moneyNum: options.moneyNum
        })
    },
    onReady: function () {

    },
    onShow: function () {

    },
    onHide: function () {

    },
    setnum(e){
        if (e.detail.value>0){
            if (parseFloat(e.detail.value) <= parseFloat(this.data.moneyNum)) {
                this.setData({
                    extractMoney: parseInt(e.detail.value)
                })
            } else {
                this.setData({
                    extractMoney: this.data.moneyNum
                })
            }
        }
    },
    applyNum(){
        if (this.data.moneyNum<=0 ){
            wx.showToast({
                title: '暂无可提现金额',
                icon:"none"
            })
            return;
        }
        if (this.data.submitType){            
            if (!this.data.extractMoney || !this.data.extractMoney>0){
                wx.showToast({
                    title: "请填写正确金额",
                    icon: "none"
                })
                return ;
            }
            this.setData({
                submitType: false
            })
            Network.post(Api.withdraw, {
                loading:true,
                params:{
                    availableAmount: this.data.extractMoney
                }
            }, res => {
                if (res.code == 200) {
                    wx.navigateTo({
                        url: '../success/success',
                    })

                } else {
                    wx.showToast({
                        title: res.message,
                        icon: "none"
                    })
                    this.setData({
                        submitType: true
                    })
                }
            }, () => {
                wx.showToast({
                    title: "请求失败，请稍后重试",
                    icon: "none"
                })
                this.setData({
                    submitType: true
                })
            })
        }else{
            wx.showToast({
                title: "请勿重复提交",
                icon: "none"
            })
        }
    }
})