//index.js
//获取应用实例
const app = getApp()

Page({
    data: {
        mobile: getApp().globalData.mobile,
        motto: 'Hello World',
        userInfo: {},
        hasUserInfo: false,
        type: 'bind',
        canIUse: wx.canIUse('button.open-type.getUserInfo')
    },
    onLoad: function(options) {

    },
    goIndex() {
        wx.navigateBack({
            delta: 3
        })
    },
    telCall: function() {
        wx.makePhoneCall({
            phoneNumber: this.data.mobile
        })
    }
})