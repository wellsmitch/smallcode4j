// pages/handwriting/handwriting.js
import { Api } from '../../utils/index';
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
    data: {
        https: getApp().globalData.https,
        mirrorId:"",
        focs:false
    },
    mirrvalue(e) {//获取text area值
        this.setData({
            mirrorId: e.detail.value
        })
    },
    binmirr(){
        if (this.data.mirrorId.replace(/\s+/g, "").length>0){
            app.requestPost(Api.CLOUD_MIRROR + this.data.mirrorId,{},function(res){
                wx.navigateBack()
            })
        }
       // app.app.requestGet(this.data.https +"api/v1/cloud-mirror/{mirrorId}")
    },
    focu(){
        this.setData({
            focs: true
        })
    }
})