// pages/myEquipment/myEquipment.js
var app = getApp(); 
Page({

    /**
     * 页面的初始数据
     */
    data: {
        https: getApp().globalData.https,
        bindmirror:"",
        mirrordata:{},
        mirrorId:"",
        showbox:false
        
    },
    onShow: function () {
        let that =this;
        wx.showLoading({
            title: '加载中...',
        })
        app.requestGet(this.data.https + "/api/v1/cloud-mirror", {}, function (res) {
            let bindmirror, mirrorId;
            if (res.data){
                bindmirror =true;
                mirrorId = res.data.mirrorId;
            }else{
                bindmirror = false;
                mirrorId="";
            }
            let showbox=true;
            that.setData({    
                bindmirror: bindmirror,         
                mirrordata: res.data,
                mirrorId: mirrorId,
                showbox: showbox
            })
            wx.hideLoading()
        })
    },

    onShareAppMessage: function () {
    
    },
    scanCodeclick(){
        let that = this;
        wx.scanCode({
            success: (res) => {
                app.requestPost(that.data.https + "/api/v1/cloud-mirror/" + res.result, {}, function (res) {
                    that.onShow();
                    wx.showToast({
                        title: res.message,
                        icon: "none"
                    })
                })
               
            }
        })
    },
    handwritingclick(){
        wx.navigateTo({
            url: '../handwriting/handwriting',
        })
    },
    unbind(e){
        let that=this;

        wx.showModal({
            title: '提示',
            content: '你确定解绑设备吗',
            confirmColor:"#333",
            success: function (res) {
                if (res.confirm) {
                    if (e.currentTarget.dataset.bind) {
                        app.request(that.data.https + "/api/v1/cloud-mirror/" + that.data.mirrorId, "DELETE", {}, function (res) {
                            wx.showToast({
                                title: res.message,
                                icon: "none"
                            })
                            that.onShow()
                        })

                    } else {
                        wx.showToast({
                            title: '暂时无法解绑',
                            icon: "none"
                        })
                    }
                }
            }
        })
    },
    depositclick(){
        app.showTo();
    }
})