
import {
    Api,
    Network,
    validate
} from '../../utils/index'
const app = getApp()
Page({
    data: {
        showBox:true,
        clicktime:true
    },
    onLoad: function (options) {
        setTimeout(()=>{
            this.ctx = wx.createCameraContext();
        },200)
      
        
    },
    onReady: function () {

    },
    onShow: function () {
        let that=this;
        if (this.data.showBox){
            return;
        }
        wx.getSetting({
            success(res) {
                if (res.authSetting["scope.camera"]) {
                    that.setData({
                        showBox: true
                    })
                } else {
                    that.setData({
                        showBox: false
                    })
                }   
                           
            }
        })
    },
    onHide: function () {

    },
    takePhoto(){
        if (!this.data.clicktime) {
            return;
        }
        this.setData({
            clicktime:false
        })
        var that = this;
        this.ctx.takePhoto({
            quality: 'normal',
            success: (res) => {
                that.setData({
                    src: res.tempImagePath
                })
                wx.showLoading({
                    title: '识别中',
                })
                const uploadTask = wx.uploadFile({
                    url: Api.lpr, // 仅为示例，非真实的接口地址
                    filePath: res.tempImagePath,
                    name: 'imgBase',
                    header: {
                        'content-type': 'multipart/form-data'
                    },
                    formData: {
                       
                    },
                    success(res) {
                        if (res.statusCode==200){
                            let cardata = JSON.parse(res.data);
                            if (cardata.code == 200) {
                                that.setimg(cardata.data[0].carNum)
                            }else{                                
                                wx.showToast({
                                    title: cardata.message,
                                    icon: 'none',
                                    duration: 2000
                                })
                                that.setData({
                                    src:""
                                })
                            }
                        }else{
                            wx.showToast({
                                title: "车牌解析失败，请重试！",
                                icon: 'none',
                                duration: 2000
                            })
                            that.setData({
                                src: ""
                            })
                            
                        }
                       
                        // do something
                    },
                    fail: function (res) {
                        typeof fail == "function" && fail(res.data);
                        wx.showToast({
                            title: "网络异常，请重试！",
                            icon: 'none',
                            duration: 2000
                        })
                        that.setData({
                            src: ""
                        })
                    },
                    complete:function(){
                        that.setData({
                            clicktime: true
                        })
                    }
                })
            }
        })
    },
    setimg(data){
        var pages = getCurrentPages();
        var currPage = pages[pages.length - 1];   //当前页面
        var prevPage = pages[pages.length - 2];  //上一个页面
        prevPage.setData({
            cardata: data
        })
        wx.navigateBack();  
    }, 
    callback(){
        var that=this;
    },
    error(){
        this.setData({
            showBox: false
        })
    }
})