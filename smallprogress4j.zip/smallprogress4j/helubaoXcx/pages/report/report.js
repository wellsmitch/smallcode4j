var app=getApp();
Page({
    data: {
        https: getApp().globalData.https,
        imgUrls: [],
        indicatorDots: true,
        autoplay: true,
        circular: true,
        network:true,
        interval: 5000,
        duration: 1000,
        swiperCurrent:0,        
        imgClickUrl:[],
        showbox:false,
        trafficItem:[{
            "icon": "https://apph5.mmcqing.com/xcx/images/report/report.png",
            "title": "我要举报",
            "clickurl":"../index/index"
        },
        {
            "icon": "https://apph5.mmcqing.com/xcx/images/report/pai.png",
            "title": "有奖抓拍",
            "clickurl": "../index/index"
        },
        {
            "icon": "https://apph5.mmcqing.com/xcx/images/report/jiang.png",
            "title": "我的奖励",
            "clickurl": "../index/index"
        }],
        courseItem:[],
        report:null,
        mirror:"",//设备绑定状态
        authstate:"",//实名认证状态
        coverUrl:""
       
       
    },
    //轮播图点击事件
    swipeclick:function(e){
        // wx.navigateTo({
        //     url: this.data.imgUrls[0].linkUrl
        // })        
    },
    //轮播图切换事件
    swiperChange: function (e) {
        this.setData({
            swiperCurrent: e.detail.current
        })
    },
    //交通文明点击事件
    trafficClick:function(e){
        if (e.currentTarget.dataset.index==0){
            wx.navigateTo({
                url: "../imreport/imreport"
            })
        }else{
            app.showTo();
        }
    },
    
    reportdetails(){
        if (this.data.report){
            wx.navigateTo({
                url: "../reportdetails/reportdetails?apiurl=/api/v3/video/draft/" + this.data.report.mirrorId + "/" + this.data.report.videoId + "&state=" + this.data.report.state
            })
        }
       
    },
    //教程点击事件
    courseClick:function(e){
        app.showTo();
        // let url=e.
        // wx.navigateTo({
        //     url: ""
        // })
    },   
    onShow(){
       
        var that = this;
        app.requestGet(this.data.https + "/api/v3/community/h5/resources", { type: 2 }, function (res) {        
            that.setData({
                imgUrls: res.data
            })
        })
        app.requestGet(this.data.https + "/api/v3/firstPage", {}, function (res) {
            // mirror//绑定设备状态
            // authstate//实名认证状态
            if (res.data.videoEntity){
                that.setData({
                    authstate: res.data.authstate,
                    mirror: res.data.mirror,
                    report: res.data.videoEntity,
                    showbox:true
                })
            }else{
                that.setData({
                    authstate: res.data.authstate,
                    mirror: res.data.mirror,
                    showbox: true,
                    report:null
                })
            }
            setTimeout(function () {
                wx.hideLoading()
            }, 300)
            
        })
        app.requestGet(this.data.https + "/api/v3/community/h5/resources", {type:5}, function (res) {
            // mirror//绑定设备状态
            // authstate//实名认证状态
            that.setData({
                courseItem:res.data
            })
        })
       
    },
    onLoad(){
        var that = this;
        wx.onNetworkStatusChange(function (res) {
            if (res.isConnected) {
                that.onShow();
            }
            that.setData({
                network: res.isConnected
            })
        })
    },
    binsear(){
        wx.navigateTo({
            url: '../myEquipment/myEquipment'
        })
    },
    navclick(e) {
        app.navtab(e)

    }
})