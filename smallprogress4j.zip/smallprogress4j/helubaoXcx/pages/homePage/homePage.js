// pages/homePage/homePage.js
import { util, Network, Api } from "../../utils/index";
var md5 = require('../../utils/md5.js');
var app =getApp(); 
Page({
  /**
   * 页面的初始数据
   */
    data: {
        imgUrls: [],
        indicatorDots: true,
        autoplay: true,
        circular: true,
        interval: 5000,
        duration: 1000,
        swiperCurrent: 0,
        https: getApp().globalData.https,
        token: getApp().globalData.token,
        friends:[],
        service:[],
        footactive:0,
        pagetabbar: [],      
        selectedColor:"",
        active:0,
        more:[],
        phoneAuth: true,
        msgCanClick:true,
        phoneNumber: "",
        openid: "",
        showMsgPanel: "",
        msgBtnText: '',
        msgCode:"",
        focus:false,
        clicke:null,
        clickTimeout:false
    },
    calcTokenGet: function () {
        let count = 0;
        let timer = setInterval(() => {
            if (app.globalData.login_code) {
                this.setData({ login_code: app.globalData.login_code });
               
            }            
            if (!app.globalData.token) { //需授权
                this.setData({ phoneAuth: true });
            } else {
                this.setData({ phoneAuth: false, clickTimeout:true });
                this.getHome();
               
                clearInterval(timer);
                wx.hideLoading()
            }
            if (app.globalData.notoken && app.globalData.notoken != "yes") {
                this.setData({ clickTimeout: true });
                wx.hideLoading();
                clearInterval(timer);
                this.getHome();
            }
            if (app.globalData.notoken == "yes") {
                this.setData({ phoneAuth: false, clickTimeout: true });
                this.getHome();
                clearInterval(timer);
                wx.hideLoading()
            }
            count++;
            if (count >= 40) {
                this.setData({ clickTimeout: true });
                wx.hideLoading();
                clearInterval(timer);
                this.getHome();
            }
        }, 150)
    },
    getMap(){
        wx.getLocation({//获取地理位置
            type: 'wgs84',
            success(res) {
                const latitude = res.latitude
                const longitude = res.longitude
                const speed = res.speed
                const accuracy = res.accuracy
            }
        })
    },
    onShow: function () {
        wx.showLoading({
            title: '加载中...',
        })
        var that=this;
        this.calcTokenGet();        
    },
    getHome(){
        var that = this;
        app.requestGet(Api.HOME_RESOURCES, { type: 10 }, function (res) {
            if (res.data.length < 2) {
                that.setData({
                    imgUrls: res.data,
                    circular: false,
                    autoplay: false,
                    indicatorDots: false
                })
            } else {
                that.setData({
                    imgUrls: res.data
                })
            }
        })
        app.requestGet(Api.HOME_RESOURCES, { type: 12 }, function (res) {
            that.setData({
                friends: res.data
            })
        })
        app.requestGet(Api.HOME_RESOURCES, { type: 11 }, function (res) {
            that.setData({
                service: res.data
            })
        })
        app.requestGet(Api.HOME_RESOURCES, { type: 13 }, function (res) {
            that.setData({
                more: res.data
            })
        })
    },
    tabss(){
        this.setData({
            focus: true
        })
    },
    click(e){
        let index=e.currentTarget.dataset.index;
        wx.navigateTo({
            url: this.data.more.linkUrl,
        })
    },
    swipeclick(e){//banner 点击事件
    },
    serviceclick(e){//功能点击事件
        let ourl;
        if (e.currentTarget.dataset.type=="m"){
            ourl = this.data.more
        } else if (e.currentTarget.dataset.type=="0"){
            ourl = this.data.service
        }
        let index = e.currentTarget.dataset.index;       
        let url = ourl[index].linkUrl;       
        if (url){
            wx.navigateTo({
                url: url
            })
        }else{
            if (e.currentTarget.dataset.type == "m"){
                wx.navigateTo({
                    url: "../download/download"
                })
            }else{
                app.showTo();
            }
        }
    },
    moreclick(e){//推荐好友
        app.showTo();
    },
    navclick(e){
        app.navtab(e)
    },
    toBuy: function (e) { // 购买授权判断 
        let that=this;
        if (!this.data.clickTimeout){
            
            return false;
        }
        this.setData({
            clickTimeout:false
        })
        let setTim = setTimeout(()=>{
            this.setData({
                clickTimeout: true
            })
            clearTimeout(setTim);
            setTim=null;
        },500)
        let detail = e.detail;
        if (detail.errMsg && detail.errMsg.indexOf('getPhoneNumber:fail') !== -1) { // 拒绝授权
            return;
        }else if (app.globalData.token) {
          this.homeNavTo(e);
          return;
        } else {
            this.setData({
                clicke:e
            })
            // this.selectComponent("#componentId").toBuy(e);
            wx.showLoading({
                title: '加载中...',
            })
            app.accredit(e,(res)=>{
                wx.removeStorageSync("click");
                app.confirm(res.data, () => {
                    wx.hideLoading();
                    // this.selectComponent("#componentId").modalCancel();
                    that.setData({ phoneAuth: false });
                    if (that.data.clicke) {
                        that.homeNavTo(that.data.clicke);
                    }
                })
            });
        }
        
    },  
    homeNavTo(e){
        if (e.currentTarget.dataset.url) {
            wx.navigateTo({
                url: e.currentTarget.dataset.url
            })
            return;
        }
        if (e.currentTarget.dataset.type == "n") {
            this.navclick(e)
        } else if (e.currentTarget.dataset.type == "m") {
            this.serviceclick(e)
        } else if (e.currentTarget.dataset.type == "0") {
            this.serviceclick(e)
        }
    },  
    modalConfirm: function (e) { // 弹框确认
        wx.removeStorageSync("click");
        wx.hideLoading();
        app.confirm(e,()=>{
            this.selectComponent("#componentId").modalCancel();
            this.setData({ phoneAuth: false });
            if (this.data.clicke) {
                this.homeNavTo(this.data.clicke);
            }
        })
    }
})
