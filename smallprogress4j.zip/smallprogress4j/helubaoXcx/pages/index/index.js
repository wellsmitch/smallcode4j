import {
    Network,
    Api
} from "../../utils/index";
var md5 = require('../../utils/md5.js');
//index.js
//获取应用实例
// var WXBizDataCrypt = require('../../utils/WXBizDataCrypt')

const app = getApp();
Page({
    data: {
        mobile: getApp().globalData.mobile,
        motto: 'Hello World',
        priceImg: 'https://apph5.mmcqing.com/xcx/images/index-top-pic.jpg?time=' + Math.random() * 10,
        userInfo: {},
        hasUserInfo: false,
        canIUse: wx.canIUse('button.open-type.getUserInfo'),
        session_key: '',
        login_code: '',
        phoneAuth: false,
        showMsgPanel: false,
        phoneNumber: '',
        msgBtnText: '发送短信验证码',
        msgCanClick: true,
        timer: null,
        msgCode: '',
        openId: '',
        redrectUrl: '',
        toParam: '',
        userInfos: true,
        recommenduserid: '',
        clickTimeout: false,
        userid:""
    },
    gonavTo() {
        wx.redirectTo({
            url: '/pages/userCenter/userCenter'
        })
    },
    bindShareUser: function() {},
    calcTokenGet: function() {
        let count = 0;
        let timer = setInterval(() => {
            if (app.globalData.login_code) {
                this.setData({
                    login_code: app.globalData.login_code
                });
            }
            if (!app.globalData.token) { //需授权
                this.setData({
                    phoneAuth: true
                });
            } else {
                this.setData({
                    phoneAuth: false
                });
                clearInterval(timer);
            }
            count++;
            if (count >= 200) {
                clearInterval(timer);
            }
        }, 100)
    },
    onShow: function() {
        this.setting(); //检查授权
        this.calcTokenGet();
    },
    onLoad: function(options) {
        if (options.recommenduserid) {
            this.setData({
                recommenduserid: options.recommenduserid
            });
        }
        if (options.q) {
            let opac = decodeURIComponent(options.q || '');
            let usertype = opac.split('?u=')[1];
            this.setData({
                userid: usertype
            });
        }
        if (options.u){
            this.setData({
                userid: options.u
            });  
        }
    },
    modalConfirm: function(e) { // 弹框确认
        let _e = e;
        _e.detail.recommenduserid = this.data.recommenduserid;
        app.confirm(_e, () => {
            // this.selectComponent("#componentId").modalCancel();
            this.setData({
                phoneAuth: false
            });
            wx.navigateTo({
                url: this.data.redrectUrl
            })
        })
    },
    toBuyCenter(e) { //我的授权 
        if (app.globalData.token) {
            wx.navigateTo({
                url: '/pages/userCenter/userCenter'
            })
            return;
        } else {
            this.setData({
                redrectUrl: '/pages/userCenter/userCenter'
            })
            let _e = e;
            if (this.data.recommenduserid) {
                _e.detail.recommenduserid = this.data.recommenduserid;
            }
            this.bindPhone(e);
        }
    },
    toBuy: function(e) { // 购买授权判断
        if (app.globalData.token) {
            if(this.data.userid){
                wx.navigateTo({
                    url: '/pages/buyProgress/buyMain/buyMain?userid=' + this.data.userid
                })
            }else{
                wx.navigateTo({
                    url: '/pages/buyProgress/buyMain/buyMain'
                })
            }
            return;
        } else {
            if (this.data.userid) {
                this.setData({
                    redrectUrl: '/pages/buyProgress/buyMain/buyMain?userid=' + this.data.userid
                })
            } else {
                this.setData({
                    redrectUrl: '/pages/buyProgress/buyMain/buyMain'
                })
            }
            let _e = e;
            if (this.data.recommenduserid) {
                _e.detail.recommenduserid = this.data.recommenduserid;
            }
            this.bindPhone(e);
        }
    },
    bindPhone(e) {
        let that = this;
        wx.showLoading({
            title: '加载中...',
        })
        app.accredit(e, (res) => {
            wx.removeStorageSync("click");
            if (that.data.recommenduserid) {
                res.data.recommenduserid = that.data.recommenduserid;
            }
            app.confirm(res.data, () => {
                wx.hideLoading();
                // this.selectComponent("#componentId").modalCancel();
                that.setData({
                    phoneAuth: false
                });
                if (that.data.userInfos){
                    return;
                }
                wx.navigateTo({
                    url: that.data.redrectUrl
                })
            })
        });
    },
    goOnlineExp: function(e) { // 体验授权
        if (app.globalData.token) { // 有toen则跳回
            wx.navigateTo({
                url: '/pages/onlineExp/onlineExpMain/onlineExpMain'
            })
            return;
        }
        this.setData({
            redrectUrl: '/pages/onlineExp/onlineExpMain/onlineExpMain'
        })
        let _e = e;
        if (this.data.recommenduserid) {
            _e.detail.recommenduserid = this.data.recommenduserid;
        }
        this.bindPhone(e);
    },
    telCall: function() { // 打电话
        wx.makePhoneCall({
            phoneNumber: this.data.mobile
        })
    },
    fullUserINFO: function() { // 补全用户信息
        wx.getSetting({
            success: function(res) {
                if (res.authSetting['scope.userInfo']) {
                    console.log(app.globalData.userInfo)
                    // 已经授权，可以直接调用 getUserInfo 获取头像昵称
                    if (app.globalData.token) {
                        wx.login({
                            success: res => {
                                Network.post(Api.AUTH_LOGIN, {
                                    params: {
                                        type: 'xcx',
                                        code: res.code,
                                        nickname: app.globalData.userInfo.nickName,
                                        headimgurl: app.globalData.userInfo.avatarUrl
                                    },
                                    loading: false
                                }, (res) => {
                                    // console.error(res);
                                })
                            }
                        })
                    }
                }
            }
        })
    },
    toCenter: function(e) { // 跳转到个人中心
        let _e = e.detail;
        if (_e.errMsg === 'getUserInfo:ok') { // 授权成功
            app.globalData.userInfo = JSON.parse(_e.rawData);
            if (app.globalData.login_code) {
                this.fullUserINFO();
            }
            this.setting()
            this.gonavTo()
        }else{
            this.gonavTo()
        }
    },
    setting() { //检查授权
        let that = this;
        wx.getSetting({
            success(res) {
                if (!res.authSetting['scope.userInfo']) {
                    that.setData({
                        userInfos: true
                    })
                } else {
                    that.setData({
                        userInfos: false
                    })
                }
            }
        })
    }
})