//index.js
//获取应用实例
import { Network, Api } from "../../../utils/index";
var md5 = require('../../../utils/md5.js');
const app = getApp()

Page({
    data: {
        mobile: getApp().globalData.mobile,
        plateNumber: '',
        phoneNumber: '',
        phoneNumbers:"",
        // modalShow: false,,
        hiddenmodalput:false,
        phoneAuth: '',
        msgCanClick: true,
        openid: "",
        showMsgPanel: "",
        msgBtnText: '',
        msgCode: "",
        focus: false,
        clicke: null,
        settime:true,
        phonetel: app.globalData.userPhone,
        phonetels: app.globalData.userPhone,
        telerror:"",
        telShow:false,
        telValue:"",
        telerr:false,
        clickTimeout: false
    },
    
    //事件处理函数
    onLoad: function (options) {
        
        let _param = JSON.parse(options.param || '{}');
        if (_param.uuid){
            this.setData({
                uuid: _param.uuid
            })
        }
        let adList;
        if (_param.list){
            adList = _param.list
        }else{
            adList=""
        }
        this.setData({
            plateNumber: _param.carNum,//车牌号
            phoneNumber: _param.phone,//要发送的手机号
            adList: adList
        })
        // this.setData({
        //     plateNumber: '豫A12345',//车牌号
        //     phoneNumber: '18875927085'//要发送的手机号
        // })
        let count = 0;
        let timer = setInterval(() => {
            if (app.globalData.login_code) {
                this.setData({ login_code: app.globalData.login_code });
            }
            if (!app.globalData.token) { //需授权
                this.setData({ phoneAuth: true });
            } else {
                this.setData({ phoneAuth: false, clickTimeout:true });
                clearInterval(timer);
            }
            count++;
            
            if (count >= 40) {
                this.setData({clickTimeout: true });
                clearInterval(timer);

            }
        }, 100)

    },
    getCenterTel: function () {
        let telA = app.globalData.userPhone;
        let telB = this.data.phoneNumber;
        if (telA .substring(0, 2) !="86"){
            telA = "86" + telA;
        }
        if (telB.substring(0, 2) != "86") {
            telB = "86" + telB;
        }
        let param={
            // telA: telA,//呼叫电话
            tel: telB,//被叫电话,
           
        }
        if(this.data.uuid){
            param.scanid = this.data.uuid
        }
        Network.post(Api.TELL_BIND, {
            params: param,
            tokenNone: true
        }, (res) => {
            if(res.code === 200) {
                wx.makePhoneCall({
                    phoneNumber: "+"+res.data.x_no//打电话的手机号
                })
            } else {
                wx.showToast({
                    title: '获取失败，请重试',
                    icon: "none"
                }) 
            }
        })
    },
    callTel: function () {
        // this.setData({
        //     telShow:true,
        //     phonetel: app.globalData.userPhone,
        //     phonetels: app.globalData.userPhone,
        //     telValue: app.globalData.userPhone
        // })
        this.getCenterTel();
        if (app.globalData.userPhone) {
            
        }
    },
    telClose(){
        this.setData({
            telShow: false,
            telerror: "",
            telerr: false,
            telValue: app.globalData.userPhone
        })
    },
    telSure() {
        if (this.data.telValue.trim() == ""){
            if (this.data.phonetels) {
                this.getCenterTel();
            }
            this.telClose();
        } else if (this.data.telValue.trim().length < 11 && this.data.telValue.trim()!=""){
            this.setData({
                telerror: "请填写正确的手机号",
                telerr:true
            })
        } else if (this.data.telValue.trim().length == 11 && this.data.telValue.trim() != ""){
            this.setData({
                phonetel: this.data.telValue.trim()
            })
            this.telClose();
            this.getCenterTel();
        }
        
    },
    telInput(e){
        if (e.detail.value.trim().length==11){
            this.setData({
                telerror: "",
                telerr: false
            })
        }
        this.setData({
            telValue: e.detail.value
        })
    },
    goIndex: function () {
        wx.redirectTo({
        url: '/pages/index/index'
        })
    },
    // modalCancel: function () {
    //   this.setData({modalShow: false})
    // },
    // modalConfirm: function () {
    //   this.setData({modalShow: false})
    // },
    
    telCall: function () {
        wx.makePhoneCall({
        phoneNumber: this.data.mobile//客服电话
        })
    },
    accredit(e){  
        let that=this;
        if (!this.data.clickTimeout) {

            return false;
        }
        this.setData({
            clickTimeout: false
        })
        let setTim = setTimeout(() => {
            this.setData({
                clickTimeout: true
            })
            clearTimeout(setTim);
            setTim = null;
        }, 500)   
        if (app.globalData.token) {
            this[e.target.dataset.tap]();            
            return;
        } else {
            this.setData({
                redrectUrl: e.target.dataset.tap
            })
            wx.showLoading({
                title: '加载中...',
            })
            app.accredit(e, (res) => {
                wx.removeStorageSync("click");
                if (that.data.uuid) {
                    res.data.uuid = that.data.uuid;
                }
                app.confirm(res.data, () => {
                    wx.hideLoading();
                    // this.selectComponent("#componentId").modalCancel();
                    that.setData({ phoneAuth: false });
                    that[that.data.redrectUrl]();
                })
            });
            // this.selectComponent("#componentId").toBuy(e);
        }  
    },
    modalConfirm: function (e) { // 弹框确认
        
        if (this.data.uuid){
            e.detail.data.uuid = this.data.uuid;
        }
        app.confirm(e, () => {
            this.setData({ phoneAuth: false });
            this.selectComponent("#componentId").modalCancel();
            this[this.data.redrectUrl](); 
        })
    },
    sendinfo(e){
        let that=this;
        if (!this.data.settime){
            wx.showToast({
                title: '请耐心等待车主正在赶来中...',
                icon: "none"
            })
            return false;
        }
        if (this.data.plateNumber && this.data.phoneNumber){
            wx.showModal({
                title: '',
                content: '是否给车主发送短信',
                confirmColor: "#333",
                success(res) {
                    if (res.confirm) {
                        that.send();
                    }                    
                }
            })
        }else{
            wx.showToast({
                title: '信息有误请退出重试',
                icon: "none"
            })
        }
    },
    send(){
        let that=this;
        let scanId="1234567890";
        if(this.data.uuid){
            scanId = this.data.uuid;
        }
        let data = {
            users: this.data.phoneNumber,
            carNum: this.data.plateNumber,
            source:1,
            scanId: scanId
        }
        Network.post(Api.MESSAGE_INFO, {
            params: data,
            tokenNone:true
        }, (res) => {
            if (res.code == 200) {
                that.setData({
                    settime: false
                })
                let tim = setTimeout(() => {
                    that.setData({
                        settime: true
                    })
                    clearTimeout(tim)
                    tim = null;

                }, 300000)

                wx.showToast({
                    title: '短信发送成功',
                    icon: "none"
                })
            } else {
                wx.showToast({
                    title: res.message,
                    icon: "none"
                })

            }
        })
        // app.requestPost(Api.MESSAGE_INFO, data, function (res) {
        //     if (res.code == 200) {
        //         that.setData({
        //             settime: false
        //         })
        //         let tim = setTimeout(() => {
        //             that.setData({
        //                 settime: true
        //             })
        //             clearTimeout(tim)
        //             tim = null;

        //         }, 300000)

        //         wx.showToast({
        //             title: '短信发送成功',
        //             icon: "none"
        //         })
        //     } else {
        //         wx.showToast({
        //             title: res.message,
        //             icon: "none"
        //         })

        //     }
        // })
        // app.requestPost(Api.SMS_MESSAGE, data, function (res) {
        //     if(res.code==200){
        //         that.setData({
        //             settime:false
        //         })
        //         let tim=setTimeout(()=>{
        //             that.setData({
        //                 settime: true
        //             })
        //             clearTimeout(tim)
        //             tim=null;

        //         },300000)

        //         wx.showToast({
        //             title: '短信发送成功',
        //             icon:"none"
        //         })
        //     }else{
        //         wx.showToast({
        //             title: res.message,
        //             icon: "none"
        //         })

        //     }
        // })
    },
    navTo(){
        wx.navigateTo({
            url: '/pages/buyProgress/buyMain/buyMain',
        })
    },
    goInite(){
        wx.navigateTo({
            url: '/pages/activities/inviteEarnMoney/inviteEarnMoney',
        })
    },
    adBanner(e){
        if (e.currentTarget.dataset.url){
            wx.navigateTo({
                url: '../../activities/webView/webView?url=' + e.currentTarget.dataset.url,
            })
        }
    }
})
