import {
    Network,
    Api,
    validate
} from "../../../utils/index";

//index.js
//获取应用实例
const app = getApp();
Page({
    data: {
        mobile: getApp().globalData.mobile,
        region: ['河南省', '郑州市', '二七区'],
        // regionText: '河南省-郑州市-二七区',
        customItem: '全部',
        detailNum: 0,
        buyNumber: 1,
        receiver: '',
        receiverPhone: '',
        receiverAdress: '',
        receiverRegion: '河南省-郑州市-二七区',
        remark: '',
        singlePrice: '8.0',
        totalPrice: '8.0',
        login_code: '',
        agreeCheck: true, // 协议勾选
        userArr:""

    },
    onLoad: function(option) {
        let userArr="";
        if (option.userid){
            userArr = option.userid.split("_");
        }
        this.moveCarGet();
        this.setData({
            login_code: app.globalData.login_code || '',
            userArr: userArr
        });
    },
    moveCarGet: function() {
        Network.post(Api.DYNAMIC_PRICE, {
            params: {
                buyNumber: 1
            },
            loading: false
        }, data => {
            if (data.code === 200) {
                this.setData({
                    singlePrice: parseFloat(data.data).toFixed(2),
                    totalPrice: parseFloat(data.data).toFixed(2)
                })
            }
        })
    },
    tapAgree: function() {
        let _t = !this.data.agreeCheck;
        this.setData({
            agreeCheck: _t
        })
    },
    buyImm: function() {
        if (!this.data.receiver.trim()) {
            wx.showToast({
                title: '请填写收货人姓名',
                icon: 'none'
            })
            return false;
        }
        let phoneNumber = this.data.receiverPhone.trim();
        if (!validate.phoneNumber(phoneNumber)) {
            wx.showToast({
                title: '请输入11位有效的手机号码',
                icon: 'none'
            })
            return false;
        }
        if (!this.data.receiverAdress.trim()) {
            wx.showToast({
                title: '请填写详细收货地址',
                icon: 'none'
            })
            return false;
        }
        if (!this.data.agreeCheck) {
            wx.showToast({
                title: '请勾选服务协议',
                icon: 'none'
            })
            return false;
        }
        let _param = {
            buyNumber: this.data.buyNumber,//数量
            receiver: this.data.receiver,//姓名
            receiverPhone: this.data.receiverPhone,//手机号
            receiverAdress: this.data.receiverAdress,//地址
            receiverRegion: this.data.receiverRegion,
            totalPrice: this.data.totalPrice,//总价
        }
        console.log(this.data.userArr)
        if (this.data.userArr.length>0){
            _param.inviteUserId = this.data.userArr[0];
            _param.inviteSource = this.data.userArr[1];
        }
        console.log(_param)
        Network.post(Api.C_ORDER, {
            params: {
                params: JSON.stringify(_param)
            }
        }, data => {
            if (data.code === 200) {
                console.log("生成订单")
                console.log(data)
                this.cxxPay(data.data.orderNumber);
            } else {
                wx.showToast({
                    title: data.message,
                    icon: 'none'
                });
            }
        })
    },
    cxxPay: function(orderId) {
        // 先检查session是否过期
        let _fn = (orderId, code = this.data.login_code) => {
            Network.post(Api.XCX_PAY, {
                params: {
                    code: code,
                    tradeType: 'WXXCX',
                    orderNumber: orderId
                }
            }, (res) => {
                console.log("生成调用")
                console.log(res)
                if (res.code === 200) {
                   
                    this.wxPluginPay(res.data);
                }
            },()=>{
                console.log("请求失败")
            })
        }
        wx.login({
            success: (res) => {
                app.globalData.login_code = res.code;
                this.setData({
                    login_code: res.code
                });
                _fn(orderId, res.code);
            }
        })
    },
    wxPluginPay: function(data) {
        let _param = {
            timeStamp: data.timeStamp,
            nonceStr: data.nonceStr,
            package: `${data.package}`,
            signType: 'MD5',
            paySign: data.paySign,
            success: () => {
                wx.redirectTo({
                    url: '/pages/buyProgress/buySuc/buySuc'
                })
            },
            fail: (res) => {
                // console.warn(res);
            }
        }
        wx.requestPayment(_param);
    },
    bindRegionChange: function(e) {
        this.setData({
            receiverRegion: e.detail.value.join('-')
        })
    },
    nameBlur: function(e) {
        // if (!e.detail.value.trim()) {
        //   wx.showToast({title: '请填写收货人姓名', icon: 'none'})
        //   return false;
        // }
        this.setData({
            receiver: e.detail.value
        });
        // return true;
    },
    detailInput: function(e) {
        this.setData({
            receiverAdress: e.detail.value
        });
        this.setData({
            detailNum: e.detail.value.trim().length
        })
    },
    detailBlur: function(e) {
        // if (!e.detail.value.trim()) {
        //   wx.showToast({title: '请填写详细收货地址', icon: 'none'});
        //   return false;
        // }
        // console.log();
        this.setData({
            receiverAdress: e.detail.value
        });
        // return true;
    },
    phoneBlur: function(e) {
        // if (!e.detail.value.trim() || e.detail.value.trim().length < 11) {
        //   wx.showToast({title: '请输入11位有效的手机号码', icon: 'none'});
        //   return false;
        // }
        this.setData({
            receiverPhone: e.detail.value
        });
        // return true;
    },
    numDesc: function() {
        if (this.data.buyNumber >= 2) {
            let _d = this.data.buyNumber - 1;
            this.setData({
                buyNumber: _d,
                totalPrice: parseFloat(this.data.singlePrice * _d).toFixed(2)
            })
        }
    },
    numAdd: function() {
        let _d = this.data.buyNumber + 1;
        this.setData({
            buyNumber: _d,
            totalPrice: parseFloat(this.data.singlePrice * _d).toFixed(2)
        })
    },
    goServAgree: function() {
        wx.navigateTo({
            url: '/pages/doc/servAgree/servAgree'
        })
    },
    telCall: function() {
        wx.makePhoneCall({
            phoneNumber: this.data.mobile
        })
    }
})