//index.js
//获取应用实例
import {
    Api,
    Network
} from '../../../utils/index'
const app = getApp()

Page({
    data: {
        mobile: getApp().globalData.mobile,
        orderList: [],
        nodata: false,
        statusWitch: {
            '0': '待付款',
            '1': '待发货',
            '2': '交易关闭',
            '3': '交易完成',
            '4': '已发货'
        }
    },
    onLoad: function() {
        this.orderListGet();
    },
    formatTime: function(timestamp, datePrefix = '-', timePrefix = ':') {
        let date = new Date(timestamp);
        const year = date.getFullYear()
        const month = date.getMonth() + 1 >= 10 ? (date.getMonth() + 1) : `0${date.getMonth() + 1}`
        const day = date.getDate() >= 10 ? date.getDate() : `0${date.getDate()}`
        const hour = date.getHours() >= 10 ? date.getHours() : `0${date.getHours()}`
        const minute = date.getMinutes() >= 10 ? date.getMinutes() : `0${date.getMinutes()}`
        const second = date.getSeconds() >= 10 ? date.getSeconds() : `0${date.getSeconds()}`
        return `${year}${datePrefix}${month}${datePrefix}${day}  ${hour}${timePrefix}${minute}${timePrefix}${second}`
        // return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
    },
    orderListGet: function() {
        Network.post(Api.EWM_DETAIL, {
            params: {
                type: 0
            }
        }, res => {
            if (res.code === 200) {
                let nodata = res.data.orderList.length < 1 ? true : false;
                this.setData({
                    orderList: res.data.orderList.map(item => {
                        item.createDate = this.formatTime(item.createDate);
                        item.stateText = this.data.statusWitch[item.state];
                        return item;
                    }),
                    nodata: nodata

                })
            }
        })
    },
    telCall: function() {
        wx.makePhoneCall({
            phoneNumber: this.data.mobile
        })
    }
})