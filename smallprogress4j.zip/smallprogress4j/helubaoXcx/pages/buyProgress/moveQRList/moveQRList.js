//index.js
//获取应用实例
import {
    Api,
    Network
} from '../../../utils/index'
const app = getApp()

Page({
    data: {
        mobile: getApp().globalData.mobile,
        moveList: [],
        nodata:false,
        statusWitch: {
            '0': '体验码',
            '1': '挪车码'
        }
    },
    onLoad: function() {
        this.orderListGet();
    },
    orderListGet: function() {
        Network.post(Api.EWM_DETAIL, {
            params: {
                type: 1
            }
        }, res => {
            if (res.code === 200) {
                let nodata = res.data.movecarList.length<1?true:false;
                this.setData({
                    moveList: res.data.movecarList.map(item => {
                        return item;
                    }),
                    nodata: nodata
                })
            }
        })
    },
    goDetail: function(e) {
        let _index = e.currentTarget.dataset.inde;
        let _data = this.data.moveList[e.currentTarget.dataset.index];
        if (_data.type === '0') {
            wx.navigateTo({
                url: `/pages/onlineExp/createQR/createQR?imgUrl=${_data.ewm_pic_url}`
            })
        }
        if (_data.type === '1') {
            wx.navigateTo({
                url: `/pages/scan/modifyQR/modifyQR?param=${JSON.stringify(_data)}`
            })
        }
    },
    telCall: function() {
        wx.makePhoneCall({
            phoneNumber: this.data.mobile
        })
    }
})