// pages/download/download.js
Page({

    /**
     * 页面的初始数据
     */
    data: {

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    },
    onclick() {
        this.download()
    },
    download() {
        wx.getSetting({
            success: (response) => {
                if (response.authSetting['scope.writePhotosAlbum'] == undefined) {
                    wx.authorize({
                        scope: 'scope.writePhotosAlbum',
                        success: () => {
                            wx.showModal({
                                title: '确定保存图片吗',
                                content: '图片保存后去相册查看',
                                confirmColor: "#333",
                                success: (res) => {
                                    if (res.confirm) {
                                        this.imgDownload();
                                    }
                                }
                            })
                        }
                    })
                } else if (response.authSetting['scope.writePhotosAlbum'] == false) {
                    wx.openSetting({
                        success: (res) => {}
                    })
                } else if (response.authSetting['scope.writePhotosAlbum']) {

                    wx.showModal({
                        title: '确定保存图片吗',
                        content: '图片保存后去相册查看',
                        confirmColor: "#333",
                        success: (res) => {
                            if (res.confirm) {
                                this.imgDownload();
                            }
                        }
                    })
                }
            }
        })
    },
    imgDownload() {
        wx.getImageInfo({
            src: "../../static/images/appCode.jpg",
            success: function(ret) {
                var path = ret.path;
                wx.saveImageToPhotosAlbum({
                    filePath: path,
                    success(result) {
                        wx.showToast({
                            title: '保存成功',
                            icon: "none"
                        })
                    }
                })
            }
        })
    }

})