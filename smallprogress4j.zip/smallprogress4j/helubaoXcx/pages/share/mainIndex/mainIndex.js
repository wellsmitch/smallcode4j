//index.js
//获取应用实例
const app = getApp()
import {
    Network,
    Api
} from '../../../utils/index'
Page({
    data: {
        mobile: '400-1066-899',
        index_imgurl: 'https://apph5.mmcqing.com/xcx/images/share-top.png?time=' + Math.random() * 10,
        showShare: false,
        // isScroll: true,
        inviteBoList: [
            // {phoneNum: '123 **** 5678', inviteTime: '2018-09-25 12:00:00'},
            // {phoneNum: '123 **** 5678', inviteTime: '2018-09-25 12:00:00'}
        ],
        inviteNum: 0,
        userId: '',
        canConvert: 0,
        viewMore: '1', // 0展示查看更多 1不展示查看更多
    },
    onShareAppMessage: function(obj) {
        if (obj.from === 'button') {
            return {
                title: '邀请好友，免费领取挪车贴！',
                path: `/pages/index/index?recommenduserid=${this.data.userId}`,
                imageUrl: '/static/images/share-icon.png',
                success(res) { // 转发成功之后的回调
                    if (res.errMsg == 'shareAppMessage:ok') {
                        // wx.showToast({
                        //     title: '分享成功',
                        //     icon: "none"
                        // })
                    }
                },
                fail(res) { // 转发失败之后的回调
                    if (res.errMsg == 'shareAppMessage:cancel') { // 用户取消转发
                        wx.showToast({
                            title: '转发取消',
                            icon: "none"
                        })
                    } else if (res.errMsg == 'shareAppMessage:fail') {
                        // 转发失败，其中 detail message 为详细失败信息
                        wx.showToast({
                            title: '转发失败',
                            icon: "none"
                        })
                    }
                },
                complete(res) {
                    // 转发结束之后的回调（转发成不成功都会执行）
                }
            }
        }
    },
    stopProp: function(e) {},
    getCanCanvertNum: function() {
        Network.post(Api.CAN_CONVERT, {
            params: {},
            loading: false
        }, (data) => {
            if (data.code === 200) {
                this.setData({
                    canConvert: data.data.canConvert || 0
                })
            }
        })
    },
    getUserId: function() {
        Network.get(Api.USER_ID, {
            params: {},
            loading: false
        }, (data) => {
            if (data.data.code === 200) {
                this.setData({
                    userId: data.data.data.userid || ''
                })
            }
        })
    },
    onShow: function() {
        this.getInviteCount();
        this.getCanCanvertNum();
        this.getUserId();
    },
    // onLoad: function () {
    //   this.getInviteCount();
    //   this.getCanCanvertNum();
    //   this.getUserId();
    // },
    toShareBuy: function() {
        if (this.data.canConvert == '0') {
            wx.showToast({
                title: '没有足够的挪车贴可兑换',
                icon: 'none'
            })
            return;
        }
        wx.navigateTo({
            url: '/pages/share/shareBuy/shareBuy?num=' + this.data.canConvert
        })
    },
    goShareMore: function() {
        wx.navigateTo({
            url: '/pages/share/shareMore/shareMore'
        })
    },
    call: function() { // 打电话
        wx.makePhoneCall({
            phoneNumber: this.data.mobile
        })
    },
    getInviteCount() {
        Network.post(Api.INVITE_COUNT, {
            params: {},
            loading:false
        }, (data) => {
            if (data.code === 200) {
                this.setData({
                    inviteNum: data.data.inviteNum || '0',
                    inviteBoList: data.data.inviteBoList || [],
                    viewMore: data.data.viewMore || '1'
                })
            }
        })
    },
    shareCancel: function() {
        this.setData({
            showShare: false
            // isScroll: true
        });
    },
    openShare: function() {
        this.setData({
            showShare: true
            // isScroll: true
        });
    }
})