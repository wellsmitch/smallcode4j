import {
    Network,
    Api,
    validate
} from "../../../utils/index";

//index.js
//获取应用实例
const app = getApp();
Page({
    data: {
        mobile: getApp().globalData.mobile,
        region: ['河南省', '郑州市', '二七区'],
        // regionText: '河南省-郑州市-二七区',
        customItem: '全部',
        detailNum: 0,
        buyNumber: 1,
        receiver: '',
        receiverPhone: '',
        receiverAdress: '',
        receiverRegion: '河南省-郑州市-二七区',
        remark: '',
        addressReplace: '请填写详细收货地址',
        initNum: 0,
        login_code: '',
        // isScroll: true,
        showKnow: false,
        agreeCheck: true, // 协议勾选


    },
    stopProp: function (e) {
    },
    onLoad: function(options) {
        this.setData({
            login_code: app.globalData.login_code || ''
        });
        if (options.num) {
            this.setData({
                initNum: parseInt(options.num),
                buyNumber: parseInt(options.num)
            });
        }
    },
    tapAgree: function() {
        let _t = !this.data.agreeCheck;
        this.setData({
            agreeCheck: _t
        })
    },
    toMainIndex: function () {
        this.setData({
            showKnow: false
            // isScroll: true
        })
        wx.redirectTo({
            url: '/pages/share/mainIndex/mainIndex'
        })
    },
    buyImm: function() {
        // this.setData({showKnow: true})
        // return;
        if (!this.data.initNum) {
            wx.showToast({
                title: '可兑换数量不足',
                icon: 'none'
            })
            return;
        }
        if (!this.data.receiver.trim()) {
            wx.showToast({
                title: '请填写收货人姓名',
                icon: 'none'
            })
            return false;
        }
        let phoneNumber = this.data.receiverPhone.trim();
        if (!validate.phoneNumber(phoneNumber)) {
            wx.showToast({
                title: '请输入11位有效的手机号码',
                icon: 'none'
            })
            return false;
        }
        if (!this.data.receiverAdress.trim()) {
            wx.showToast({
                title: '请填写详细收货地址',
                icon: 'none'
            })
            return false;
        }
        if (!this.data.agreeCheck) {
            wx.showToast({
                title: '请勾选服务协议',
                icon: 'none'
            })
            return false;
        }
        let _param = {
            buyNumber: this.data.buyNumber,
            receiver: this.data.receiver,
            receiverPhone: this.data.receiverPhone,
            receiverAdress: `${this.data.region.join('')}${this.data.receiverAdress}`,
            type: 0,
            source: 1
        }
        return false;
        Network.post(Api.APPOINTMENT_CONVERT, {
            params: _param
        }, data => {
            if (data.code === 200) {
                this.setData({
                    showKnow: true
                    // isScroll: false
                })
            } else {
                wx.showToast({
                    title: data.message,
                    icon: 'none'
                });
            }
        })
    },
    bindRegionChange: function(e) {
        this.setData({
            receiverRegion: e.detail.value.join('-')
        })
    },
    nameBlur: function(e) {
        // if (!e.detail.value.trim()) {
        //   wx.showToast({title: '请填写收货人姓名', icon: 'none'})
        //   return false;
        // }
        this.setData({
            receiver: e.detail.value
        });
        // return true;
    },
    detailInput: function(e) {
        this.setData({
            receiverAdress: e.detail.value
        });
        if (e.detail.value) {
            this.setData({
                receiverAdress: e.detail.value
            });
        } else {
            this.setData({
                receiverAdress: '请填写详细收货地址'
            });
        }
        this.setData({
            detailNum: e.detail.value.trim().length
        })
    },
    detailBlur: function(e) {
        // if (!e.detail.value.trim()) {
        //   wx.showToast({title: '请填写详细收货地址', icon: 'none'});
        //   return false;
        // }
        this.setData({
            receiverAdress: e.detail.value
        });
        // return true;
    },
    phoneBlur: function(e) {
        // if (!e.detail.value.trim() || e.detail.value.trim().length < 11) {
        //   wx.showToast({title: '请输入11位有效的手机号码', icon: 'none'});
        //   return false;
        // }
        this.setData({
            receiverPhone: e.detail.value
        });
        // return true;
    },
    numDesc: function() {
        if (this.data.buyNumber >= 2) {
            let _d = this.data.buyNumber - 1;
            this.setData({
                buyNumber: _d,
                // totalPrice: parseFloat(this.data.singlePrice * _d).toFixed(2)
            })
        }
    },
    numAdd: function() {
        let _d = this.data.buyNumber + 1;
        if (_d <= this.data.initNum) {
            this.setData({
                buyNumber: _d,
            })
        }
    },
    goServAgree: function() {
        wx.navigateTo({
            url: '/pages/doc/servAgree/servAgree'
        })
    },
    telCall: function() {
        wx.makePhoneCall({
            phoneNumber: this.data.mobile
        })
    }
})