//index.js
//获取应用实例
const app = getApp()
import { Network, Api } from '../../../utils/index'
Page({
  data: {
    showShare: false,
    inviteNum: 0,
    userId: '',
    inviteBoList: [],
    canConvert: 0,
    yetConvert: 0,
    // isScroll: true,
    showLoading: false,
    offset: 0,
    limit: 5
  },
  onShareAppMessage: function (obj) {
    if (obj.from === 'button') {
      return {
        title: '邀请好友，免费领取挪车贴！',
        path: `/pages/index/index?recommenduserid=${this.data.userId}`,
        imageUrl: '/static/images/share-icon.png',
          success(res) { // 转发成功之后的回调
              
              if (res.errMsg == 'shareAppMessage:ok') {
                //   wx.showToast({
                //       title: '分享成功',
                //       icon: "none"
                //   })
              }
          },
          fail(res) { // 转发失败之后的回调
              if (res.errMsg == 'shareAppMessage:cancel') { // 用户取消转发
                  wx.showToast({
                      title: '转发取消',
                      icon: "none"
                  })
              } else if (res.errMsg == 'shareAppMessage:fail') {
                  // 转发失败，其中 detail message 为详细失败信息
                  wx.showToast({
                      title: '转发失败',
                      icon: "none"
                  })
              }
          },
          complete(res) {
              // 转发结束之后的回调（转发成不成功都会执行）
          }
      }
    }
  },
  stopProp: function (e) {},
  getUserId: function () {
    Network.get(Api.USER_ID, {}, (data) => {
      if (data.code === 200) {
        this.setData({userId: data.data.userid || ''})
      }
    })
  },
  loadMore: function () {

  },
  onLoad: function () {
    this.getShareMore();
    this.getUserId();
  },
  getShareMore () {
    Network.post(Api.VIEW_MORE, {
      params: {
        offset: this.data.offset,
        limit: this.data.limit
      },
      loading: false
    }, (data) => {
      if (data.code === 200) {
        let retData = data.data.inviteBoList || [];
        this.setData({
          inviteBoList: [...this.data.inviteBoList, ...(data.data.inviteBoList || [])],
          canConvert: data.data.canConvert || 0,
          yetConvert: data.data.yetConvert || 0,
          inviteNum: data.data.inviteNum || 0
        });
        if (retData.length < this.data.limit) { // 不足一页了
          this.setData({showLoading: false});
        } else if (retData.length == this.data.limit && data.data.inviteNum == (this.data.inviteBoList || []).length) {
          this.setData({showLoading: false});
        } else {
          this.setData({
            showLoading: true,
            offset: this.data.offset + this.data.limit
          })
        }
      }
    })
  },
  shareCancel: function () {
    this.setData({
      showShare: false
      // isScroll: true
    });
  },
  openShare: function () {
    this.setData({showShare: true});
  }
})
