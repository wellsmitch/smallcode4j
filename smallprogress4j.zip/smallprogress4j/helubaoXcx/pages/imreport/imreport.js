var api = require('../../utils/util.js');
var app=getApp();
Page({
    data:{
        https: getApp().globalData.https,
        // network: app.networkType(),
        network: getApp().globalData.network,
        list:[],
        active:0,  
        network:true,
        listShow:false
    },
    reportClick: function (e) {
        let that = this;
        //触摸时间距离页面打开的毫秒数
        var touchTime = that.data.touch_end - that.data.touch_start;
        if (touchTime < 350) {
            if (e.currentTarget.dataset.num >= 3) {
                wx.navigateTo({
                    url: "../reportdetails/reportdetails?apiurl=" + e.currentTarget.dataset.url + "&state=" + e.currentTarget.dataset.state
                })
            } else {
                wx.navigateTo({
                    url: "../invalid/invalid"
                })
            }
        } else {
            wx.showModal({
                title: '提示',
                content: '是否删除此条信息',
                confirmColor: "#333",
                success: function (res) {
                    if (res.confirm) {
                        app.request(that.data.https + e.currentTarget.dataset.url, "DELETE", {}, function (res) {
                            wx.showToast({
                                title: res.message,
                                icon: "none"
                            })
                            that.onShow()
                        })
                    }
                }
            })
        }
    },
    mapclick(e){
        wx.navigateTo({
            url: e.currentTarget.dataset.clickurl
        })
    },
    tabclick:function(e){
        var that = this;
        if (this.data.active === e.target.dataset.current) {
            return false;
        } else {
           
            that.setData({
                active: e.target.dataset.current
            })
        }
        
    },
    onLoad(){
        
    },
    onShow(){
        let that=this;
        wx.onNetworkStatusChange(function (res) {
            if (res.isConnected) {
                that.onLoad();
            }
            that.setData({
                network: res.isConnected
            })
        })
        let data = { orderBy: 0 };
        wx.showLoading({
            title: '加载中...',
        })
        app.requestGet(this.data.https + '/api/v3/video/draft', data, function (res) {
            for (let i = 0; i < res.data.length; i++) {
                res.data[i]["datetime"] = api.formatDate(res.data[i]["datetime"]);

            }
            that.setData({
                list: res.data,
                listShow:true
            })
            wx.hideLoading()
        })
    },
    mytouchstart: function (e) {
        let that = this;
        that.setData({
            touch_start: e.timeStamp
        })
    },
    //按下事件结束
    mytouchend: function (e) {
        let that = this;
        that.setData({
            touch_end: e.timeStamp
        })
    }

    
})