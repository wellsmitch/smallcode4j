//index.js
//获取应用实例
import {
    Api,
    Network
} from '../../utils/index'
const app = getApp();

Page({
    data: {
        mobile: getApp().globalData.mobile,
        orderNum: '0',
        ewmNum: '0',
        userInfo: '',
        canIUse: wx.canIUse('button.open-type.getUserInfo')
    },
    onLoad: function() {
        this.cewmInfoGet();
        if (app.globalData.userInfo) {
            this.setData({
                userInfo: app.globalData.userInfo
            })
        }

    },
    goMoveCarRecord: function() {
        wx.navigateTo({
            url: '/pages/buyProgress/moveQRList/moveQRList'
        })
    },
    cewmInfoGet() {
        Network.post(Api.CEWM_INFO, {
            params: {}
        }, res => {
            if (res.code === 200) {
                this.setData({
                    orderNum: res.data.total_order_num,
                    ewmNum: res.data.total_ewm_num
                });
            }
        })
    },
    goOrderRecord: function() {
        wx.navigateTo({
            url: '/pages/buyProgress/buyRecord/buyRecord'
        })
    },
    telCall: function() {
        wx.makePhoneCall({
            phoneNumber: this.data.mobile
        })
    },
    toIndex: function() {
        wx.redirectTo({
            url: '/pages/index/index'
        })
        // wx.navigateTo({
        //   url: '/pages/index/index'
        // })
    },
    hrefnavite(e) {
    }
})