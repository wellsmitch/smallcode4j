// pages/replaceImg/replaceImg.js
var api = require('../../utils/util.js');
var app = getApp();
Page({
    data: {
        https: getApp().globalData.https,
        token: getApp().globalData.token,
        url:"../pictureExample/pictureExample",
        list:[],
        datalist:[],
        mirrorId:"",
        videoId:"",
        imgId:"" ,
        imgurl:[],
        apiurl:"",
        network:true
    },
    checkboxChange(e){
        let lists = this.data.list;        
        let arr = e.detail.value;
        if (arr.length>3){
            for (var i = 0; i <lists.length-1;i++){
                lists[i].captureSelected=false;
            }      
            lists[arr[0]].captureSelected = true;
            lists[arr[1]].captureSelected = true;
            lists[arr[2]].captureSelected = true;
            this.setData({
                list: lists,
                datalist: arr
            })
            wx.showToast({
                title: '最多只能选3张图片',
                icon: 'none',
                duration: 1000,
                mask: true
            })
        }else{
            this.setData({
                datalist: arr
            })
        }
    },
    onback(){
        let that=this;
        let list=this.data.list
        let datalist= this.data.datalist; 
        if (datalist.length < 3) {
            wx.showToast({
                title: '请选择三张图片',
                icon: 'none',
                duration: 1000,
                mask: true
            })
            return false;
        }    
        let imgId = list[datalist[0]].captureId + "," + list[datalist[1]].captureId + "," + list[datalist[2]].captureId
        let datas={
            mirrorId: that.data.mirrorId,
            videoId: that.data.videoId,
            imgId: imgId
        }
        app.requestPost(this.data.https + '/api/v3/video/changeDefault', datas,function(res){
            wx.navigateBack();
        })        
    },
    onShow(){
        let that = this;
        wx.onNetworkStatusChange(function (res) {
            if (res.isConnected) {
                that.onShow(that.data.apiurl);
            }
            that.setData({
                network: res.isConnected
            })
        })
    },
    onLoad(url){
        var apiurl = url.apiurl;
        var that = this;
        app.requestGet(this.data.https + apiurl, {}, function (res) {
            let arr = [];
            let imgurl = [];
            let cap = res.data.capturesInfo;
            for (let i = 0; i < cap.length; i++) {
                imgurl.push(cap[i].captureUrl)
                if (cap[i].captureSelected) {
                    arr.push(i)
                }
            }
            that.setData({
                list: res.data.capturesInfo,
                mirrorId: res.data.mirrorId,
                videoId: res.data.videoId,
                datalist: arr,
                imgurl: imgurl,
                apiurl: apiurl
            })
        })        
    },
    imgYu: function (event) {
        var src = event.currentTarget.dataset.src;//获取data-src
        //图片预览
        wx.previewImage({
            current: src, // 当前显示图片的http链接
            urls: this.data.imgurl // 需要预览的图片http链接列表
        })
    }

})