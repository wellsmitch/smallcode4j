var api = require('../../utils/util.js');
import { Api } from '../../utils/index';
var app = getApp();
Page({
    data:{
        https: getApp().globalData.https,
        state:2,
        data:{},   //详情信息
        replaceUrl:"",    //接口保存
        typeindex:-1,//选着违法类型位子
        activetype:-1,//暂存违法类型位置
        typevarue:"请选择",//违法类型名称
        array: [],//全部违法类型
        showDialog: false,//是否显示违反类型选择
        showVehicle:false,//是否显示车牌悬着省市
        showVehicleCode:true,//
        vehicleCode:"请选择",//车牌号
        vehicleCodeShow:true,//选着车牌/手动输入车牌
        vehicleArr:[],//省市简称
        textareaShow:true,//弹出选择时隐藏输入框
        pickindex:0,//
        pickrang: [],//车牌号选择集合
        carindex:0,//选择省简称位置
        carindexshow:0,//保存省简称位置
        capitalsindex:{0:0},//选着省市简称位置
        capitalsindexshow: {0:0},//暂存省市简称位置
        vehiceH:"",//显示的省简称
        vehiceA:"",//显示的市简称
        choiceH:"",//选择时显示的省简称
        choiceA:"",//选择时显示的市简称
        mirrorId: "",//mirrorId
        videoId: "",//videoId
        carvalue:"",//手动输入的值
        caption:"",//详细说明的值
        focus:false,//input焦点
        text:false,//textarea 焦点
        carImgId:[],//imgid
        carshow:false,
        carshowindex:0,
        carshowindexB: 0,
        imgurl:[],
        network:true        
    },
    bindPickerChange: function (e) {//车牌选择原声pick事件
        var vehicleCodeShow=true;
        if (e.detail.value == this.data.pickrang.length-1){
            vehicleCodeShow=false;
        }
        this.setData({
            index: e.detail.value,
            vehicleCode: this.data.pickrang[e.detail.value],
            vehicleCodeShow: vehicleCodeShow
        })
        this.areashow()
    },
    textf(){
        this.setData({
            text: true
        })
    },
    touchmovec:function(e){
        
    },
    preventD(e){

    },
    cardialog(){//显示选着车牌
        this.setData({
            carshow: true
        })
        this.areahide()
    },
    cardialogclick(e){//点击选着车牌
        this.setData({
            carshowindex: e.currentTarget.dataset.index
        })
    },
    cardialogclose(){//取消选着车牌
        this.setData({
            carshowindex: this.data.carshowindexB,
            carshow: false
        })
        this.areashow()
    },
    cardialogsrue(){//确定选择车牌
        let vehicleCodeShow = true;
        if (this.data.carshowindex == this.data.pickrang.length-1){
            vehicleCodeShow=false;
        }
        this.setData({
            carshowindexB: this.data.carshowindex,
            carshow: false,
            vehicleCode: this.data.pickrang[this.data.carshowindex],
            vehicleCodeShow: vehicleCodeShow
        })
        this.areashow()

    },
    closedialog:function(e){//违法类型关闭
        this.setData({
            showDialog: false,
            typeindex: this.data.activetype
        })
        this.areashow()
    },
    dialogshow(){//违法类型显示
        this.setData({
            showDialog: true,
        })
        this.areahide();
    },
    carClick(e){//选择省简称点击事件
        let carH = this.data.vehicleArr[e.currentTarget.dataset.index].title;
        let carA;
        if (this.data.capitalsindex[e.currentTarget.dataset.index] || this.data.capitalsindex[e.currentTarget.dataset.index]==0){
               carA = this.data.vehicleArr[e.currentTarget.dataset.index].capitals[this.data.capitalsindex[e.currentTarget.dataset.index]].title
        }else{
             carA=""
        }
        this.setData({
            carindex: e.currentTarget.dataset.index,
            choiceH: carH,
            choiceA: carA
        })
    },
    capitalsClick(e){//选择市代码点击事件
        var obj = this.data.capitalsindex;
        obj[this.data.carindex] = e.currentTarget.dataset.index;
       
        let carH = this.data.vehicleArr[this.data.carindex].title
        let carA = this.data.vehicleArr[this.data.carindex].capitals[this.data.capitalsindex[this.data.carindex]].title
       
        this.setData({
            capitalsindex: obj,
            choiceH: carH,
            choiceA: carA
        }) 
    },
    clicktypelist(e){//违法类型选择事件
       var that=this;
       this.setData({
           typeindex: e.currentTarget.dataset.index
       }) 
    },
    sureclick(e){//违法类型选择确定按钮
        var that = this;
        this.setData({
            showDialog: false,
            typeindex: that.data.typeindex,
            activetype: that.data.typeindex,
            typevarue: that.data.array[that.data.typeindex].transgressName
        }) 
        this.areashow()
    },
    closeV(){//省市简称隐藏
        this.setData({
            showVehicle: false,
            capitalsindex: this.data.capitalsindexshow,
            carindex: this.data.carindexshow
        })
        this.areashow()
    },
    sureV(){//省市简称确定按钮
        if (this.data.capitalsindex[this.data.carindex] || this.data.capitalsindex[this.data.carindex]==0){
            var cap={};
            cap[this.data.carindex] = this.data.capitalsindex[this.data.carindex];
            var carH = this.data.vehicleArr[this.data.carindex].title
            var carA = this.data.vehicleArr[this.data.carindex].capitals[this.data.capitalsindex[this.data.carindex]].title
            this.setData({
                showVehicle: false,
                carindexshow: this.data.carindex,
                capitalsindexshow: cap,
                capitalsindex: cap,
                vehiceH: carH,
                vehiceA: carA
            })
            this.areashow();
        }else{
            wx.showToast({
                title: '请选择区牌号',
                icon: 'none',
                duration: 2000
            })
        }
    },
    dialogVshow(e){//省市简称选择显示
        this.setData({
            showVehicle: true
        }) 
        this.areahide()
    },
    replaceurl(){//跳转到更换图片页面
        wx.navigateTo({
            url: '../replaceImg/replaceImg?apiurl=' + this.data.replaceUrl
        })
    },
    onShow(){
        this.showdetails();
    },
    imgshili(){
        wx.navigateTo({
            url: '../pictureExample/pictureExample?videoId=' + this.data.videoId
        })
        
    },
    onLoad(url){
        var apiurl = url.apiurl;
        var that =this;
        that.setData({
            replaceUrl: apiurl,
            state: url.state
        })
        app.requestPost(this.data.https + "/api/v3/rule/carInfo", {time:0}, function (res) {
            that.setData({
                vehicleArr: res.data
            })
        })
    },
    getweifaleixing(){
        app.requestGet(Api.IMG_EXAMPLE, { source: 0, videoId: this.data.videoId },res=> {
            console.log(res)
            this.setData({
                array: res.data
            })
        })
    },
    showdetails(){//获取详情信息
        var that=this;
        wx.showLoading({
            title: '加载中...',
        })
        app.requestGet(this.data.https + that.data.replaceUrl, { time: 0 }, (res)=> {
            let imgurl = [];
            let arr = [];
            let area = new Set();
            res.data.snapTime = api.formatDate(res.data.snapTime);
            var vicode = res.data.capturesInfo;
            for (let i = 0; i < vicode.length; i++) {
                if (vicode[i].captureSelected) {
                    arr.push(vicode[i].captureId);
                    imgurl.push(vicode[i].captureUrl)
                }
                for (let k = 0; k < vicode[i].licenses.length; k++) {
                    if(vicode[i].licenses[k]){
                        area.add(vicode[i].licenses[k]);
                    }
                }
            }
            wx.hideLoading()
            area = Array.from(area);
            area.push("为解析出车牌？手动填写");
            that.setData({
                data: res.data,
                url: that.data.replaceUrl,
                pickrang: area,
                vehiceH: res.data.provinceMark,
                vehiceA: res.data.cityMark,
                choiceH: res.data.provinceMark,
                choiceA: res.data.cityMark,
                vehicleCode: area[0],
                carImgId: arr,
                mirrorId: res.data.mirrorId,
                videoId: res.data.videoId,
                imgurl: imgurl
            })
            this.getweifaleixing();
            
        })
    },
    areashow(){//显示textarea
        this.setData({
            textareaShow: true
        })
    },
    areahide(){//隐藏textarea
        this.setData({
            textareaShow: false
        })
    },
    warn(){//提交
        let content,onsrue=true;       
        let idcard = this.data.data.authstate;
        if (idcard==0){
            content = '您提交的实名认证信息正在审核中，系统审核通过后即可提交举报。';
            onsrue = false;           
        } else if (idcard == 1){
           
        } else if (idcard == 2) {
            content = '您提交的实名认证信息没有审核通过，请重新进行认证。';
            onsrue = false;
        } else {
            content = '请先进行实名认证，系统审核通过后即可提交举报。';
            onsrue = false;
        }
        if (!onsrue){
            wx.showModal({
                title: '提示',
                showCancel: false,
                content: content,
                confirmColor: "#333",
                success: function (res) {
                    
                }
            })
            return false;
        }
        if (this.data.state!=1){
            return false;
        }
        let that=this;
        let typecode;
        if (this.data.typeindex>-1){
            typecode = this.data.array[this.data.typeindex].transgressCode;
        }else{
            wx.showToast({
                title: '请选择违法类型',
                icon: 'none',
                duration: 2000
            })
            return false; 
        }
        
        let carCodel="";//车牌号
        if (this.data.vehicleCodeShow){
            carCodel = this.data.vehicleCode;
        }else{
            let res =/^(([冀豫云辽黑湘皖鲁苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼渝京津沪新京军空海北沈兰济南广成使领][A-Z])|([云][A][-][V]))(([A-HJ-NP-Z0-9]{4}[A-HJ-NP-Z0-9挂学警港澳])|(([DF][A-HJ-NP-Z0-9][0-9]{4})|([0-9]{5}[DF])))$/
            carCodel = this.data.vehiceH + this.data.vehiceA + this.data.carvalue;
            if (res.test(carCodel)){

            }else{
                wx.showToast({
                    title: '请正确填写号牌',
                    icon: 'none',
                    duration: 2000
                })
                return false;
            }
        }
        let plateLicense = [];//plateLicense
        for (let i = 0; i < this.data.carImgId.length;i++){
            plateLicense.push({ 
                imgId: this.data.carImgId[i],
                carNum: carCodel
            })
        }
        let plate = encodeURI(JSON.stringify(plateLicense))
        this.setData({
            focus: false
        })
        let url = this.data.https + '/api/v3/video/' + this.data.mirrorId + "/" + that.data.videoId;
        let data = {
            mirrorId: that.data.mirrorId,
            videoId: that.data.videoId,
            plate_license: plate,
            "type": typecode,
            apptype: 2,//小程序
            caption: encodeURI(that.data.caption)

        }
        app.requestPost(url, data,function(res){
            wx.showToast({
                title: res.data,
                icon: 'none',
                duration: 2000
            })
            wx.navigateBack();
        })
        

    },
    input(){//input获取焦点
        this.setData({
            focus: true
        })
    },
    binput(e){//获取input值
        this.setData({
            carvalue: e.detail.value
        })

    },
    textareaval(e){//获取text area值
        this.setData({
            caption: e.detail.value
        })
    },
    imgYu: function (event) {
        var src = event.currentTarget.dataset.src;//获取data-src
        //图片预览
        wx.previewImage({
            current: src, // 当前显示图片的http链接
            urls: this.data.imgurl // 需要预览的图片http链接列表
        })
    },
    addressmap(){
        let coordinates = this.data.data.coordinates;
        wx.navigateTo({
            url: '../adressmap/adressmap?coordinates=' + coordinates + "&address=" + this.data.data.address
        })
    }

    
})