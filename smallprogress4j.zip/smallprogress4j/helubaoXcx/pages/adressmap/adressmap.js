Page({
    data: {
        latitude: 34.797495,
        longitude: 113.643724,
        markers: [{
            id: 1,
            iconPath: "img/icon.png",
            latitude: 34.797495,
            longitude: 113.643724,
            name: ''
        }],
        address:""
       
    },
    onLoad(url){
        var latitude= url.coordinates.split(",")[1],
            longitude = url.coordinates.split(",")[0];
        let markers=[{
                id: 1,
                iconPath: "img/icon.png",
                latitude: latitude,
                longitude: longitude,
                name: '',
                width:30,
                height:30
            }]
        this.setData({
            latitude: latitude,
            longitude: longitude,
            address: url.address,
            markers: markers
        })

    } 
})
