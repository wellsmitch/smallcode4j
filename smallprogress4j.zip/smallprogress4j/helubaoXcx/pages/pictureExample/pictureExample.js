var app = getApp();
import {Api} from '../../utils/index';
Page({
    data:{
        https: getApp().globalData.https,
        imgurl:[]
    },
    onLoad(option){
        console.log(option)
        app.requestGet(Api.IMG_EXAMPLE, {source: 0, videoId: this.data.videoId}, res=> {
            console.log(res)
            this.setData({
                imgurl: res.data
            })
        })
    }
})