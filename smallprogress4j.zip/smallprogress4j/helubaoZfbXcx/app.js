App({
  onLaunch(options) {
    // 第一次打开
    // options.query == {number:1}
    //console.info('App onLaunch');
  },
  onShow(options) {
    // 从后台被 scheme 重新打开
    // options.query == {number:1}  18089 8083
  },
  globalData:{
    ApiUrl:'https://www.mmcqing.com:18089',
    author_img:'',
    author_name:'',
    userId:'',
    token:'',
    phone:'',
    isBind:false,
    id:'',
    goodsNumber:'',
    rentDate:'',
    receiver:'',
    receiverAdress:'',
    receiverPhone:'',
    receiverRegion:'',
  }
});
