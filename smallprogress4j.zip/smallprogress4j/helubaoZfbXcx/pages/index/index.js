const app = getApp();
Page({
  data:{
    imgUrlId:'',
    imgUrls:'',
    list:[],
    mode: 'widthFix',
  },
  onLoad(query) {
    // 页面加载
    // console.log('hello APP');
    // console.info(`Page onLoad with query: ${JSON.stringify(query)}`);
  },
  banner(){
    let that = this;
    my.httpRequest({
      method: 'get',
      url: app.globalData.ApiUrl + '/api/v3/xcx/h5/resources', // 该url是自己的服务地址，实现的功能是服务端拿到authcode去开放平台进行token验证
      data: {
        type: 18
      },
      success: (data) => {
        //console.log(data);
        if(data.data.code==200){
          if(data.data.data){
            that.setData({
              imgUrlId: data.data.data[0].linkUrl,
              imgUrls:data.data.data[0].picUrl
            })
          }
        }else{
          my.alert({
            title:'提示',
            content:data.data.message
          })
        }
      }
    })
  },
  onReady() {
    // 页面加载完成
    // 授权
    this.getAuthCodes();
  },
  onShow() {
    // 页面显示
    //租赁商品列表
    this.banner();
    this.getProductList();
  },
  tiaozhuan(){
    var that = this;
    if (!that.data.imgUrlId){
      return;
    }
    my.navigateTo({
      url: that.data.imgUrlId
    })
  },
  getAuthCodes(){
    //获取授权
    my.getAuthCode({
      scopes: 'auth_base', // 主动授权：auth_user，静默授权：auth_base
      success: (res) => {
        //console.log(res);
        if (res.authCode) {
          //console.log(res.authCode);
          let codes = res.authCode;
          //console.log(codes)
          // 认证成功
          // 调用自己的服务端接口，让服务端进行后端的授权认证，并且种session，需要解决跨域问题
          my.httpRequest({
            method:'post',
            url: app.globalData.ApiUrl+'/api/xcx/zfb/oauth', // 该url是自己的服务地址，实现的功能是服务端拿到authcode去开放平台进行token验证
            data: {
              code: codes
            },
            success: (data) => {
              // 授权成功并且服务器端登录成功
              if(data.data.code==200){
                //console.log(data);
                app.globalData.userId = data.data.data.userId;
                //console.log(app.globalData.userId);
                // 获取token
                my.httpRequest({
                  method:'post',
                  url: app.globalData.ApiUrl + '/api/thirdparty/login', // 目标服务器url
                  data: {
                    type: 'zfbxcx',
                    openid: data.data.data.userId
                  },
                  success: (res) => {
                    //console.log(res);
                    if(res.data.code==200){
                      app.globalData.token = res.data.data.token;
                      app.globalData.isBind = res.data.data.isBind;
                    }
                  },
                });
                my.getAuthCode({
                  scopes: 'auth_base',
                  success: (res) => {
                    my.getAuthUserInfo({
                      success: (userInfo) => {
                        //console.log(userInfo);
                        app.globalData.author_img = userInfo.avatar;
                        app.globalData.author_name = userInfo.nickName;
                      }
                    });
                  },
                });
              } else if (data.data.code == -1){
                my.alert({
                  title:'提示',
                  content: data.data.message 
                });
              }
            },
            fail: () => {
              // 根据自己的业务场景来进行错误处理
            },
          });
        }
      },
    })
  },
  getProductList(){
    my.httpRequest({
      method: 'post',
      url: app.globalData.ApiUrl + '/api/v1/goods', // 该url是自己的服务地址，实现的功能是服务端拿到authcode去开放平台进行token验证
      data: {
        source: 1
      },
      success: (data) => {
        //console.log(data);
        if(data.data.code==100){
          this.setData({
            list:data.data.data
          })
        }else{
          // my.alert({
          //   title:'提示',
          //   content:data.data.message
          // })
        }
      }
    })
  },
  onHide() {
    // 页面隐藏
  },
  onUnload() {
    // 页面被关闭
  },
  onTitleClick() {
    // 标题被点击
  },
  onPullDownRefresh() {
    // 页面被下拉
  },
  onReachBottom() {
    // 页面被拉到底部
  },
  onShareAppMessage() {
    // 返回自定义分享信息
    return {
      title: '和路宝',
      desc: '品牌租赁 信用免押',
      path: '/pages/index/index',
      imageUrl:'/images/share.png'
    };
  },
});
