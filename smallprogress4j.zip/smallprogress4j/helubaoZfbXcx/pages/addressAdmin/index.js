const app = getApp();
Page({
  data: {
    IsDefault:1,
    list:[],
    mode:'widthFix'
  },
  switchChange (e){
    let that = this;
    //console.log(e);
    //console.log('switchChange 事件，值:', e.detail.value);
    if(e.detail.value){
      that.setData({
        IsDefault:0
      })
    }else{
      that.setData({
        IsDefault:1
      })
    }
    let data = {
      id:e.target.dataset.id,
      receiver:e.target.dataset.receiver,
      receiverPhone:e.target.dataset.receiverPhone,
      receiverAdress:e.target.dataset.receiverAdress,
      receiverRegion:e.target.dataset.receiverRegion,
      isDefaultFlag:that.data.IsDefault
    };
    my.httpRequest({
      method:'post',
      url: app.globalData.ApiUrl+'/api/v1/uReceiverTerminal', // 该url是自己的服务地址，实现的功能是服务端拿到authcode去开放平台进行token验证
      data:{
        'params':JSON.stringify(data)
      },
      headers:{
        'token':app.globalData.token
      },
      success: (res) => {
        //console.log(res);
        if(res.data.code==100){
          that.list();
          my.alert({
            title:'提示',
            content:res.data.message
          })
        }else{
          my.alert({
            title:'提示',
            content:res.data.message
          })
        }
      }
    })
  },
  onLoad(query) {
    // 页面加载
    console.info(`Page onLoad with query: ${JSON.stringify(query)}`);
  },
  onReady() {
    // 页面加载完成
  },
  list(){
    let that = this;
    my.httpRequest({
      method:'post',
      url: app.globalData.ApiUrl+'/api/v1/sReceiverTerminal', // 该url是自己的服务地址，实现的功能是服务端拿到authcode去开放平台进行token验证
      headers:{
        'token':app.globalData.token
      },
      success: (res) => {
        //console.log(res);
        if(res.data.code==100){
          if(res.data.data){
            that.setData({
              list:res.data.data
            })
          }
        }else{
          my.alert({
            title:'提示',
            content:res.data.message
          })
        }
      }
    })
  },
  delAddress(e){
    let that = this;
    let id = e.target.dataset.id;
    my.confirm({
      title: '提示',
      content: '您是否确定删除该地址',
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      success: (result) => {
        if(result.confirm){
          my.httpRequest({
            method:'post',
            url: app.globalData.ApiUrl+'/api/v1/dReceiverTerminal', // 该url是自己的服务地址，实现的功能是服务端拿到authcode去开放平台进行token验证
            data:{id:id},
            headers:{
              'token':app.globalData.token
            },
            success: (res) => {
              //console.log(res);
              if(res.data.code==100){
                that.list();
                my.alert({
                  title:'提示',
                  content:res.data.message,
                })
              }
            }
          })
        }
      },
    });
  },
  onShow() {
    // 页面显示
    this.list();
  },
  onHide() {
    // 页面隐藏
  },
  onUnload() {
    // 页面被关闭
  },
  onTitleClick() {
    // 标题被点击
  },
  onPullDownRefresh() {
    // 页面被下拉
  },
  onReachBottom() {
    // 页面被拉到底部
  },
  onShareAppMessage() {
    // 返回自定义分享信息
    // 返回自定义分享信息
    return {
      title: '和路宝',
      desc: '品牌租赁 信用免押',
      path: '/pages/index/index',
      imageUrl:'/images/share.png'
    };
  },
});
