const app = getApp();
var address = require('../../js/city.js');
Page({
  data: {
    isEdit:0,
    mode:'widthFix',
    id:'',
    people:'',
    phone:'',
    address:'',
    xsaddress:'',
    checkId:1,
    isShow:false,
    value: [0, 0, 0],
    provinces: [],
    citys: [],
    areas: [],
    province: '',
    city: '',
    area: ''
  },
  switchChange (e){//设为默认
    let that = this;
    //console.log('switchChange 事件，值:', e.detail.value);
    if(e.detail.value){
      that.data.checkId = 0;
      // that.setData({
      //   checkId:0
      // })
    }else{
      that.data.checkId = 1;
      // that.setData({
      //   checkId:1
      // })
    }
  },
  bindTextAreaBlur(e) {//详细地址
    this.data.xsaddress = e.detail.value
    // this.setData({
    //   xsaddress: e.detail.value,
    // });
  },
  bindUser(e){//收货人
    this.data.people = e.detail.value;
    // this.setData({
    //   people: e.detail.value,
    // });
  },
  bindPhone(e){//收货人电话
    this.data.phone = e.detail.value;
    // this.setData({
    //   phone: e.detail.value,
    // });
  },
  bindAddress(e){//收货人地址
    this.data.address = e.detail.value;
    // this.setData({
    //   address: e.detail.value,
    // });
  },
  saveAddree(){//新增收货地址
    //console.log(this.data);
    let that = this;
    //console.log(that.data.checkId);
    if(!that.data.people){
      my.alert({
        title:'提示',
        content:'收货人姓名不能为空'
      });
      return false;
    }
    if(!that.data.phone){
      my.alert({
        title:'提示',
        content:'收货人电话不能为空'
      });
      return false;
    }else{
      let phoneReg = /^1[0-9]{10}$/;
      if (!phoneReg.test(that.data.phone)){
        my.alert({
          title:'提示',
          content:'请输入正确的手机号'
        })
        return false;
      }
    }
    if(!that.data.address){
      my.alert({
        title:'提示',
        content:'收货人地址不能为空'
      });
      return false;
    }
    if(!that.data.xsaddress){
      my.alert({
        title:'提示',
        content:'收货人详细地址不能为空'
      });
      return false;
    }
    
    let data = {
      receiver:that.data.people,
      receiverPhone:that.data.phone,
      receiverAdress:that.data.xsaddress,
      receiverRegion:that.data.address,
      isDefaultFlag:that.data.checkId
    };
    my.httpRequest({
      method:'post',
      url: app.globalData.ApiUrl+'/api/v1/cReceiverTerminal', // 该url是自己的服务地址，实现的功能是服务端拿到authcode去开放平台进行token验证
      data:{
        'params':JSON.stringify(data)
      },
      headers:{
        'token':app.globalData.token
      },
      success: (res) => {
        //console.log(res);
        if(res.data.code==100){
          my.alert({
            title:'提示',
            content:res.data.message,
            success: () => {
              my.navigateBack({
                delta: 1
              })
              // my.redirectTo({
              //   url: '/pages/addressList/index'
              // })
            }
          })
        }else{
          my.alert({
            title:'提示',
            content:res.data.message
          })
        }
      }
    })
  },
  updateAddree(){//修改收货地址
    let that = this;
    if(!that.data.people){
      my.alert({
        title:'提示',
        content:'收货人姓名不能为空'
      });
      return false;
    }
    if(!that.data.phone){
      my.alert({
        title:'提示',
        content:'收货人电话不能为空'
      });
      return false;
    }else{
      let phoneReg = /^1[0-9]{10}$/;
      if (!phoneReg.test(that.data.phone)){
        my.alert({
          title:'提示',
          content:'请输入正确的手机号'
        })
        return false;
      }
    }
    if(!that.data.address){
      my.alert({
        title:'提示',
        content:'收货人地址不能为空'
      });
      return false;
    }
    if(!that.data.xsaddress){
      my.alert({
        title:'提示',
        content:'收货人详细地址不能为空'
      });
      return false;
    }
    let data = {
      id:that.data.id,
      receiver:that.data.people,
      receiverPhone:that.data.phone,
      receiverAdress:that.data.xsaddress,
      receiverRegion:that.data.address,
      isDefaultFlag:that.data.checkId
    };
    my.httpRequest({
      method:'post',
      url: app.globalData.ApiUrl+'/api/v1/uReceiverTerminal', // 该url是自己的服务地址，实现的功能是服务端拿到authcode去开放平台进行token验证
      data:{
        'params':JSON.stringify(data)
      },
      headers:{
        'token':app.globalData.token
      },
      success: (res) => {
        //console.log(res);
        if(res.data.code==100){
          my.alert({
            title:'提示',
            content:res.data.message,
            success: () => {
              my.redirectTo({
                url: '/pages/addressList/index'
              })
            }
          })
        }else{
          my.alert({
            title:'提示',
            content:res.data.message
          })
        }
      }
    })
  },
  selectAddress(){
    let that = this;
    that.setData({
      isShow:true
    })
  },
  onLoad(query) {
    // 页面加载
    //console.info(`Page onLoad with query: ${JSON.stringify(query)}`);
    let checkId;
    if(query.receiver){
      this.setData({
        isEdit:1
      })
    }else{
      this.setData({
        isEdit:0
      })
    }
    if(query.isDefaultFlag){
      checkId = query.isDefaultFlag
    }else{
      checkId = 1;
    }
    this.setData({
      id:query.id,
      people:query.receiver,
      phone:query.receiverPhone,
      address:query.receiverRegion,
      xsaddress:query.receiverAdress,
      checkId:checkId
    })
    //三级级联
    // 默认联动显示北京
    var id = address.provinces[0].id
    this.setData({
      provinces: address.provinces,
      citys: address.citys[id],
      areas: address.areas[address.citys[id][0].id],
    })
  },
  // 点击地区选择取消按钮
  cityCancel: function () {
    let that = this;
    that.setData({
      isShow:false
    })
  },
  // 点击地区选择确定按钮
  citySure: function (e) {
    var that = this;
    var city = that.data.city;
    var value = that.data.value;
    // 将选择的城市信息显示到输入框
    var areaInfo = that.data.provinces[value[0]].name + ',' + that.data.citys[value[1]].name + ',' + that.data.areas[value[2]].name
    // that.data.address = that.data.provinces[value[0]].name+that.data.citys[value[1]].name+ that.data.areas[value[2]].name;
    // that.data.isShow = false;

    that.setData({
      areaInfo: areaInfo,
      address:that.data.provinces[value[0]].name+that.data.citys[value[1]].name+ that.data.areas[value[2]].name,
      isShow:false
    })
  },
  cityChange(e) {//三级级联
    //console.log(e)
    var value = e.detail.value
    var provinces = this.data.provinces
    var citys = this.data.citys
    var areas = this.data.areas
    var provinceNum = value[0]
    var cityNum = value[1]
    var countyNum = value[2]
    if (this.data.value[0] != provinceNum) {
      var id = provinces[provinceNum].id
      this.setData({
        value: [provinceNum, 0, 0],
        citys: address.citys[id],
        areas: address.areas[address.citys[id][0].id],
      })
    } else if (this.data.value[1] != cityNum) {
      var id = citys[cityNum].id
      this.setData({
        value: [provinceNum, cityNum, 0],
        areas: address.areas[citys[cityNum].id],
      })
    } else {
      this.setData({
        value: [provinceNum, cityNum, countyNum]
      })
    }
    //console.log(this.data)
    // console.log(e.detail.value);
    // this.setData({
    //   value: e.detail.value,
    // });
  },
  onReady() {
    // 页面加载完成
  },
  onShow() {
    // 页面显示
  },
  onHide() {
    // 页面隐藏
  },
  onUnload() {
    // 页面被关闭
  },
  onTitleClick() {
    // 标题被点击
  },
  onPullDownRefresh() {
    // 页面被下拉
  },
  onReachBottom() {
    // 页面被拉到底部
  },
  onShareAppMessage() {
    // 返回自定义分享信息
    return {
      title: '和路宝',
      desc: '品牌租赁 信用免押',
      path: '/pages/index/index',
      imageUrl:'/images/share.png'
    };
  },
});
