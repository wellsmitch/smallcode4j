const app = getApp();
Page({
  data: {
    id:'',
    goodsNumber:'',
    rentDate:'',
    list:[],
    mode:'widthFix'
  },
  onLoad(query) {
    // 页面加载
    //console.info(`Page onLoad with query: ${JSON.stringify(query)}`);
    this.setData({
      id:query.id,
      goodsNumber:query.goodsNumber,
      rentDate:query.rentDate
    })
  },
  onReady() {
    // 页面加载完成
    
  },
  list(){
    my.httpRequest({
      method:'post',
      url: app.globalData.ApiUrl+'/api/v1/sReceiverTerminal', // 该url是自己的服务地址，实现的功能是服务端拿到authcode去开放平台进行token验证
      headers:{
        'token':app.globalData.token
      },
      success: (res) => {
        //console.log(res);
        if(res.data.code==100){
          if(res.data.data){
            this.setData({
              list:res.data.data
            })
          }
        }
      }
    })
  },
  onShow() {
    // 页面显示
    this.list();
  },
  addressSel(e){
    //console.log(e);
    // let id = this.data.id;
    // let goodsNumber = this.data.goodsNumber;
    // let rentDate = this.data.rentDate;
    // let receiver = e.target.dataset.receiver;
    // let receiverAdress = e.target.dataset.receiverAdress;
    // let receiverPhone = e.target.dataset.receiverPhone;
    // let receiverRegion = e.target.dataset.receiverRegion;
    app.globalData.id = this.data.id;
    app.globalData.goodsNumber = this.data.goodsNumber;
    app.globalData.rentDate = this.data.rentDate;
    app.globalData.receiver = e.target.dataset.receiver;
    app.globalData.receiverAdress = e.target.dataset.receiverAdress;
    app.globalData.receiverPhone = e.target.dataset.receiverPhone;
    app.globalData.receiverRegion = e.target.dataset.receiverRegion;
    // my.redirectTo({
    //   url: '/pages/orderQueren/index?id='+id+'&goodsNumber='+goodsNumber+"&rentDate="+rentDate+"&receiver="+receiver+"&receiverAdress="+receiverAdress+'&receiverPhone='+receiverPhone+'&receiverRegion='+receiverRegion
    // })
    // 在three页面内 navigateBack，将返回one页面
    my.navigateBack({
      delta: 1
    })
  },
  onHide() {
    // 页面隐藏
  },
  onUnload() {
    // 页面被关闭
  },
  onTitleClick() {
    // 标题被点击
  },
  onPullDownRefresh() {
    // 页面被下拉
  },
  onReachBottom() {
    // 页面被拉到底部
  },
  onShareAppMessage() {
    // 返回自定义分享信息
    return {
      title: '和路宝',
      desc: '品牌租赁 信用免押',
      path: '/pages/index/index',
      imageUrl:'/images/share.png'
    };
  },
});
