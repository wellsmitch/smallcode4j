const app = getApp();
Page({
  data: {
    isShow:false,
    list:[],
    mode:'aspectFill'
  },
  onLoad(query) {
    // 页面加载
    console.info(`Page onLoad with query: ${JSON.stringify(query)}`);
  },
  onReady() {
    // 页面加载完成
  },
  onShow() {
    // 页面显示
    this.list();
  },
  list(){
    let that = this;
    my.httpRequest({
      method:'post',
      url:app.globalData.ApiUrl+'/api/v1/listOrder',
      data:{
        source:1
      },
      headers:{
        'token':app.globalData.token
      },
      success:(res)=>{
        // console.log(res);
        if(res.data.code==200){
          if(res.data.data){
            that.setData({
              list:res.data.data,
              isShow:false
            })
          }else{
            that.setData({
              isShow:true
            })
          }
        }else{
          my.alert({
            title:'提示',
            content:res.data.message
          })
        }
      }
    })
  },
  backhome(){
    my.switchTab({
      url:'/pages/index/index'
    })
  },
  onHide() {
    // 页面隐藏
  },
  onUnload() {
    // 页面被关闭
  },
  onTitleClick() {
    // 标题被点击
  },
  onPullDownRefresh() {
    // 页面被下拉
  },
  onReachBottom() {
    // 页面被拉到底部
  },
  onShareAppMessage() {
    // 返回自定义分享信息
    return {
      title: '和路宝',
      desc: '品牌租赁 信用免押',
      path: '/pages/index/index',
      imageUrl:'/images/share.png'
    };
  },
});
