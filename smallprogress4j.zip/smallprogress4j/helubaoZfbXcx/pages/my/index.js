const app = getApp();
var util = require('../../js/MD5.js');
Page({
  data: {
    phone:'',
    code:'',
    IsLoginShow:false,
    sms_zt: '发送验证码',
    second: 60,
    nullHouse1: true,
    nullHouse2: false,
    mode:'widthFix'
  },
  onLoad(query) {
    // 页面加载
    // console.info(`Page onLoad with query: ${JSON.stringify(query)}`);
  },
  orderClick(){
    // /pages/order/index
    let token = app.globalData.token;
    let isBind = app.globalData.isBind;
    var that = this;
    if(!isBind){
      my.redirectTo({
        url:'/pages/login/index?from=my'
      })
    }else{
      my.navigateTo({
        url:'/pages/order/index'
      })
    }
  },
  bindKeyInput(e){
    this.setData({
      phone: e.detail.value,
    });
  },
  bindKeyCode(e){
    this.setData({
      code: e.detail.value,
    });
  },
  getcode(){
    var phone = this.data.phone;
    if(!phone){
      my.alert({
        title: '提示',
        content: '手机号不能为空' 
      });
    }else{
      let phoneReg = /^1[0-9]{10}$/;
      if (!phoneReg.test(phone)){
        my.alert({
          title:'提示',
          content:'请输入正确的手机号'
        })
      }else{
        let that = this;
        that.countdown(that);
        let random = this.randomWord(true, 32, 32);
        let timestamp =  new Date().getTime();
        let secret_key = '1234567';
        let signature = util.hexMD5('phone=' + phone + '&random=' + random + '&timestamp=' + timestamp + '&secret_key=' + secret_key);
        // console.log(signature);
        my.httpRequest({
          method: 'post',
          url: app.globalData.ApiUrl + '/api/oauth/sms/bind', // 该url是自己的服务地址，实现的功能是服务端拿到authcode去开放平台进行token验证
          data: {
            phone: phone,
            random: random,
            timestamp: timestamp,
            signature: signature,
          },
          success: (res) => {
            //console.log(res);
            if(res.data.code==200){
              
            }
          }
        })
      }
    }
  },
  login(){
    let that = this;
    let phone = this.data.phone;
    let code = this.data.code;
    if(!phone){
      my.alert({
        title: '提示',
        content:'手机号不能为空'
      })
      return false;
    }
    if(!code){
      my.alert({
        title: '提示',
        content: '验证码不能为空'
      })
      return false;
    }
    my.httpRequest({
      method: 'post',
      url: app.globalData.ApiUrl + '/api/thirdparty/bind', // 该url是自己的服务地址，实现的功能是服务端拿到authcode去开放平台进行token验证
      data: {
        type: 'zfbxcx',
        openid: app.globalData.userId,
        phone:phone,
        password: code,
      },
      success: (res) => {
        //console.log(res);
        if(res.data.code==200){
          app.globalData.token = res.data.data.token;
          app.globalData.phone = res.data.data.phone;
          that.setData({
            phone:'',
            code:'',
            IsLoginShow:false
          })
        }
        //that.countdown(that);
      }
    })
  },
  randomWord(randomFlag, min, max){//生成随机数
    var str = "",
      pos,
    range = min,
    arr =['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
    // 随机产生
    if(randomFlag) {
      range = Math.round(Math.random() * (max - min)) + min;
    }
    for(var i = 0; i<range; i++){
    pos = Math.round(Math.random() * (arr.length - 1));
    str += arr[pos];
  }
  return str;
  },
  countdown(that){
    var second = that.data.second;
    if(second==0){
      that.setData({
        second: 60,
        nullHouse1: true,
        nullHouse2: false
      });
      return;
    }
    var time = setTimeout(function(){
      that.setData({
        second: second - 1,
        nullHouse1: false,
        nullHouse2: true
      })
      this.countdown(that);
    }.bind(this),1000)
  },
  preventTouchMove:function(e) {
    alert(1);
  },
  onReady() {
    // 页面加载完成
  },
  onShow() {
    // 页面显示
  },
  onHide() {
    // 页面隐藏
  },
  onUnload() {
    // 页面被关闭
  },
  onTitleClick() {
    // 标题被点击
  },
  onPullDownRefresh() {
    // 页面被下拉
  },
  onReachBottom() {
    // 页面被拉到底部
  },
  onShareAppMessage() {
    // 返回自定义分享信息
    return {
      title: '和路宝',
      desc: '品牌租赁 信用免押',
      path: '/pages/index/index',
      imageUrl:'/images/share.png'
    };
  },
});
