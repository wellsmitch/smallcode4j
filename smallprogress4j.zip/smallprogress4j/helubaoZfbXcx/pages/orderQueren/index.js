const app = getApp();
Page({
  data: {
    id:'',
    value:0,
    receivera: '',
    receiverAdressa: '',
    receiverPhonea: '',
    receiverRegiona:'',
    checked:false,
    goodsNumber:'',
    rentDate:'',
    msg:[],
    mode:'aspectFill',
    isloading:false
  },
  onChange: function(e) {
    //console.log('你选择的框架是：', e.detail.value);
    if(e.detail.value){
      this.setData({
        value:1,
        checked:true
      })
    }else{
      this.setData({
        value:0,
        checked:false
      })
    }
  },
  subOrder(){//提交订单
    let that = this;
    if(!that.data.msg.receiver){
      my.alert({
        title:'提示',
        content:'请选择收货地址'
      })
      return false;
    }
    if(!that.data.checked){
      my.alert({
        title:'提示',
        content:'请阅读并同意《租赁服务协议》'
      })
      return false;
    }
    let receiver,receiverPhone,receiverRegion,receiverAdress;
    if(that.data.receivera){
      receiver = that.data.receivera;
      receiverPhone = that.data.receiverPhonea;
      receiverRegion = that.data.receiverRegiona;
      receiverAdress = that.data.receiverAdressa;
    }else{
      receiver = that.data.msg.receiver;
      receiverPhone = that.data.msg.receiverPhone;
      receiverRegion = that.data.msg.receiverRegion;
      receiverAdress = that.data.msg.receiverAdress;
    }
    let data = {
        goodsNumber:1,
        packageId:that.data.id,
        receiver:receiver,
        receiverPhone:receiverPhone,
        receiverAdress:receiverRegion+receiverAdress,
        freight:that.data.msg.freight,
        goodsTotalPrice:that.data.msg.goodsTotalPrice,
        rentDate:that.data.msg.rentDate,
        totalRentPrice:that.data.msg.totalRentPrice
      };
    my.showLoading();
    my.httpRequest({
      method:'post',
      url:app.globalData.ApiUrl+'/api/v1/cOrder',
      data:{
        params:JSON.stringify(data)
      },
      headers:{
        'token':app.globalData.token
      },
      success:(res)=>{
        // console.log(res);
        if(res.data.code==100){
          let orderNumber = res.data.data.orderNumber;
          my.httpRequest({//解冻支付
            url: app.globalData.ApiUrl+'/api/pay/all/create/order', // 目标服务器url
            data:{
              tradeType:'freeze-app-zfb',
              orderNumber:orderNumber
            },
            headers:{
              'token':app.globalData.token
            },
            method: 'POST',
            success: (resa) => {
              // console.log(resa);
              my.hideLoading();
              if(resa.data.code==200){
                my.tradePay({//调起支付
                  orderStr: resa.data.data.orderStr,  // 即上述服务端已经加签的orderSr参数
                  success: (resb) => {
                    if(resb.resultCode==9000){
                      my.redirectTo({
                        url:'/pages/successok/index'
                      })
                    }
                    
                  },
                });
              }else{
                my.alert({
                  title:'提示',
                  content: '1111'
                });
              } 
            },fail: function(res) {
              my.alert({ content: '2222fail' });
            }
          });
        }else{
          my.alert({
            title:'提示',
            content:res.data.message
          })
        }
      },
      fail: function(res) {
        my.alert({ content: '111fail' });
      }
    })
  },
  onLoad(query) {

      this.setData({
        id:query.id,
        goodsNumber:query.goodsNumber,
        rentDate:query.rentDate,
        receivera: query.receiver,
        receiverAdressa: query.receiverAdress,
        receiverPhonea: query.receiverPhone,
        receiverRegiona: query.receiverRegion
      })
    
    console.info(`Page onLoad with query: ${JSON.stringify(query)}`);
    
  },
  orderMsg(){
    let that = this;
    let data = {
      id:that.data.id,
      goodsNumber:that.data.goodsNumber,
      rentDate:that.data.rentDate
    };
    my.httpRequest({
      method:'post',
      url:app.globalData.ApiUrl+'/api/v1/flushSaleInfo',
      data:{
        params:JSON.stringify(data)
      },
      headers:{
        'token':app.globalData.token
      },
      success:(res)=>{
        // console.log(res);
        if(res.data.code == 100){
          that.setData({
            msg:res.data.data
          })
        }else{
          my.alert({
            title:'提示',
            content:res.data.message
          })
        }
      }
    })
  },
  xieyiClick(){
    my.navigateTo({
      url: '/pages/xieyi/index'
    })
  },
  dizhiSelect(){
    //my.redirectTo({
    my.navigateTo({
      url: '/pages/addressList/index?id='+this.data.id+'&goodsNumber='+this.data.goodsNumber+'&rentDate='+this.data.rentDate
    })
  },
  onReady() {
    // 页面加载完成
  },
  onShow() {
    if(app.globalData.id){
      this.setData({
        id:app.globalData.id,
        goodsNumber:app.globalData.goodsNumber,
        rentDate:app.globalData.rentDate,
        receivera: app.globalData.receiver,
        receiverAdressa: app.globalData.receiverAdress,
        receiverPhonea: app.globalData.receiverPhone,
        receiverRegiona: app.globalData.receiverRegion
      })
    }
    // 页面显示
    this.orderMsg();
  },
  onHide() {
    // 页面隐藏
  },
  onUnload() {
    // 页面被关闭
  },
  onTitleClick() {
    // 标题被点击
  },
  onPullDownRefresh() {
    // 页面被下拉
  },
  onReachBottom() {
    // 页面被拉到底部
  },
  onShareAppMessage() {
    // 返回自定义分享信息
    return {
      title: '和路宝',
      desc: '品牌租赁 信用免押',
      path: '/pages/index/index',
      imageUrl:'/images/share.png'
    };
  },
});
